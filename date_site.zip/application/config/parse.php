<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	$config['parse_app_id'] = 'parse_app_id';
	$config['parse_rest_key'] = 'parse_rest_key';
