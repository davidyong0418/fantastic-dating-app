<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-05 07:32:42 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
ERROR - 2018-03-05 07:32:43 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
ERROR - 2018-03-05 07:32:46 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
ERROR - 2018-03-05 07:32:46 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-05 07:33:28 --> Database Driver Class Initialized
INFO - 2018-03-05 07:33:28 --> Config Class Initialized
INFO - 2018-03-05 07:33:28 --> Hooks Class Initialized
DEBUG - 2018-03-05 07:33:28 --> UTF-8 Support Enabled
INFO - 2018-03-05 07:33:28 --> Utf8 Class Initialized
INFO - 2018-03-05 07:33:28 --> URI Class Initialized
INFO - 2018-03-05 07:33:28 --> Router Class Initialized
INFO - 2018-03-05 07:33:28 --> Output Class Initialized
INFO - 2018-03-05 07:33:28 --> Security Class Initialized
DEBUG - 2018-03-05 07:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 07:33:28 --> Input Class Initialized
INFO - 2018-03-05 07:33:28 --> Language Class Initialized
ERROR - 2018-03-05 07:33:28 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-05 07:34:17 --> Database Driver Class Initialized
INFO - 2018-03-05 07:34:17 --> Config Class Initialized
INFO - 2018-03-05 07:34:17 --> Hooks Class Initialized
DEBUG - 2018-03-05 07:34:17 --> UTF-8 Support Enabled
INFO - 2018-03-05 07:34:17 --> Utf8 Class Initialized
INFO - 2018-03-05 07:34:17 --> URI Class Initialized
INFO - 2018-03-05 07:34:17 --> Router Class Initialized
INFO - 2018-03-05 07:34:17 --> Output Class Initialized
INFO - 2018-03-05 07:34:17 --> Security Class Initialized
DEBUG - 2018-03-05 07:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 07:34:17 --> Input Class Initialized
INFO - 2018-03-05 07:34:17 --> Language Class Initialized
ERROR - 2018-03-05 07:34:17 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-05 07:38:34 --> Database Driver Class Initialized
INFO - 2018-03-05 07:38:34 --> Config Class Initialized
INFO - 2018-03-05 07:38:34 --> Hooks Class Initialized
DEBUG - 2018-03-05 07:38:34 --> UTF-8 Support Enabled
INFO - 2018-03-05 07:38:34 --> Utf8 Class Initialized
INFO - 2018-03-05 07:38:34 --> URI Class Initialized
INFO - 2018-03-05 07:38:34 --> Router Class Initialized
INFO - 2018-03-05 07:38:34 --> Output Class Initialized
INFO - 2018-03-05 07:38:34 --> Security Class Initialized
DEBUG - 2018-03-05 07:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 07:38:34 --> Input Class Initialized
INFO - 2018-03-05 07:38:34 --> Language Class Initialized
ERROR - 2018-03-05 07:38:34 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-05 07:39:14 --> Database Driver Class Initialized
INFO - 2018-03-05 07:39:14 --> Config Class Initialized
INFO - 2018-03-05 07:39:14 --> Hooks Class Initialized
DEBUG - 2018-03-05 07:39:14 --> UTF-8 Support Enabled
INFO - 2018-03-05 07:39:14 --> Utf8 Class Initialized
INFO - 2018-03-05 07:39:14 --> URI Class Initialized
INFO - 2018-03-05 07:39:14 --> Router Class Initialized
INFO - 2018-03-05 07:39:14 --> Output Class Initialized
INFO - 2018-03-05 07:39:14 --> Security Class Initialized
DEBUG - 2018-03-05 07:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 07:39:14 --> Input Class Initialized
INFO - 2018-03-05 07:39:14 --> Language Class Initialized
ERROR - 2018-03-05 07:39:14 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-05 07:39:14 --> Database Driver Class Initialized
INFO - 2018-03-05 07:39:14 --> Config Class Initialized
INFO - 2018-03-05 07:39:14 --> Hooks Class Initialized
DEBUG - 2018-03-05 07:39:14 --> UTF-8 Support Enabled
INFO - 2018-03-05 07:39:14 --> Utf8 Class Initialized
INFO - 2018-03-05 07:39:14 --> URI Class Initialized
INFO - 2018-03-05 07:39:14 --> Router Class Initialized
INFO - 2018-03-05 07:39:14 --> Output Class Initialized
INFO - 2018-03-05 07:39:14 --> Security Class Initialized
DEBUG - 2018-03-05 07:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 07:39:14 --> Input Class Initialized
INFO - 2018-03-05 07:39:14 --> Language Class Initialized
ERROR - 2018-03-05 07:39:14 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-05 07:41:50 --> Database Driver Class Initialized
INFO - 2018-03-05 07:41:50 --> Config Class Initialized
INFO - 2018-03-05 07:41:50 --> Hooks Class Initialized
DEBUG - 2018-03-05 07:41:50 --> UTF-8 Support Enabled
INFO - 2018-03-05 07:41:50 --> Utf8 Class Initialized
INFO - 2018-03-05 07:41:50 --> URI Class Initialized
INFO - 2018-03-05 07:41:50 --> Router Class Initialized
INFO - 2018-03-05 07:41:50 --> Output Class Initialized
INFO - 2018-03-05 07:41:50 --> Security Class Initialized
DEBUG - 2018-03-05 07:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 07:41:50 --> Input Class Initialized
INFO - 2018-03-05 07:41:50 --> Language Class Initialized
ERROR - 2018-03-05 07:41:50 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-05 07:41:58 --> Database Driver Class Initialized
INFO - 2018-03-05 07:41:58 --> Config Class Initialized
INFO - 2018-03-05 07:41:58 --> Hooks Class Initialized
DEBUG - 2018-03-05 07:41:58 --> UTF-8 Support Enabled
INFO - 2018-03-05 07:41:58 --> Utf8 Class Initialized
INFO - 2018-03-05 07:41:58 --> URI Class Initialized
INFO - 2018-03-05 07:41:58 --> Router Class Initialized
INFO - 2018-03-05 07:41:58 --> Output Class Initialized
INFO - 2018-03-05 07:41:58 --> Security Class Initialized
DEBUG - 2018-03-05 07:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 07:41:58 --> Input Class Initialized
INFO - 2018-03-05 07:41:58 --> Language Class Initialized
ERROR - 2018-03-05 07:41:58 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-05 07:44:19 --> Database Driver Class Initialized
INFO - 2018-03-05 07:44:19 --> Config Class Initialized
INFO - 2018-03-05 07:44:19 --> Hooks Class Initialized
DEBUG - 2018-03-05 07:44:19 --> UTF-8 Support Enabled
INFO - 2018-03-05 07:44:19 --> Utf8 Class Initialized
INFO - 2018-03-05 07:44:19 --> URI Class Initialized
INFO - 2018-03-05 07:44:19 --> Router Class Initialized
INFO - 2018-03-05 07:44:19 --> Output Class Initialized
INFO - 2018-03-05 07:44:19 --> Security Class Initialized
DEBUG - 2018-03-05 07:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 07:44:19 --> Input Class Initialized
INFO - 2018-03-05 07:44:19 --> Language Class Initialized
ERROR - 2018-03-05 07:44:19 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-05 07:48:09 --> Database Driver Class Initialized
INFO - 2018-03-05 07:48:09 --> Config Class Initialized
INFO - 2018-03-05 07:48:09 --> Hooks Class Initialized
DEBUG - 2018-03-05 07:48:09 --> UTF-8 Support Enabled
INFO - 2018-03-05 07:48:09 --> Utf8 Class Initialized
INFO - 2018-03-05 07:48:09 --> URI Class Initialized
INFO - 2018-03-05 07:48:09 --> Router Class Initialized
INFO - 2018-03-05 07:48:09 --> Output Class Initialized
INFO - 2018-03-05 07:48:09 --> Security Class Initialized
DEBUG - 2018-03-05 07:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 07:48:09 --> Input Class Initialized
INFO - 2018-03-05 07:48:09 --> Language Class Initialized
ERROR - 2018-03-05 07:48:09 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-05 07:48:14 --> Database Driver Class Initialized
INFO - 2018-03-05 07:48:14 --> Config Class Initialized
INFO - 2018-03-05 07:48:14 --> Hooks Class Initialized
DEBUG - 2018-03-05 07:48:14 --> UTF-8 Support Enabled
INFO - 2018-03-05 07:48:14 --> Utf8 Class Initialized
INFO - 2018-03-05 07:48:14 --> URI Class Initialized
INFO - 2018-03-05 07:48:14 --> Router Class Initialized
INFO - 2018-03-05 07:48:14 --> Output Class Initialized
INFO - 2018-03-05 07:48:14 --> Security Class Initialized
DEBUG - 2018-03-05 07:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 07:48:14 --> Input Class Initialized
INFO - 2018-03-05 07:48:14 --> Language Class Initialized
ERROR - 2018-03-05 07:48:14 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-05 07:48:15 --> Database Driver Class Initialized
INFO - 2018-03-05 07:48:15 --> Config Class Initialized
INFO - 2018-03-05 07:48:15 --> Hooks Class Initialized
DEBUG - 2018-03-05 07:48:15 --> UTF-8 Support Enabled
INFO - 2018-03-05 07:48:15 --> Utf8 Class Initialized
INFO - 2018-03-05 07:48:15 --> URI Class Initialized
INFO - 2018-03-05 07:48:15 --> Router Class Initialized
INFO - 2018-03-05 07:48:15 --> Output Class Initialized
INFO - 2018-03-05 07:48:15 --> Security Class Initialized
DEBUG - 2018-03-05 07:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 07:48:15 --> Input Class Initialized
INFO - 2018-03-05 07:48:15 --> Language Class Initialized
ERROR - 2018-03-05 07:48:15 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-05 08:07:53 --> Database Driver Class Initialized
INFO - 2018-03-05 08:07:53 --> Config Class Initialized
INFO - 2018-03-05 08:07:53 --> Hooks Class Initialized
DEBUG - 2018-03-05 08:07:53 --> UTF-8 Support Enabled
INFO - 2018-03-05 08:07:53 --> Utf8 Class Initialized
INFO - 2018-03-05 08:07:53 --> URI Class Initialized
INFO - 2018-03-05 08:07:53 --> Router Class Initialized
INFO - 2018-03-05 08:07:53 --> Output Class Initialized
INFO - 2018-03-05 08:07:53 --> Security Class Initialized
DEBUG - 2018-03-05 08:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 08:07:53 --> Input Class Initialized
INFO - 2018-03-05 08:07:53 --> Language Class Initialized
INFO - 2018-03-05 08:07:53 --> Loader Class Initialized
INFO - 2018-03-05 08:07:53 --> Helper loaded: url_helper
INFO - 2018-03-05 08:07:53 --> Helper loaded: site_helper
INFO - 2018-03-05 08:07:53 --> Database Driver Class Initialized
INFO - 2018-03-05 08:07:53 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-05 08:07:53 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-05 08:07:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-05 08:07:53 --> Controller Class Initialized
INFO - 2018-03-05 08:07:53 --> Model "user_model" initialized
INFO - 2018-03-05 08:07:53 --> Model "site_model" initialized
INFO - 2018-03-05 08:07:53 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-05 08:07:53 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-05 08:07:53 --> Model "pm_model" initialized
INFO - 2018-03-05 08:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-05 08:07:54 --> Pagination Class Initialized
INFO - 2018-03-05 08:07:54 --> Model "premium_model" initialized
INFO - 2018-03-05 08:07:54 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/main_header.php
ERROR - 2018-03-05 08:07:54 --> Could not find the language line "coins_with_paypal"
ERROR - 2018-03-05 08:07:54 --> Could not find the language line "coins_with_stripe"
ERROR - 2018-03-05 08:07:54 --> Could not find the language line "not_enough_credits"
ERROR - 2018-03-05 08:07:54 --> Could not find the language line "take_it_btn"
ERROR - 2018-03-05 08:07:54 --> Could not find the language line "see_loves_success"
ERROR - 2018-03-05 08:07:54 --> Could not find the language line "invisible_success"
ERROR - 2018-03-05 08:07:54 --> Could not find the language line "featured_one_week_success"
ERROR - 2018-03-05 08:07:54 --> Could not find the language line "featured_one_month_success"
ERROR - 2018-03-05 08:07:54 --> Could not find the language line "send_reply_btn"
ERROR - 2018-03-05 08:07:54 --> Could not find the language line "write_something"
ERROR - 2018-03-05 08:07:54 --> Could not find the language line "conv_not_exist"
ERROR - 2018-03-05 08:07:54 --> Could not find the language line "write_something"
INFO - 2018-03-05 08:07:54 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/main_footer.php
INFO - 2018-03-05 08:07:54 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\site/home.php
INFO - 2018-03-05 08:07:54 --> Final output sent to browser
DEBUG - 2018-03-05 08:07:54 --> Total execution time: 0.4400
INFO - 2018-03-05 08:07:58 --> Database Driver Class Initialized
INFO - 2018-03-05 08:07:58 --> Config Class Initialized
INFO - 2018-03-05 08:07:58 --> Hooks Class Initialized
DEBUG - 2018-03-05 08:07:58 --> UTF-8 Support Enabled
INFO - 2018-03-05 08:07:58 --> Utf8 Class Initialized
INFO - 2018-03-05 08:07:58 --> URI Class Initialized
DEBUG - 2018-03-05 08:07:58 --> No URI present. Default controller set.
INFO - 2018-03-05 08:07:58 --> Router Class Initialized
INFO - 2018-03-05 08:07:58 --> Output Class Initialized
INFO - 2018-03-05 08:07:58 --> Security Class Initialized
DEBUG - 2018-03-05 08:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 08:07:58 --> Input Class Initialized
INFO - 2018-03-05 08:07:58 --> Language Class Initialized
INFO - 2018-03-05 08:07:58 --> Loader Class Initialized
INFO - 2018-03-05 08:07:58 --> Helper loaded: url_helper
INFO - 2018-03-05 08:07:58 --> Helper loaded: site_helper
INFO - 2018-03-05 08:07:58 --> Database Driver Class Initialized
INFO - 2018-03-05 08:07:58 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-05 08:07:58 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-05 08:07:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-05 08:07:58 --> Controller Class Initialized
INFO - 2018-03-05 08:07:58 --> User Agent Class Initialized
INFO - 2018-03-05 08:07:58 --> Model "site_model" initialized
INFO - 2018-03-05 08:07:58 --> Model "user_model" initialized
INFO - 2018-03-05 08:07:58 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-05 08:07:58 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-05 08:07:58 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-05 08:07:58 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-05 08:07:58 --> Final output sent to browser
DEBUG - 2018-03-05 08:07:58 --> Total execution time: 0.0475
INFO - 2018-03-05 08:08:01 --> Database Driver Class Initialized
INFO - 2018-03-05 08:08:01 --> Database Driver Class Initialized
INFO - 2018-03-05 08:08:01 --> Config Class Initialized
INFO - 2018-03-05 08:08:01 --> Hooks Class Initialized
DEBUG - 2018-03-05 08:08:01 --> UTF-8 Support Enabled
INFO - 2018-03-05 08:08:01 --> Config Class Initialized
INFO - 2018-03-05 08:08:01 --> Utf8 Class Initialized
INFO - 2018-03-05 08:08:01 --> Hooks Class Initialized
INFO - 2018-03-05 08:08:01 --> URI Class Initialized
DEBUG - 2018-03-05 08:08:01 --> UTF-8 Support Enabled
INFO - 2018-03-05 08:08:01 --> Router Class Initialized
INFO - 2018-03-05 08:08:01 --> Utf8 Class Initialized
INFO - 2018-03-05 08:08:01 --> URI Class Initialized
INFO - 2018-03-05 08:08:01 --> Output Class Initialized
INFO - 2018-03-05 08:08:01 --> Router Class Initialized
INFO - 2018-03-05 08:08:01 --> Security Class Initialized
INFO - 2018-03-05 08:08:01 --> Output Class Initialized
INFO - 2018-03-05 08:08:01 --> Security Class Initialized
DEBUG - 2018-03-05 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 08:08:01 --> Input Class Initialized
INFO - 2018-03-05 08:08:01 --> Language Class Initialized
DEBUG - 2018-03-05 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-05 08:08:01 --> Input Class Initialized
ERROR - 2018-03-05 08:08:01 --> 404 Page Not Found: Themes/latoo
INFO - 2018-03-05 08:08:01 --> Language Class Initialized
ERROR - 2018-03-05 08:08:01 --> 404 Page Not Found: Themes/latoo
