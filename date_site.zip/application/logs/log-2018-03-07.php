<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-07 13:07:08 --> Database Driver Class Initialized
INFO - 2018-03-07 13:07:08 --> Config Class Initialized
INFO - 2018-03-07 13:07:08 --> Hooks Class Initialized
DEBUG - 2018-03-07 13:07:08 --> UTF-8 Support Enabled
INFO - 2018-03-07 13:07:08 --> Utf8 Class Initialized
INFO - 2018-03-07 13:07:08 --> URI Class Initialized
DEBUG - 2018-03-07 13:07:08 --> No URI present. Default controller set.
INFO - 2018-03-07 13:07:08 --> Router Class Initialized
INFO - 2018-03-07 13:07:08 --> Output Class Initialized
INFO - 2018-03-07 13:07:08 --> Security Class Initialized
DEBUG - 2018-03-07 13:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 13:07:08 --> Input Class Initialized
INFO - 2018-03-07 13:07:08 --> Language Class Initialized
INFO - 2018-03-07 13:07:08 --> Loader Class Initialized
INFO - 2018-03-07 13:07:08 --> Helper loaded: url_helper
INFO - 2018-03-07 13:07:08 --> Helper loaded: site_helper
INFO - 2018-03-07 13:07:08 --> Database Driver Class Initialized
INFO - 2018-03-07 13:07:08 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-07 13:07:08 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-07 13:07:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 13:07:08 --> Controller Class Initialized
INFO - 2018-03-07 13:07:08 --> User Agent Class Initialized
INFO - 2018-03-07 13:07:08 --> Model "site_model" initialized
INFO - 2018-03-07 13:07:08 --> Model "user_model" initialized
INFO - 2018-03-07 13:07:08 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-07 13:07:09 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-07 13:07:09 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-07 13:07:09 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-07 13:07:09 --> Final output sent to browser
DEBUG - 2018-03-07 13:07:09 --> Total execution time: 0.7440
INFO - 2018-03-07 13:07:59 --> Database Driver Class Initialized
INFO - 2018-03-07 13:07:59 --> Config Class Initialized
INFO - 2018-03-07 13:07:59 --> Hooks Class Initialized
DEBUG - 2018-03-07 13:07:59 --> UTF-8 Support Enabled
INFO - 2018-03-07 13:07:59 --> Utf8 Class Initialized
INFO - 2018-03-07 13:07:59 --> URI Class Initialized
DEBUG - 2018-03-07 13:07:59 --> No URI present. Default controller set.
INFO - 2018-03-07 13:07:59 --> Router Class Initialized
INFO - 2018-03-07 13:07:59 --> Output Class Initialized
INFO - 2018-03-07 13:07:59 --> Security Class Initialized
DEBUG - 2018-03-07 13:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 13:07:59 --> Input Class Initialized
INFO - 2018-03-07 13:07:59 --> Language Class Initialized
INFO - 2018-03-07 13:07:59 --> Loader Class Initialized
INFO - 2018-03-07 13:07:59 --> Helper loaded: url_helper
INFO - 2018-03-07 13:07:59 --> Helper loaded: site_helper
INFO - 2018-03-07 13:07:59 --> Database Driver Class Initialized
INFO - 2018-03-07 13:07:59 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-07 13:07:59 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-07 13:07:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 13:07:59 --> Controller Class Initialized
INFO - 2018-03-07 13:07:59 --> User Agent Class Initialized
INFO - 2018-03-07 13:07:59 --> Model "site_model" initialized
INFO - 2018-03-07 13:07:59 --> Model "user_model" initialized
INFO - 2018-03-07 13:07:59 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-07 13:07:59 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-07 13:07:59 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-07 13:07:59 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-07 13:07:59 --> Final output sent to browser
DEBUG - 2018-03-07 13:07:59 --> Total execution time: 0.0560
INFO - 2018-03-07 13:08:16 --> Database Driver Class Initialized
INFO - 2018-03-07 13:08:16 --> Config Class Initialized
INFO - 2018-03-07 13:08:16 --> Hooks Class Initialized
DEBUG - 2018-03-07 13:08:16 --> UTF-8 Support Enabled
INFO - 2018-03-07 13:08:16 --> Utf8 Class Initialized
INFO - 2018-03-07 13:08:16 --> URI Class Initialized
DEBUG - 2018-03-07 13:08:16 --> No URI present. Default controller set.
INFO - 2018-03-07 13:08:16 --> Router Class Initialized
INFO - 2018-03-07 13:08:16 --> Output Class Initialized
INFO - 2018-03-07 13:08:16 --> Security Class Initialized
DEBUG - 2018-03-07 13:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 13:08:16 --> Input Class Initialized
INFO - 2018-03-07 13:08:16 --> Language Class Initialized
INFO - 2018-03-07 13:08:16 --> Loader Class Initialized
INFO - 2018-03-07 13:08:16 --> Helper loaded: url_helper
INFO - 2018-03-07 13:08:16 --> Helper loaded: site_helper
INFO - 2018-03-07 13:08:16 --> Database Driver Class Initialized
INFO - 2018-03-07 13:08:16 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-07 13:08:16 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-07 13:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 13:08:16 --> Controller Class Initialized
INFO - 2018-03-07 13:08:16 --> User Agent Class Initialized
INFO - 2018-03-07 13:08:16 --> Model "site_model" initialized
INFO - 2018-03-07 13:08:16 --> Model "user_model" initialized
INFO - 2018-03-07 13:08:16 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-07 13:08:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-07 13:08:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-07 13:08:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-07 13:08:16 --> Final output sent to browser
DEBUG - 2018-03-07 13:08:16 --> Total execution time: 0.0400
INFO - 2018-03-07 13:50:40 --> Database Driver Class Initialized
INFO - 2018-03-07 13:50:40 --> Config Class Initialized
INFO - 2018-03-07 13:50:40 --> Hooks Class Initialized
DEBUG - 2018-03-07 13:50:40 --> UTF-8 Support Enabled
INFO - 2018-03-07 13:50:40 --> Utf8 Class Initialized
INFO - 2018-03-07 13:50:40 --> URI Class Initialized
DEBUG - 2018-03-07 13:50:40 --> No URI present. Default controller set.
INFO - 2018-03-07 13:50:40 --> Router Class Initialized
INFO - 2018-03-07 13:50:40 --> Output Class Initialized
INFO - 2018-03-07 13:50:40 --> Security Class Initialized
DEBUG - 2018-03-07 13:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 13:50:40 --> Input Class Initialized
INFO - 2018-03-07 13:50:40 --> Language Class Initialized
INFO - 2018-03-07 13:50:41 --> Loader Class Initialized
INFO - 2018-03-07 13:50:41 --> Helper loaded: url_helper
INFO - 2018-03-07 13:50:41 --> Helper loaded: site_helper
INFO - 2018-03-07 13:50:41 --> Database Driver Class Initialized
INFO - 2018-03-07 13:50:41 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-07 13:50:41 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-07 13:50:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 13:50:41 --> Controller Class Initialized
INFO - 2018-03-07 13:50:41 --> User Agent Class Initialized
INFO - 2018-03-07 13:50:41 --> Model "site_model" initialized
INFO - 2018-03-07 13:50:41 --> Model "user_model" initialized
INFO - 2018-03-07 13:50:41 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-07 13:50:41 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-07 13:50:41 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-07 13:50:41 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-07 13:50:41 --> Final output sent to browser
DEBUG - 2018-03-07 13:50:41 --> Total execution time: 0.0710
INFO - 2018-03-07 13:51:10 --> Database Driver Class Initialized
INFO - 2018-03-07 13:51:10 --> Config Class Initialized
INFO - 2018-03-07 13:51:10 --> Hooks Class Initialized
DEBUG - 2018-03-07 13:51:10 --> UTF-8 Support Enabled
INFO - 2018-03-07 13:51:10 --> Utf8 Class Initialized
INFO - 2018-03-07 13:51:10 --> URI Class Initialized
DEBUG - 2018-03-07 13:51:10 --> No URI present. Default controller set.
INFO - 2018-03-07 13:51:10 --> Router Class Initialized
INFO - 2018-03-07 13:51:10 --> Output Class Initialized
INFO - 2018-03-07 13:51:10 --> Security Class Initialized
DEBUG - 2018-03-07 13:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 13:51:10 --> Input Class Initialized
INFO - 2018-03-07 13:51:10 --> Language Class Initialized
INFO - 2018-03-07 13:51:10 --> Loader Class Initialized
INFO - 2018-03-07 13:51:10 --> Helper loaded: url_helper
INFO - 2018-03-07 13:51:10 --> Helper loaded: site_helper
INFO - 2018-03-07 13:51:10 --> Database Driver Class Initialized
INFO - 2018-03-07 13:51:10 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-07 13:51:10 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-07 13:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 13:51:10 --> Controller Class Initialized
INFO - 2018-03-07 13:51:10 --> User Agent Class Initialized
INFO - 2018-03-07 13:51:11 --> Model "site_model" initialized
INFO - 2018-03-07 13:51:11 --> Model "user_model" initialized
INFO - 2018-03-07 13:51:11 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-07 13:51:11 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-07 13:51:11 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-07 13:51:11 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-07 13:51:11 --> Final output sent to browser
DEBUG - 2018-03-07 13:51:11 --> Total execution time: 0.0870
INFO - 2018-03-07 13:51:13 --> Database Driver Class Initialized
INFO - 2018-03-07 13:51:13 --> Config Class Initialized
INFO - 2018-03-07 13:51:13 --> Hooks Class Initialized
DEBUG - 2018-03-07 13:51:13 --> UTF-8 Support Enabled
INFO - 2018-03-07 13:51:13 --> Utf8 Class Initialized
INFO - 2018-03-07 13:51:13 --> URI Class Initialized
INFO - 2018-03-07 13:51:13 --> Router Class Initialized
INFO - 2018-03-07 13:51:13 --> Output Class Initialized
INFO - 2018-03-07 13:51:13 --> Security Class Initialized
DEBUG - 2018-03-07 13:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 13:51:13 --> Input Class Initialized
INFO - 2018-03-07 13:51:13 --> Language Class Initialized
ERROR - 2018-03-07 13:51:13 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-07 13:51:27 --> Database Driver Class Initialized
INFO - 2018-03-07 13:51:27 --> Config Class Initialized
INFO - 2018-03-07 13:51:27 --> Hooks Class Initialized
DEBUG - 2018-03-07 13:51:27 --> UTF-8 Support Enabled
INFO - 2018-03-07 13:51:27 --> Utf8 Class Initialized
INFO - 2018-03-07 13:51:27 --> URI Class Initialized
DEBUG - 2018-03-07 13:51:27 --> No URI present. Default controller set.
INFO - 2018-03-07 13:51:27 --> Router Class Initialized
INFO - 2018-03-07 13:51:27 --> Output Class Initialized
INFO - 2018-03-07 13:51:27 --> Security Class Initialized
DEBUG - 2018-03-07 13:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 13:51:27 --> Input Class Initialized
INFO - 2018-03-07 13:51:27 --> Language Class Initialized
INFO - 2018-03-07 13:51:27 --> Loader Class Initialized
INFO - 2018-03-07 13:51:27 --> Helper loaded: url_helper
INFO - 2018-03-07 13:51:27 --> Helper loaded: site_helper
INFO - 2018-03-07 13:51:27 --> Database Driver Class Initialized
INFO - 2018-03-07 13:51:27 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-07 13:51:27 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-07 13:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 13:51:27 --> Controller Class Initialized
INFO - 2018-03-07 13:51:27 --> User Agent Class Initialized
INFO - 2018-03-07 13:51:27 --> Model "site_model" initialized
INFO - 2018-03-07 13:51:27 --> Model "user_model" initialized
INFO - 2018-03-07 13:51:27 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-07 13:51:27 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-07 13:51:27 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-07 13:51:27 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-07 13:51:27 --> Final output sent to browser
DEBUG - 2018-03-07 13:51:27 --> Total execution time: 0.0450
INFO - 2018-03-07 13:51:34 --> Database Driver Class Initialized
INFO - 2018-03-07 13:51:34 --> Config Class Initialized
INFO - 2018-03-07 13:51:34 --> Hooks Class Initialized
DEBUG - 2018-03-07 13:51:34 --> UTF-8 Support Enabled
INFO - 2018-03-07 13:51:34 --> Utf8 Class Initialized
INFO - 2018-03-07 13:51:34 --> URI Class Initialized
INFO - 2018-03-07 13:51:34 --> Router Class Initialized
INFO - 2018-03-07 13:51:34 --> Output Class Initialized
INFO - 2018-03-07 13:51:34 --> Security Class Initialized
DEBUG - 2018-03-07 13:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 13:51:34 --> Input Class Initialized
INFO - 2018-03-07 13:51:34 --> Language Class Initialized
ERROR - 2018-03-07 13:51:34 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-07 13:51:39 --> Database Driver Class Initialized
INFO - 2018-03-07 13:51:39 --> Config Class Initialized
INFO - 2018-03-07 13:51:39 --> Hooks Class Initialized
DEBUG - 2018-03-07 13:51:39 --> UTF-8 Support Enabled
INFO - 2018-03-07 13:51:39 --> Utf8 Class Initialized
INFO - 2018-03-07 13:51:39 --> URI Class Initialized
DEBUG - 2018-03-07 13:51:39 --> No URI present. Default controller set.
INFO - 2018-03-07 13:51:39 --> Router Class Initialized
INFO - 2018-03-07 13:51:39 --> Output Class Initialized
INFO - 2018-03-07 13:51:39 --> Security Class Initialized
DEBUG - 2018-03-07 13:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 13:51:39 --> Input Class Initialized
INFO - 2018-03-07 13:51:39 --> Language Class Initialized
INFO - 2018-03-07 13:51:39 --> Loader Class Initialized
INFO - 2018-03-07 13:51:39 --> Helper loaded: url_helper
INFO - 2018-03-07 13:51:39 --> Helper loaded: site_helper
INFO - 2018-03-07 13:51:39 --> Database Driver Class Initialized
INFO - 2018-03-07 13:51:39 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-07 13:51:39 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-07 13:51:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 13:51:39 --> Controller Class Initialized
INFO - 2018-03-07 13:51:39 --> User Agent Class Initialized
INFO - 2018-03-07 13:51:39 --> Model "site_model" initialized
INFO - 2018-03-07 13:51:39 --> Model "user_model" initialized
INFO - 2018-03-07 13:51:39 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-07 13:51:39 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-07 13:51:39 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-07 13:51:39 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-07 13:51:39 --> Final output sent to browser
DEBUG - 2018-03-07 13:51:39 --> Total execution time: 0.0520
INFO - 2018-03-07 13:51:42 --> Database Driver Class Initialized
INFO - 2018-03-07 13:51:42 --> Config Class Initialized
INFO - 2018-03-07 13:51:42 --> Hooks Class Initialized
DEBUG - 2018-03-07 13:51:42 --> UTF-8 Support Enabled
INFO - 2018-03-07 13:51:42 --> Utf8 Class Initialized
INFO - 2018-03-07 13:51:42 --> URI Class Initialized
INFO - 2018-03-07 13:51:42 --> Router Class Initialized
INFO - 2018-03-07 13:51:42 --> Output Class Initialized
INFO - 2018-03-07 13:51:42 --> Security Class Initialized
DEBUG - 2018-03-07 13:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 13:51:42 --> Input Class Initialized
INFO - 2018-03-07 13:51:42 --> Language Class Initialized
ERROR - 2018-03-07 13:51:42 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-07 13:51:43 --> Database Driver Class Initialized
INFO - 2018-03-07 13:51:43 --> Config Class Initialized
INFO - 2018-03-07 13:51:43 --> Hooks Class Initialized
DEBUG - 2018-03-07 13:51:43 --> UTF-8 Support Enabled
INFO - 2018-03-07 13:51:43 --> Utf8 Class Initialized
INFO - 2018-03-07 13:51:43 --> URI Class Initialized
INFO - 2018-03-07 13:51:43 --> Router Class Initialized
INFO - 2018-03-07 13:51:43 --> Output Class Initialized
INFO - 2018-03-07 13:51:43 --> Security Class Initialized
DEBUG - 2018-03-07 13:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 13:51:43 --> Input Class Initialized
INFO - 2018-03-07 13:51:43 --> Language Class Initialized
ERROR - 2018-03-07 13:51:43 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-07 13:51:44 --> Database Driver Class Initialized
INFO - 2018-03-07 13:51:44 --> Config Class Initialized
INFO - 2018-03-07 13:51:44 --> Hooks Class Initialized
DEBUG - 2018-03-07 13:51:44 --> UTF-8 Support Enabled
INFO - 2018-03-07 13:51:44 --> Utf8 Class Initialized
INFO - 2018-03-07 13:51:44 --> URI Class Initialized
DEBUG - 2018-03-07 13:51:44 --> No URI present. Default controller set.
INFO - 2018-03-07 13:51:44 --> Router Class Initialized
INFO - 2018-03-07 13:51:44 --> Output Class Initialized
INFO - 2018-03-07 13:51:44 --> Security Class Initialized
DEBUG - 2018-03-07 13:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 13:51:44 --> Input Class Initialized
INFO - 2018-03-07 13:51:44 --> Language Class Initialized
INFO - 2018-03-07 13:51:44 --> Loader Class Initialized
INFO - 2018-03-07 13:51:44 --> Helper loaded: url_helper
INFO - 2018-03-07 13:51:44 --> Helper loaded: site_helper
INFO - 2018-03-07 13:51:44 --> Database Driver Class Initialized
INFO - 2018-03-07 13:51:44 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-07 13:51:44 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-07 13:51:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 13:51:44 --> Controller Class Initialized
INFO - 2018-03-07 13:51:44 --> User Agent Class Initialized
INFO - 2018-03-07 13:51:44 --> Model "site_model" initialized
INFO - 2018-03-07 13:51:44 --> Model "user_model" initialized
INFO - 2018-03-07 13:51:44 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-07 13:51:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-07 13:51:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-07 13:51:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-07 13:51:44 --> Final output sent to browser
DEBUG - 2018-03-07 13:51:44 --> Total execution time: 0.0460
INFO - 2018-03-07 13:51:45 --> Database Driver Class Initialized
INFO - 2018-03-07 13:51:45 --> Config Class Initialized
INFO - 2018-03-07 13:51:45 --> Hooks Class Initialized
DEBUG - 2018-03-07 13:51:45 --> UTF-8 Support Enabled
INFO - 2018-03-07 13:51:45 --> Utf8 Class Initialized
INFO - 2018-03-07 13:51:45 --> URI Class Initialized
DEBUG - 2018-03-07 13:51:45 --> No URI present. Default controller set.
INFO - 2018-03-07 13:51:45 --> Router Class Initialized
INFO - 2018-03-07 13:51:45 --> Output Class Initialized
INFO - 2018-03-07 13:51:45 --> Security Class Initialized
DEBUG - 2018-03-07 13:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 13:51:45 --> Input Class Initialized
INFO - 2018-03-07 13:51:45 --> Language Class Initialized
INFO - 2018-03-07 13:51:45 --> Loader Class Initialized
INFO - 2018-03-07 13:51:45 --> Helper loaded: url_helper
INFO - 2018-03-07 13:51:45 --> Helper loaded: site_helper
INFO - 2018-03-07 13:51:45 --> Database Driver Class Initialized
INFO - 2018-03-07 13:51:45 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-07 13:51:46 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-07 13:51:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 13:51:46 --> Controller Class Initialized
INFO - 2018-03-07 13:51:46 --> User Agent Class Initialized
INFO - 2018-03-07 13:51:46 --> Model "site_model" initialized
INFO - 2018-03-07 13:51:46 --> Model "user_model" initialized
INFO - 2018-03-07 13:51:46 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-07 13:51:46 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-07 13:51:46 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-07 13:51:46 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-07 13:51:46 --> Final output sent to browser
DEBUG - 2018-03-07 13:51:46 --> Total execution time: 0.1090
INFO - 2018-03-07 13:51:48 --> Database Driver Class Initialized
INFO - 2018-03-07 13:51:48 --> Config Class Initialized
INFO - 2018-03-07 13:51:48 --> Hooks Class Initialized
DEBUG - 2018-03-07 13:51:48 --> UTF-8 Support Enabled
INFO - 2018-03-07 13:51:48 --> Utf8 Class Initialized
INFO - 2018-03-07 13:51:48 --> URI Class Initialized
INFO - 2018-03-07 13:51:48 --> Router Class Initialized
INFO - 2018-03-07 13:51:48 --> Output Class Initialized
INFO - 2018-03-07 13:51:48 --> Security Class Initialized
DEBUG - 2018-03-07 13:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 13:51:48 --> Input Class Initialized
INFO - 2018-03-07 13:51:48 --> Language Class Initialized
ERROR - 2018-03-07 13:51:48 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-07 13:52:37 --> Database Driver Class Initialized
INFO - 2018-03-07 13:52:37 --> Config Class Initialized
INFO - 2018-03-07 13:52:37 --> Hooks Class Initialized
DEBUG - 2018-03-07 13:52:37 --> UTF-8 Support Enabled
INFO - 2018-03-07 13:52:37 --> Utf8 Class Initialized
INFO - 2018-03-07 13:52:37 --> URI Class Initialized
DEBUG - 2018-03-07 13:52:37 --> No URI present. Default controller set.
INFO - 2018-03-07 13:52:37 --> Router Class Initialized
INFO - 2018-03-07 13:52:37 --> Output Class Initialized
INFO - 2018-03-07 13:52:37 --> Security Class Initialized
DEBUG - 2018-03-07 13:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 13:52:37 --> Input Class Initialized
INFO - 2018-03-07 13:52:37 --> Language Class Initialized
INFO - 2018-03-07 13:52:37 --> Loader Class Initialized
INFO - 2018-03-07 13:52:37 --> Helper loaded: url_helper
INFO - 2018-03-07 13:52:37 --> Helper loaded: site_helper
INFO - 2018-03-07 13:52:37 --> Database Driver Class Initialized
INFO - 2018-03-07 13:52:37 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-07 13:52:37 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-07 13:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 13:52:37 --> Controller Class Initialized
INFO - 2018-03-07 13:52:37 --> User Agent Class Initialized
INFO - 2018-03-07 13:52:37 --> Model "site_model" initialized
INFO - 2018-03-07 13:52:37 --> Model "user_model" initialized
INFO - 2018-03-07 13:52:37 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-07 13:52:37 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-07 13:52:37 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-07 13:52:37 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-07 13:52:37 --> Final output sent to browser
DEBUG - 2018-03-07 13:52:37 --> Total execution time: 0.0440
INFO - 2018-03-07 14:13:03 --> Database Driver Class Initialized
INFO - 2018-03-07 14:13:03 --> Config Class Initialized
INFO - 2018-03-07 14:13:03 --> Hooks Class Initialized
DEBUG - 2018-03-07 14:13:03 --> UTF-8 Support Enabled
INFO - 2018-03-07 14:13:03 --> Utf8 Class Initialized
INFO - 2018-03-07 14:13:03 --> URI Class Initialized
DEBUG - 2018-03-07 14:13:03 --> No URI present. Default controller set.
INFO - 2018-03-07 14:13:03 --> Router Class Initialized
INFO - 2018-03-07 14:13:03 --> Output Class Initialized
INFO - 2018-03-07 14:13:03 --> Security Class Initialized
DEBUG - 2018-03-07 14:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 14:13:03 --> Input Class Initialized
INFO - 2018-03-07 14:13:03 --> Language Class Initialized
INFO - 2018-03-07 14:13:04 --> Loader Class Initialized
INFO - 2018-03-07 14:13:04 --> Helper loaded: url_helper
INFO - 2018-03-07 14:13:04 --> Helper loaded: site_helper
INFO - 2018-03-07 14:13:04 --> Database Driver Class Initialized
INFO - 2018-03-07 14:13:04 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-07 14:13:04 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-07 14:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 14:13:04 --> Controller Class Initialized
INFO - 2018-03-07 14:13:04 --> User Agent Class Initialized
INFO - 2018-03-07 14:13:04 --> Model "site_model" initialized
INFO - 2018-03-07 14:13:04 --> Model "user_model" initialized
INFO - 2018-03-07 14:13:04 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-07 14:13:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-07 14:13:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-07 14:13:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-07 14:13:04 --> Final output sent to browser
DEBUG - 2018-03-07 14:13:04 --> Total execution time: 0.0550
INFO - 2018-03-07 14:13:07 --> Database Driver Class Initialized
INFO - 2018-03-07 14:13:07 --> Config Class Initialized
INFO - 2018-03-07 14:13:07 --> Hooks Class Initialized
DEBUG - 2018-03-07 14:13:07 --> UTF-8 Support Enabled
INFO - 2018-03-07 14:13:07 --> Utf8 Class Initialized
INFO - 2018-03-07 14:13:07 --> URI Class Initialized
INFO - 2018-03-07 14:13:07 --> Router Class Initialized
INFO - 2018-03-07 14:13:07 --> Output Class Initialized
INFO - 2018-03-07 14:13:07 --> Security Class Initialized
DEBUG - 2018-03-07 14:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 14:13:07 --> Input Class Initialized
INFO - 2018-03-07 14:13:07 --> Language Class Initialized
ERROR - 2018-03-07 14:13:07 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-07 14:13:10 --> Database Driver Class Initialized
INFO - 2018-03-07 14:13:10 --> Config Class Initialized
INFO - 2018-03-07 14:13:10 --> Hooks Class Initialized
DEBUG - 2018-03-07 14:13:10 --> UTF-8 Support Enabled
INFO - 2018-03-07 14:13:10 --> Utf8 Class Initialized
INFO - 2018-03-07 14:13:10 --> URI Class Initialized
INFO - 2018-03-07 14:13:10 --> Router Class Initialized
INFO - 2018-03-07 14:13:10 --> Output Class Initialized
INFO - 2018-03-07 14:13:10 --> Security Class Initialized
DEBUG - 2018-03-07 14:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 14:13:10 --> Input Class Initialized
INFO - 2018-03-07 14:13:10 --> Language Class Initialized
ERROR - 2018-03-07 14:13:10 --> Severity: error --> Exception: syntax error, unexpected 'private' (T_PRIVATE), expecting end of file D:\xampp\htdocs\myteenmatch\application\controllers\User.php 2421
INFO - 2018-03-07 14:13:56 --> Database Driver Class Initialized
INFO - 2018-03-07 14:13:56 --> Config Class Initialized
INFO - 2018-03-07 14:13:56 --> Hooks Class Initialized
DEBUG - 2018-03-07 14:13:56 --> UTF-8 Support Enabled
INFO - 2018-03-07 14:13:56 --> Utf8 Class Initialized
INFO - 2018-03-07 14:13:56 --> URI Class Initialized
DEBUG - 2018-03-07 14:13:56 --> No URI present. Default controller set.
INFO - 2018-03-07 14:13:56 --> Router Class Initialized
INFO - 2018-03-07 14:13:56 --> Output Class Initialized
INFO - 2018-03-07 14:13:56 --> Security Class Initialized
DEBUG - 2018-03-07 14:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 14:13:56 --> Input Class Initialized
INFO - 2018-03-07 14:13:56 --> Language Class Initialized
INFO - 2018-03-07 14:13:56 --> Loader Class Initialized
INFO - 2018-03-07 14:13:56 --> Helper loaded: url_helper
INFO - 2018-03-07 14:13:56 --> Helper loaded: site_helper
INFO - 2018-03-07 14:13:56 --> Database Driver Class Initialized
INFO - 2018-03-07 14:13:56 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-07 14:13:56 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-07 14:13:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 14:13:56 --> Controller Class Initialized
INFO - 2018-03-07 14:13:56 --> User Agent Class Initialized
INFO - 2018-03-07 14:13:56 --> Model "site_model" initialized
INFO - 2018-03-07 14:13:56 --> Model "user_model" initialized
INFO - 2018-03-07 14:13:56 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-07 14:13:56 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-07 14:13:56 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-07 14:13:56 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-07 14:13:56 --> Final output sent to browser
DEBUG - 2018-03-07 14:13:56 --> Total execution time: 0.0460
