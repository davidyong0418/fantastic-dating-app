<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>


INFO - 2018-03-10 14:36:52 --> Database Driver Class Initialized
ERROR - 2018-03-10 14:36:52 --> Query error: Table 'okdate.admin' doesn't exist - Invalid query: SELECT `online_delay`
FROM `admin`
 LIMIT 1
INFO - 2018-03-10 14:36:52 --> Language Class Initialized
INFO - 2018-03-10 14:38:28 --> Database Driver Class Initialized
INFO - 2018-03-10 14:38:28 --> Config Class Initialized
INFO - 2018-03-10 14:38:28 --> Hooks Class Initialized
DEBUG - 2018-03-10 14:38:28 --> UTF-8 Support Enabled
INFO - 2018-03-10 14:38:28 --> Utf8 Class Initialized
INFO - 2018-03-10 14:38:28 --> URI Class Initialized
DEBUG - 2018-03-10 14:38:28 --> No URI present. Default controller set.
INFO - 2018-03-10 14:38:28 --> Router Class Initialized
INFO - 2018-03-10 14:38:28 --> Output Class Initialized
INFO - 2018-03-10 14:38:28 --> Security Class Initialized
DEBUG - 2018-03-10 14:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 14:38:28 --> Input Class Initialized
INFO - 2018-03-10 14:38:28 --> Language Class Initialized
INFO - 2018-03-10 14:38:28 --> Loader Class Initialized
INFO - 2018-03-10 14:38:28 --> Helper loaded: url_helper
INFO - 2018-03-10 14:38:28 --> Helper loaded: site_helper
INFO - 2018-03-10 14:38:28 --> Database Driver Class Initialized
INFO - 2018-03-10 14:38:28 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 14:38:28 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 14:38:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 14:38:28 --> Controller Class Initialized
INFO - 2018-03-10 14:38:28 --> User Agent Class Initialized
INFO - 2018-03-10 14:38:28 --> Model "site_model" initialized
INFO - 2018-03-10 14:38:28 --> Model "user_model" initialized
INFO - 2018-03-10 14:38:28 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 14:38:28 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 14:38:28 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 14:38:28 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 14:38:28 --> Final output sent to browser
DEBUG - 2018-03-10 14:38:28 --> Total execution time: 0.0610
INFO - 2018-03-10 15:39:40 --> Database Driver Class Initialized
INFO - 2018-03-10 15:39:40 --> Config Class Initialized
INFO - 2018-03-10 15:39:40 --> Hooks Class Initialized
DEBUG - 2018-03-10 15:39:40 --> UTF-8 Support Enabled
INFO - 2018-03-10 15:39:40 --> Utf8 Class Initialized
INFO - 2018-03-10 15:39:40 --> URI Class Initialized
DEBUG - 2018-03-10 15:39:40 --> No URI present. Default controller set.
INFO - 2018-03-10 15:39:40 --> Router Class Initialized
INFO - 2018-03-10 15:39:40 --> Output Class Initialized
INFO - 2018-03-10 15:39:40 --> Security Class Initialized
DEBUG - 2018-03-10 15:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 15:39:40 --> Input Class Initialized
INFO - 2018-03-10 15:39:40 --> Language Class Initialized
INFO - 2018-03-10 15:39:40 --> Loader Class Initialized
INFO - 2018-03-10 15:39:40 --> Helper loaded: url_helper
INFO - 2018-03-10 15:39:40 --> Helper loaded: site_helper
INFO - 2018-03-10 15:39:40 --> Database Driver Class Initialized
INFO - 2018-03-10 15:39:40 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 15:39:40 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 15:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 15:39:40 --> Controller Class Initialized
INFO - 2018-03-10 15:39:40 --> User Agent Class Initialized
INFO - 2018-03-10 15:39:40 --> Model "site_model" initialized
INFO - 2018-03-10 15:39:40 --> Model "user_model" initialized
INFO - 2018-03-10 15:39:40 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 15:39:40 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 15:39:40 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 15:39:40 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 15:39:40 --> Final output sent to browser
DEBUG - 2018-03-10 15:39:40 --> Total execution time: 0.0444
INFO - 2018-03-10 15:40:02 --> Database Driver Class Initialized
INFO - 2018-03-10 15:40:02 --> Config Class Initialized
INFO - 2018-03-10 15:40:02 --> Hooks Class Initialized
DEBUG - 2018-03-10 15:40:02 --> UTF-8 Support Enabled
INFO - 2018-03-10 15:40:02 --> Utf8 Class Initialized
INFO - 2018-03-10 15:40:02 --> URI Class Initialized
DEBUG - 2018-03-10 15:40:02 --> No URI present. Default controller set.
INFO - 2018-03-10 15:40:02 --> Router Class Initialized
INFO - 2018-03-10 15:40:02 --> Output Class Initialized
INFO - 2018-03-10 15:40:02 --> Security Class Initialized
DEBUG - 2018-03-10 15:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 15:40:02 --> Input Class Initialized
INFO - 2018-03-10 15:40:02 --> Language Class Initialized
INFO - 2018-03-10 15:40:02 --> Loader Class Initialized
INFO - 2018-03-10 15:40:02 --> Helper loaded: url_helper
INFO - 2018-03-10 15:40:02 --> Helper loaded: site_helper
INFO - 2018-03-10 15:40:02 --> Database Driver Class Initialized
INFO - 2018-03-10 15:40:02 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 15:40:02 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 15:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 15:40:02 --> Controller Class Initialized
INFO - 2018-03-10 15:40:02 --> User Agent Class Initialized
INFO - 2018-03-10 15:40:02 --> Model "site_model" initialized
INFO - 2018-03-10 15:40:02 --> Model "user_model" initialized
INFO - 2018-03-10 15:40:02 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 15:40:03 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 15:40:03 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 15:40:03 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 15:40:03 --> Final output sent to browser
DEBUG - 2018-03-10 15:40:03 --> Total execution time: 0.0409
INFO - 2018-03-10 15:46:53 --> Database Driver Class Initialized
INFO - 2018-03-10 15:46:53 --> Config Class Initialized
INFO - 2018-03-10 15:46:53 --> Hooks Class Initialized
DEBUG - 2018-03-10 15:46:53 --> UTF-8 Support Enabled
INFO - 2018-03-10 15:46:53 --> Utf8 Class Initialized
INFO - 2018-03-10 15:46:53 --> URI Class Initialized
DEBUG - 2018-03-10 15:46:53 --> No URI present. Default controller set.
INFO - 2018-03-10 15:46:53 --> Router Class Initialized
INFO - 2018-03-10 15:46:53 --> Output Class Initialized
INFO - 2018-03-10 15:46:53 --> Security Class Initialized
DEBUG - 2018-03-10 15:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 15:46:53 --> Input Class Initialized
INFO - 2018-03-10 15:46:53 --> Language Class Initialized
INFO - 2018-03-10 15:46:53 --> Loader Class Initialized
INFO - 2018-03-10 15:46:53 --> Helper loaded: url_helper
INFO - 2018-03-10 15:46:53 --> Helper loaded: site_helper
INFO - 2018-03-10 15:46:53 --> Database Driver Class Initialized
INFO - 2018-03-10 15:46:53 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 15:46:53 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 15:46:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 15:46:53 --> Controller Class Initialized
INFO - 2018-03-10 15:46:53 --> User Agent Class Initialized
INFO - 2018-03-10 15:46:53 --> Model "site_model" initialized
INFO - 2018-03-10 15:46:53 --> Model "user_model" initialized
INFO - 2018-03-10 15:46:53 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 15:46:53 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 15:46:53 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 15:46:53 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 15:46:53 --> Final output sent to browser
DEBUG - 2018-03-10 15:46:53 --> Total execution time: 0.0412
INFO - 2018-03-10 15:51:30 --> Database Driver Class Initialized
INFO - 2018-03-10 15:51:30 --> Config Class Initialized
INFO - 2018-03-10 15:51:30 --> Hooks Class Initialized
DEBUG - 2018-03-10 15:51:30 --> UTF-8 Support Enabled
INFO - 2018-03-10 15:51:30 --> Utf8 Class Initialized
INFO - 2018-03-10 15:51:30 --> URI Class Initialized
DEBUG - 2018-03-10 15:51:30 --> No URI present. Default controller set.
INFO - 2018-03-10 15:51:30 --> Router Class Initialized
INFO - 2018-03-10 15:51:30 --> Output Class Initialized
INFO - 2018-03-10 15:51:30 --> Security Class Initialized
DEBUG - 2018-03-10 15:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 15:51:30 --> Input Class Initialized
INFO - 2018-03-10 15:51:30 --> Language Class Initialized
INFO - 2018-03-10 15:51:30 --> Loader Class Initialized
INFO - 2018-03-10 15:51:30 --> Helper loaded: url_helper
INFO - 2018-03-10 15:51:30 --> Helper loaded: site_helper
INFO - 2018-03-10 15:51:30 --> Database Driver Class Initialized
INFO - 2018-03-10 15:51:30 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 15:51:30 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 15:51:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 15:51:30 --> Controller Class Initialized
INFO - 2018-03-10 15:51:30 --> User Agent Class Initialized
INFO - 2018-03-10 15:51:30 --> Model "site_model" initialized
INFO - 2018-03-10 15:51:30 --> Model "user_model" initialized
INFO - 2018-03-10 15:51:30 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 15:51:30 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 15:51:30 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 15:51:30 --> Final output sent to browser
DEBUG - 2018-03-10 15:51:30 --> Total execution time: 0.0247
INFO - 2018-03-10 15:51:49 --> Database Driver Class Initialized
INFO - 2018-03-10 15:51:49 --> Config Class Initialized
INFO - 2018-03-10 15:51:49 --> Hooks Class Initialized
DEBUG - 2018-03-10 15:51:49 --> UTF-8 Support Enabled
INFO - 2018-03-10 15:51:49 --> Utf8 Class Initialized
INFO - 2018-03-10 15:51:49 --> URI Class Initialized
DEBUG - 2018-03-10 15:51:49 --> No URI present. Default controller set.
INFO - 2018-03-10 15:51:49 --> Router Class Initialized
INFO - 2018-03-10 15:51:49 --> Output Class Initialized
INFO - 2018-03-10 15:51:49 --> Security Class Initialized
DEBUG - 2018-03-10 15:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 15:51:49 --> Input Class Initialized
INFO - 2018-03-10 15:51:49 --> Language Class Initialized
INFO - 2018-03-10 15:51:49 --> Loader Class Initialized
INFO - 2018-03-10 15:51:49 --> Helper loaded: url_helper
INFO - 2018-03-10 15:51:49 --> Helper loaded: site_helper
INFO - 2018-03-10 15:51:49 --> Database Driver Class Initialized
INFO - 2018-03-10 15:51:49 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 15:51:49 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 15:51:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 15:51:49 --> Controller Class Initialized
INFO - 2018-03-10 15:51:49 --> User Agent Class Initialized
INFO - 2018-03-10 15:51:49 --> Model "site_model" initialized
INFO - 2018-03-10 15:51:49 --> Model "user_model" initialized
INFO - 2018-03-10 15:51:49 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 15:51:49 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 15:51:49 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 15:51:49 --> Final output sent to browser
DEBUG - 2018-03-10 15:51:49 --> Total execution time: 0.0299
INFO - 2018-03-10 15:53:58 --> Database Driver Class Initialized
INFO - 2018-03-10 15:53:58 --> Config Class Initialized
INFO - 2018-03-10 15:53:58 --> Hooks Class Initialized
DEBUG - 2018-03-10 15:53:58 --> UTF-8 Support Enabled
INFO - 2018-03-10 15:53:58 --> Utf8 Class Initialized
INFO - 2018-03-10 15:53:58 --> URI Class Initialized
DEBUG - 2018-03-10 15:53:58 --> No URI present. Default controller set.
INFO - 2018-03-10 15:53:58 --> Router Class Initialized
INFO - 2018-03-10 15:53:58 --> Output Class Initialized
INFO - 2018-03-10 15:53:58 --> Security Class Initialized
DEBUG - 2018-03-10 15:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 15:53:58 --> Input Class Initialized
INFO - 2018-03-10 15:53:58 --> Language Class Initialized
INFO - 2018-03-10 15:53:58 --> Loader Class Initialized
INFO - 2018-03-10 15:53:58 --> Helper loaded: url_helper
INFO - 2018-03-10 15:53:58 --> Helper loaded: site_helper
INFO - 2018-03-10 15:53:58 --> Database Driver Class Initialized
INFO - 2018-03-10 15:53:58 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 15:53:58 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 15:53:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 15:53:58 --> Controller Class Initialized
INFO - 2018-03-10 15:53:58 --> User Agent Class Initialized
INFO - 2018-03-10 15:53:58 --> Model "site_model" initialized
INFO - 2018-03-10 15:53:58 --> Model "user_model" initialized
INFO - 2018-03-10 15:53:58 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 15:53:58 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 15:53:58 --> Final output sent to browser
DEBUG - 2018-03-10 15:53:58 --> Total execution time: 0.0186
INFO - 2018-03-10 15:57:50 --> Database Driver Class Initialized
INFO - 2018-03-10 15:57:50 --> Config Class Initialized
INFO - 2018-03-10 15:57:50 --> Hooks Class Initialized
DEBUG - 2018-03-10 15:57:50 --> UTF-8 Support Enabled
INFO - 2018-03-10 15:57:50 --> Utf8 Class Initialized
INFO - 2018-03-10 15:57:50 --> URI Class Initialized
DEBUG - 2018-03-10 15:57:50 --> No URI present. Default controller set.
INFO - 2018-03-10 15:57:50 --> Router Class Initialized
INFO - 2018-03-10 15:57:50 --> Output Class Initialized
INFO - 2018-03-10 15:57:50 --> Security Class Initialized
DEBUG - 2018-03-10 15:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 15:57:50 --> Input Class Initialized
INFO - 2018-03-10 15:57:50 --> Language Class Initialized
INFO - 2018-03-10 15:57:50 --> Loader Class Initialized
INFO - 2018-03-10 15:57:50 --> Helper loaded: url_helper
INFO - 2018-03-10 15:57:50 --> Helper loaded: site_helper
INFO - 2018-03-10 15:57:50 --> Database Driver Class Initialized
INFO - 2018-03-10 15:57:50 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 15:57:50 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 15:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 15:57:50 --> Controller Class Initialized
INFO - 2018-03-10 15:57:50 --> User Agent Class Initialized
INFO - 2018-03-10 15:57:50 --> Model "site_model" initialized
INFO - 2018-03-10 15:57:50 --> Model "user_model" initialized
INFO - 2018-03-10 15:57:50 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 15:57:50 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 15:57:50 --> Final output sent to browser
DEBUG - 2018-03-10 15:57:50 --> Total execution time: 0.0204
INFO - 2018-03-10 15:57:52 --> Database Driver Class Initialized
INFO - 2018-03-10 15:57:52 --> Config Class Initialized
INFO - 2018-03-10 15:57:52 --> Hooks Class Initialized
DEBUG - 2018-03-10 15:57:52 --> UTF-8 Support Enabled
INFO - 2018-03-10 15:57:52 --> Utf8 Class Initialized
INFO - 2018-03-10 15:57:52 --> URI Class Initialized
INFO - 2018-03-10 15:57:52 --> Router Class Initialized
INFO - 2018-03-10 15:57:52 --> Output Class Initialized
INFO - 2018-03-10 15:57:52 --> Security Class Initialized
DEBUG - 2018-03-10 15:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 15:57:52 --> Input Class Initialized
INFO - 2018-03-10 15:57:52 --> Language Class Initialized
ERROR - 2018-03-10 15:57:52 --> 404 Page Not Found: Migrate/index.php
INFO - 2018-03-10 15:57:53 --> Database Driver Class Initialized
INFO - 2018-03-10 15:57:53 --> Config Class Initialized
INFO - 2018-03-10 15:57:53 --> Hooks Class Initialized
DEBUG - 2018-03-10 15:57:53 --> UTF-8 Support Enabled
INFO - 2018-03-10 15:57:53 --> Utf8 Class Initialized
INFO - 2018-03-10 15:57:53 --> URI Class Initialized
DEBUG - 2018-03-10 15:57:53 --> No URI present. Default controller set.
INFO - 2018-03-10 15:57:53 --> Router Class Initialized
INFO - 2018-03-10 15:57:53 --> Output Class Initialized
INFO - 2018-03-10 15:57:53 --> Security Class Initialized
DEBUG - 2018-03-10 15:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 15:57:53 --> Input Class Initialized
INFO - 2018-03-10 15:57:53 --> Language Class Initialized
INFO - 2018-03-10 15:57:53 --> Loader Class Initialized
INFO - 2018-03-10 15:57:53 --> Helper loaded: url_helper
INFO - 2018-03-10 15:57:53 --> Helper loaded: site_helper
INFO - 2018-03-10 15:57:53 --> Database Driver Class Initialized
INFO - 2018-03-10 15:57:53 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 15:57:53 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 15:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 15:57:53 --> Controller Class Initialized
INFO - 2018-03-10 15:57:53 --> User Agent Class Initialized
INFO - 2018-03-10 15:57:53 --> Model "site_model" initialized
INFO - 2018-03-10 15:57:53 --> Model "user_model" initialized
INFO - 2018-03-10 15:57:53 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 15:57:53 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 15:57:53 --> Final output sent to browser
DEBUG - 2018-03-10 15:57:53 --> Total execution time: 0.0217
INFO - 2018-03-10 15:58:18 --> Database Driver Class Initialized
INFO - 2018-03-10 15:58:18 --> Config Class Initialized
INFO - 2018-03-10 15:58:18 --> Hooks Class Initialized
DEBUG - 2018-03-10 15:58:18 --> UTF-8 Support Enabled
INFO - 2018-03-10 15:58:18 --> Utf8 Class Initialized
INFO - 2018-03-10 15:58:18 --> URI Class Initialized
DEBUG - 2018-03-10 15:58:18 --> No URI present. Default controller set.
INFO - 2018-03-10 15:58:18 --> Router Class Initialized
INFO - 2018-03-10 15:58:18 --> Output Class Initialized
INFO - 2018-03-10 15:58:18 --> Security Class Initialized
DEBUG - 2018-03-10 15:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 15:58:18 --> Input Class Initialized
INFO - 2018-03-10 15:58:18 --> Language Class Initialized
INFO - 2018-03-10 15:58:18 --> Loader Class Initialized
INFO - 2018-03-10 15:58:18 --> Helper loaded: url_helper
INFO - 2018-03-10 15:58:18 --> Helper loaded: site_helper
INFO - 2018-03-10 15:58:18 --> Database Driver Class Initialized
INFO - 2018-03-10 15:58:18 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 15:58:18 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 15:58:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 15:58:18 --> Controller Class Initialized
INFO - 2018-03-10 15:58:18 --> User Agent Class Initialized
INFO - 2018-03-10 15:58:18 --> Model "site_model" initialized
INFO - 2018-03-10 15:58:18 --> Model "user_model" initialized
INFO - 2018-03-10 15:58:18 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 15:58:18 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 15:58:18 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 15:58:18 --> Final output sent to browser
DEBUG - 2018-03-10 15:58:18 --> Total execution time: 0.0254
INFO - 2018-03-10 15:58:35 --> Database Driver Class Initialized
INFO - 2018-03-10 15:58:35 --> Config Class Initialized
INFO - 2018-03-10 15:58:35 --> Hooks Class Initialized
DEBUG - 2018-03-10 15:58:35 --> UTF-8 Support Enabled
INFO - 2018-03-10 15:58:35 --> Utf8 Class Initialized
INFO - 2018-03-10 15:58:35 --> URI Class Initialized
DEBUG - 2018-03-10 15:58:35 --> No URI present. Default controller set.
INFO - 2018-03-10 15:58:35 --> Router Class Initialized
INFO - 2018-03-10 15:58:35 --> Output Class Initialized
INFO - 2018-03-10 15:58:35 --> Security Class Initialized
DEBUG - 2018-03-10 15:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 15:58:35 --> Input Class Initialized
INFO - 2018-03-10 15:58:35 --> Language Class Initialized
INFO - 2018-03-10 15:58:35 --> Loader Class Initialized
INFO - 2018-03-10 15:58:35 --> Helper loaded: url_helper
INFO - 2018-03-10 15:58:35 --> Helper loaded: site_helper
INFO - 2018-03-10 15:58:35 --> Database Driver Class Initialized
INFO - 2018-03-10 15:58:35 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 15:58:35 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 15:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 15:58:35 --> Controller Class Initialized
INFO - 2018-03-10 15:58:35 --> User Agent Class Initialized
INFO - 2018-03-10 15:58:35 --> Model "site_model" initialized
INFO - 2018-03-10 15:58:35 --> Model "user_model" initialized
INFO - 2018-03-10 15:58:35 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 15:58:35 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 15:58:35 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 15:58:35 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 15:58:35 --> Final output sent to browser
DEBUG - 2018-03-10 15:58:35 --> Total execution time: 0.0236
INFO - 2018-03-10 16:02:49 --> Database Driver Class Initialized
INFO - 2018-03-10 16:02:49 --> Config Class Initialized
INFO - 2018-03-10 16:02:49 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:02:49 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:02:49 --> Utf8 Class Initialized
INFO - 2018-03-10 16:02:49 --> URI Class Initialized
DEBUG - 2018-03-10 16:02:49 --> No URI present. Default controller set.
INFO - 2018-03-10 16:02:49 --> Router Class Initialized
INFO - 2018-03-10 16:02:49 --> Output Class Initialized
INFO - 2018-03-10 16:02:49 --> Security Class Initialized
DEBUG - 2018-03-10 16:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:02:49 --> Input Class Initialized
INFO - 2018-03-10 16:02:49 --> Language Class Initialized
INFO - 2018-03-10 16:02:49 --> Loader Class Initialized
INFO - 2018-03-10 16:02:49 --> Helper loaded: url_helper
INFO - 2018-03-10 16:02:49 --> Helper loaded: site_helper
INFO - 2018-03-10 16:02:49 --> Database Driver Class Initialized
INFO - 2018-03-10 16:02:49 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:02:49 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:02:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:02:49 --> Controller Class Initialized
INFO - 2018-03-10 16:02:49 --> User Agent Class Initialized
INFO - 2018-03-10 16:02:49 --> Model "site_model" initialized
INFO - 2018-03-10 16:02:49 --> Model "user_model" initialized
INFO - 2018-03-10 16:02:49 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 16:02:49 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 16:02:49 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 16:02:49 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 16:02:49 --> Final output sent to browser
DEBUG - 2018-03-10 16:02:49 --> Total execution time: 0.0391
INFO - 2018-03-10 16:02:59 --> Database Driver Class Initialized
INFO - 2018-03-10 16:02:59 --> Config Class Initialized
INFO - 2018-03-10 16:02:59 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:02:59 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:02:59 --> Utf8 Class Initialized
INFO - 2018-03-10 16:02:59 --> URI Class Initialized
DEBUG - 2018-03-10 16:02:59 --> No URI present. Default controller set.
INFO - 2018-03-10 16:02:59 --> Router Class Initialized
INFO - 2018-03-10 16:02:59 --> Output Class Initialized
INFO - 2018-03-10 16:02:59 --> Security Class Initialized
DEBUG - 2018-03-10 16:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:02:59 --> Input Class Initialized
INFO - 2018-03-10 16:02:59 --> Language Class Initialized
INFO - 2018-03-10 16:02:59 --> Loader Class Initialized
INFO - 2018-03-10 16:02:59 --> Helper loaded: url_helper
INFO - 2018-03-10 16:02:59 --> Helper loaded: site_helper
INFO - 2018-03-10 16:02:59 --> Database Driver Class Initialized
INFO - 2018-03-10 16:02:59 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:02:59 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:02:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:02:59 --> Controller Class Initialized
INFO - 2018-03-10 16:02:59 --> User Agent Class Initialized
INFO - 2018-03-10 16:02:59 --> Model "site_model" initialized
INFO - 2018-03-10 16:02:59 --> Model "user_model" initialized
INFO - 2018-03-10 16:02:59 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 16:02:59 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 16:02:59 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 16:02:59 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 16:02:59 --> Final output sent to browser
DEBUG - 2018-03-10 16:02:59 --> Total execution time: 0.0181
INFO - 2018-03-10 16:05:17 --> Database Driver Class Initialized
INFO - 2018-03-10 16:05:17 --> Config Class Initialized
INFO - 2018-03-10 16:05:17 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:05:17 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:05:17 --> Utf8 Class Initialized
INFO - 2018-03-10 16:05:17 --> URI Class Initialized
DEBUG - 2018-03-10 16:05:17 --> No URI present. Default controller set.
INFO - 2018-03-10 16:05:17 --> Router Class Initialized
INFO - 2018-03-10 16:05:17 --> Output Class Initialized
INFO - 2018-03-10 16:05:17 --> Security Class Initialized
DEBUG - 2018-03-10 16:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:05:17 --> Input Class Initialized
INFO - 2018-03-10 16:05:17 --> Language Class Initialized
INFO - 2018-03-10 16:05:17 --> Loader Class Initialized
INFO - 2018-03-10 16:05:17 --> Helper loaded: url_helper
INFO - 2018-03-10 16:05:17 --> Helper loaded: site_helper
INFO - 2018-03-10 16:05:17 --> Database Driver Class Initialized
INFO - 2018-03-10 16:05:17 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:05:17 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:05:17 --> Controller Class Initialized
INFO - 2018-03-10 16:05:17 --> User Agent Class Initialized
INFO - 2018-03-10 16:05:17 --> Model "site_model" initialized
INFO - 2018-03-10 16:05:17 --> Model "user_model" initialized
INFO - 2018-03-10 16:05:17 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 16:05:17 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 16:05:17 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 16:05:17 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 16:05:17 --> Final output sent to browser
DEBUG - 2018-03-10 16:05:17 --> Total execution time: 0.0188
INFO - 2018-03-10 16:05:28 --> Database Driver Class Initialized
INFO - 2018-03-10 16:05:28 --> Config Class Initialized
INFO - 2018-03-10 16:05:28 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:05:28 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:05:28 --> Utf8 Class Initialized
INFO - 2018-03-10 16:05:28 --> URI Class Initialized
DEBUG - 2018-03-10 16:05:28 --> No URI present. Default controller set.
INFO - 2018-03-10 16:05:28 --> Router Class Initialized
INFO - 2018-03-10 16:05:28 --> Output Class Initialized
INFO - 2018-03-10 16:05:28 --> Security Class Initialized
DEBUG - 2018-03-10 16:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:05:28 --> Input Class Initialized
INFO - 2018-03-10 16:05:28 --> Language Class Initialized
INFO - 2018-03-10 16:05:28 --> Loader Class Initialized
INFO - 2018-03-10 16:05:28 --> Helper loaded: url_helper
INFO - 2018-03-10 16:05:28 --> Helper loaded: site_helper
INFO - 2018-03-10 16:05:28 --> Database Driver Class Initialized
INFO - 2018-03-10 16:05:28 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:05:28 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:05:28 --> Controller Class Initialized
INFO - 2018-03-10 16:05:28 --> User Agent Class Initialized
INFO - 2018-03-10 16:05:28 --> Model "site_model" initialized
INFO - 2018-03-10 16:05:28 --> Model "user_model" initialized
INFO - 2018-03-10 16:05:28 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 16:05:28 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 16:05:28 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 16:05:28 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 16:05:28 --> Final output sent to browser
DEBUG - 2018-03-10 16:05:28 --> Total execution time: 0.0215
INFO - 2018-03-10 16:05:32 --> Database Driver Class Initialized
INFO - 2018-03-10 16:05:32 --> Config Class Initialized
INFO - 2018-03-10 16:05:32 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:05:32 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:05:32 --> Utf8 Class Initialized
INFO - 2018-03-10 16:05:32 --> URI Class Initialized
DEBUG - 2018-03-10 16:05:32 --> No URI present. Default controller set.
INFO - 2018-03-10 16:05:32 --> Router Class Initialized
INFO - 2018-03-10 16:05:32 --> Output Class Initialized
INFO - 2018-03-10 16:05:32 --> Security Class Initialized
DEBUG - 2018-03-10 16:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:05:32 --> Input Class Initialized
INFO - 2018-03-10 16:05:32 --> Language Class Initialized
INFO - 2018-03-10 16:05:32 --> Loader Class Initialized
INFO - 2018-03-10 16:05:32 --> Helper loaded: url_helper
INFO - 2018-03-10 16:05:32 --> Helper loaded: site_helper
INFO - 2018-03-10 16:05:32 --> Database Driver Class Initialized
INFO - 2018-03-10 16:05:32 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:05:32 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:05:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:05:32 --> Controller Class Initialized
INFO - 2018-03-10 16:05:32 --> User Agent Class Initialized
INFO - 2018-03-10 16:05:32 --> Model "site_model" initialized
INFO - 2018-03-10 16:05:32 --> Model "user_model" initialized
INFO - 2018-03-10 16:05:32 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 16:05:32 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 16:05:32 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 16:05:32 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 16:05:32 --> Final output sent to browser
DEBUG - 2018-03-10 16:05:32 --> Total execution time: 0.0183
INFO - 2018-03-10 16:06:07 --> Database Driver Class Initialized
INFO - 2018-03-10 16:06:07 --> Config Class Initialized
INFO - 2018-03-10 16:06:07 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:06:07 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:06:07 --> Utf8 Class Initialized
INFO - 2018-03-10 16:06:07 --> URI Class Initialized
DEBUG - 2018-03-10 16:06:07 --> No URI present. Default controller set.
INFO - 2018-03-10 16:06:07 --> Router Class Initialized
INFO - 2018-03-10 16:06:07 --> Output Class Initialized
INFO - 2018-03-10 16:06:07 --> Security Class Initialized
DEBUG - 2018-03-10 16:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:06:07 --> Input Class Initialized
INFO - 2018-03-10 16:06:07 --> Language Class Initialized
INFO - 2018-03-10 16:06:07 --> Loader Class Initialized
INFO - 2018-03-10 16:06:07 --> Helper loaded: url_helper
INFO - 2018-03-10 16:06:07 --> Helper loaded: site_helper
INFO - 2018-03-10 16:06:07 --> Database Driver Class Initialized
INFO - 2018-03-10 16:06:07 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:06:07 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:06:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:06:07 --> Controller Class Initialized
INFO - 2018-03-10 16:06:07 --> User Agent Class Initialized
INFO - 2018-03-10 16:06:07 --> Model "site_model" initialized
INFO - 2018-03-10 16:06:07 --> Model "user_model" initialized
INFO - 2018-03-10 16:06:07 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 16:06:07 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 16:06:07 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 16:06:07 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 16:06:07 --> Final output sent to browser
DEBUG - 2018-03-10 16:06:07 --> Total execution time: 0.0195
INFO - 2018-03-10 16:06:13 --> Database Driver Class Initialized
INFO - 2018-03-10 16:06:13 --> Config Class Initialized
INFO - 2018-03-10 16:06:13 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:06:13 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:06:13 --> Utf8 Class Initialized
INFO - 2018-03-10 16:06:13 --> URI Class Initialized
DEBUG - 2018-03-10 16:06:13 --> No URI present. Default controller set.
INFO - 2018-03-10 16:06:13 --> Router Class Initialized
INFO - 2018-03-10 16:06:13 --> Output Class Initialized
INFO - 2018-03-10 16:06:13 --> Security Class Initialized
DEBUG - 2018-03-10 16:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:06:13 --> Input Class Initialized
INFO - 2018-03-10 16:06:13 --> Language Class Initialized
INFO - 2018-03-10 16:06:13 --> Loader Class Initialized
INFO - 2018-03-10 16:06:13 --> Helper loaded: url_helper
INFO - 2018-03-10 16:06:13 --> Helper loaded: site_helper
INFO - 2018-03-10 16:06:13 --> Database Driver Class Initialized
INFO - 2018-03-10 16:06:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:06:13 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:06:13 --> Controller Class Initialized
INFO - 2018-03-10 16:06:13 --> User Agent Class Initialized
INFO - 2018-03-10 16:06:13 --> Model "site_model" initialized
INFO - 2018-03-10 16:06:13 --> Model "user_model" initialized
INFO - 2018-03-10 16:06:13 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 16:06:13 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 16:06:13 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 16:06:13 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 16:06:13 --> Final output sent to browser
DEBUG - 2018-03-10 16:06:13 --> Total execution time: 0.0212
INFO - 2018-03-10 16:10:06 --> Database Driver Class Initialized
INFO - 2018-03-10 16:10:06 --> Config Class Initialized
INFO - 2018-03-10 16:10:06 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:10:06 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:10:06 --> Utf8 Class Initialized
INFO - 2018-03-10 16:10:06 --> URI Class Initialized
DEBUG - 2018-03-10 16:10:06 --> No URI present. Default controller set.
INFO - 2018-03-10 16:10:06 --> Router Class Initialized
INFO - 2018-03-10 16:10:06 --> Output Class Initialized
INFO - 2018-03-10 16:10:06 --> Security Class Initialized
DEBUG - 2018-03-10 16:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:10:06 --> Input Class Initialized
INFO - 2018-03-10 16:10:06 --> Language Class Initialized
INFO - 2018-03-10 16:10:06 --> Loader Class Initialized
INFO - 2018-03-10 16:10:06 --> Helper loaded: url_helper
INFO - 2018-03-10 16:10:06 --> Helper loaded: site_helper
INFO - 2018-03-10 16:10:06 --> Database Driver Class Initialized
INFO - 2018-03-10 16:10:06 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:10:06 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:10:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:10:06 --> Controller Class Initialized
INFO - 2018-03-10 16:10:06 --> User Agent Class Initialized
INFO - 2018-03-10 16:10:06 --> Model "site_model" initialized
INFO - 2018-03-10 16:10:06 --> Model "user_model" initialized
INFO - 2018-03-10 16:10:06 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 16:10:06 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 16:10:06 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 16:10:06 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 16:10:06 --> Final output sent to browser
DEBUG - 2018-03-10 16:10:06 --> Total execution time: 0.0344
INFO - 2018-03-10 16:10:38 --> Database Driver Class Initialized
INFO - 2018-03-10 16:10:38 --> Config Class Initialized
INFO - 2018-03-10 16:10:38 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:10:38 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:10:38 --> Utf8 Class Initialized
INFO - 2018-03-10 16:10:38 --> URI Class Initialized
DEBUG - 2018-03-10 16:10:38 --> No URI present. Default controller set.
INFO - 2018-03-10 16:10:38 --> Router Class Initialized
INFO - 2018-03-10 16:10:38 --> Output Class Initialized
INFO - 2018-03-10 16:10:38 --> Security Class Initialized
DEBUG - 2018-03-10 16:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:10:38 --> Input Class Initialized
INFO - 2018-03-10 16:10:38 --> Language Class Initialized
INFO - 2018-03-10 16:10:38 --> Loader Class Initialized
INFO - 2018-03-10 16:10:38 --> Helper loaded: url_helper
INFO - 2018-03-10 16:10:38 --> Helper loaded: site_helper
INFO - 2018-03-10 16:10:38 --> Database Driver Class Initialized
INFO - 2018-03-10 16:10:38 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:10:38 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:10:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:10:38 --> Controller Class Initialized
INFO - 2018-03-10 16:10:38 --> User Agent Class Initialized
INFO - 2018-03-10 16:10:38 --> Model "site_model" initialized
INFO - 2018-03-10 16:10:38 --> Model "user_model" initialized
INFO - 2018-03-10 16:10:38 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 16:10:38 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 16:10:38 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 16:10:38 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 16:10:38 --> Final output sent to browser
DEBUG - 2018-03-10 16:10:38 --> Total execution time: 0.0318
INFO - 2018-03-10 16:11:30 --> Database Driver Class Initialized
INFO - 2018-03-10 16:11:30 --> Config Class Initialized
INFO - 2018-03-10 16:11:30 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:11:30 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:11:30 --> Utf8 Class Initialized
INFO - 2018-03-10 16:11:30 --> URI Class Initialized
DEBUG - 2018-03-10 16:11:30 --> No URI present. Default controller set.
INFO - 2018-03-10 16:11:30 --> Router Class Initialized
INFO - 2018-03-10 16:11:30 --> Output Class Initialized
INFO - 2018-03-10 16:11:30 --> Security Class Initialized
DEBUG - 2018-03-10 16:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:11:30 --> Input Class Initialized
INFO - 2018-03-10 16:11:30 --> Language Class Initialized
INFO - 2018-03-10 16:11:30 --> Loader Class Initialized
INFO - 2018-03-10 16:11:30 --> Helper loaded: url_helper
INFO - 2018-03-10 16:11:30 --> Helper loaded: site_helper
INFO - 2018-03-10 16:11:30 --> Database Driver Class Initialized
INFO - 2018-03-10 16:11:30 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:11:30 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:11:30 --> Controller Class Initialized
INFO - 2018-03-10 16:11:30 --> User Agent Class Initialized
INFO - 2018-03-10 16:11:30 --> Model "site_model" initialized
INFO - 2018-03-10 16:11:30 --> Model "user_model" initialized
INFO - 2018-03-10 16:11:30 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 16:11:30 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 16:11:30 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 16:11:30 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 16:11:30 --> Final output sent to browser
DEBUG - 2018-03-10 16:11:30 --> Total execution time: 0.0210
INFO - 2018-03-10 16:15:07 --> Database Driver Class Initialized
INFO - 2018-03-10 16:15:07 --> Config Class Initialized
INFO - 2018-03-10 16:15:07 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:15:07 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:15:07 --> Utf8 Class Initialized
INFO - 2018-03-10 16:15:07 --> URI Class Initialized
DEBUG - 2018-03-10 16:15:07 --> No URI present. Default controller set.
INFO - 2018-03-10 16:15:07 --> Router Class Initialized
INFO - 2018-03-10 16:15:07 --> Output Class Initialized
INFO - 2018-03-10 16:15:07 --> Security Class Initialized
DEBUG - 2018-03-10 16:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:15:07 --> Input Class Initialized
INFO - 2018-03-10 16:15:07 --> Language Class Initialized
INFO - 2018-03-10 16:15:07 --> Loader Class Initialized
INFO - 2018-03-10 16:15:07 --> Helper loaded: url_helper
INFO - 2018-03-10 16:15:07 --> Helper loaded: site_helper
INFO - 2018-03-10 16:15:07 --> Database Driver Class Initialized
INFO - 2018-03-10 16:15:07 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:15:07 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:15:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:15:07 --> Controller Class Initialized
INFO - 2018-03-10 16:15:07 --> User Agent Class Initialized
INFO - 2018-03-10 16:15:07 --> Model "site_model" initialized
INFO - 2018-03-10 16:15:07 --> Model "user_model" initialized
INFO - 2018-03-10 16:15:07 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-10 16:15:07 --> Severity: error --> Exception: syntax error, unexpected '" ?></a>' (T_CONSTANT_ENCAPSED_STRING) /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php 86
INFO - 2018-03-10 16:15:10 --> Database Driver Class Initialized
INFO - 2018-03-10 16:15:10 --> Config Class Initialized
INFO - 2018-03-10 16:15:10 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:15:10 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:15:10 --> Utf8 Class Initialized
INFO - 2018-03-10 16:15:10 --> URI Class Initialized
INFO - 2018-03-10 16:15:10 --> Router Class Initialized
INFO - 2018-03-10 16:15:10 --> Output Class Initialized
INFO - 2018-03-10 16:15:10 --> Security Class Initialized
DEBUG - 2018-03-10 16:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:15:10 --> Input Class Initialized
INFO - 2018-03-10 16:15:10 --> Language Class Initialized
ERROR - 2018-03-10 16:15:10 --> 404 Page Not Found: Migrate/index.php
INFO - 2018-03-10 16:15:13 --> Database Driver Class Initialized
INFO - 2018-03-10 16:15:13 --> Config Class Initialized
INFO - 2018-03-10 16:15:13 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:15:13 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:15:13 --> Utf8 Class Initialized
INFO - 2018-03-10 16:15:13 --> URI Class Initialized
INFO - 2018-03-10 16:15:13 --> Router Class Initialized
INFO - 2018-03-10 16:15:13 --> Output Class Initialized
INFO - 2018-03-10 16:15:13 --> Security Class Initialized
DEBUG - 2018-03-10 16:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:15:13 --> Input Class Initialized
INFO - 2018-03-10 16:15:13 --> Language Class Initialized
INFO - 2018-03-10 16:15:13 --> Loader Class Initialized
INFO - 2018-03-10 16:15:13 --> Helper loaded: url_helper
INFO - 2018-03-10 16:15:13 --> Helper loaded: site_helper
INFO - 2018-03-10 16:15:13 --> Database Driver Class Initialized
INFO - 2018-03-10 16:15:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:15:13 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:15:13 --> Controller Class Initialized
INFO - 2018-03-10 16:15:13 --> Migrations Class Initialized
INFO - 2018-03-10 16:15:13 --> Language file loaded: language/english/migration_lang.php
INFO - 2018-03-10 16:15:13 --> Database Forge Class Initialized
INFO - 2018-03-10 16:15:13 --> Final output sent to browser
DEBUG - 2018-03-10 16:15:13 --> Total execution time: 0.0182
INFO - 2018-03-10 16:15:14 --> Database Driver Class Initialized
INFO - 2018-03-10 16:15:14 --> Config Class Initialized
INFO - 2018-03-10 16:15:14 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:15:14 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:15:14 --> Utf8 Class Initialized
INFO - 2018-03-10 16:15:14 --> URI Class Initialized
DEBUG - 2018-03-10 16:15:14 --> No URI present. Default controller set.
INFO - 2018-03-10 16:15:14 --> Router Class Initialized
INFO - 2018-03-10 16:15:14 --> Output Class Initialized
INFO - 2018-03-10 16:15:14 --> Security Class Initialized
DEBUG - 2018-03-10 16:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:15:14 --> Input Class Initialized
INFO - 2018-03-10 16:15:14 --> Language Class Initialized
INFO - 2018-03-10 16:15:14 --> Loader Class Initialized
INFO - 2018-03-10 16:15:14 --> Helper loaded: url_helper
INFO - 2018-03-10 16:15:14 --> Helper loaded: site_helper
INFO - 2018-03-10 16:15:14 --> Database Driver Class Initialized
INFO - 2018-03-10 16:15:14 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:15:14 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:15:14 --> Controller Class Initialized
INFO - 2018-03-10 16:15:14 --> User Agent Class Initialized
INFO - 2018-03-10 16:15:14 --> Model "site_model" initialized
INFO - 2018-03-10 16:15:14 --> Model "user_model" initialized
INFO - 2018-03-10 16:15:14 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-10 16:15:14 --> Severity: error --> Exception: syntax error, unexpected '" ?></a>' (T_CONSTANT_ENCAPSED_STRING) /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php 86
INFO - 2018-03-10 16:15:40 --> Database Driver Class Initialized
INFO - 2018-03-10 16:15:40 --> Config Class Initialized
INFO - 2018-03-10 16:15:40 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:15:40 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:15:40 --> Utf8 Class Initialized
INFO - 2018-03-10 16:15:40 --> URI Class Initialized
DEBUG - 2018-03-10 16:15:40 --> No URI present. Default controller set.
INFO - 2018-03-10 16:15:40 --> Router Class Initialized
INFO - 2018-03-10 16:15:40 --> Output Class Initialized
INFO - 2018-03-10 16:15:40 --> Security Class Initialized
DEBUG - 2018-03-10 16:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:15:40 --> Input Class Initialized
INFO - 2018-03-10 16:15:40 --> Language Class Initialized
INFO - 2018-03-10 16:15:40 --> Loader Class Initialized
INFO - 2018-03-10 16:15:40 --> Helper loaded: url_helper
INFO - 2018-03-10 16:15:40 --> Helper loaded: site_helper
INFO - 2018-03-10 16:15:40 --> Database Driver Class Initialized
INFO - 2018-03-10 16:15:40 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:15:40 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:15:40 --> Controller Class Initialized
INFO - 2018-03-10 16:15:40 --> User Agent Class Initialized
INFO - 2018-03-10 16:15:40 --> Model "site_model" initialized
INFO - 2018-03-10 16:15:40 --> Model "user_model" initialized
INFO - 2018-03-10 16:15:40 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 16:15:40 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 16:15:40 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 16:15:40 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 16:15:40 --> Final output sent to browser
DEBUG - 2018-03-10 16:15:40 --> Total execution time: 0.0211
INFO - 2018-03-10 16:15:40 --> Database Driver Class Initialized
INFO - 2018-03-10 16:15:40 --> Config Class Initialized
INFO - 2018-03-10 16:15:40 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:15:40 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:15:40 --> Utf8 Class Initialized
INFO - 2018-03-10 16:15:40 --> URI Class Initialized
DEBUG - 2018-03-10 16:15:40 --> No URI present. Default controller set.
INFO - 2018-03-10 16:15:40 --> Router Class Initialized
INFO - 2018-03-10 16:15:40 --> Output Class Initialized
INFO - 2018-03-10 16:15:40 --> Security Class Initialized
DEBUG - 2018-03-10 16:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:15:40 --> Input Class Initialized
INFO - 2018-03-10 16:15:40 --> Language Class Initialized
INFO - 2018-03-10 16:15:40 --> Loader Class Initialized
INFO - 2018-03-10 16:15:40 --> Helper loaded: url_helper
INFO - 2018-03-10 16:15:40 --> Helper loaded: site_helper
INFO - 2018-03-10 16:15:40 --> Database Driver Class Initialized
INFO - 2018-03-10 16:15:40 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:15:40 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:15:40 --> Controller Class Initialized
INFO - 2018-03-10 16:15:40 --> User Agent Class Initialized
INFO - 2018-03-10 16:15:40 --> Model "site_model" initialized
INFO - 2018-03-10 16:15:40 --> Model "user_model" initialized
INFO - 2018-03-10 16:15:40 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 16:15:40 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 16:15:40 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 16:15:40 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 16:15:40 --> Final output sent to browser
DEBUG - 2018-03-10 16:15:40 --> Total execution time: 0.0183
INFO - 2018-03-10 16:15:50 --> Database Driver Class Initialized
INFO - 2018-03-10 16:15:50 --> Config Class Initialized
INFO - 2018-03-10 16:15:50 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:15:50 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:15:50 --> Utf8 Class Initialized
INFO - 2018-03-10 16:15:50 --> URI Class Initialized
DEBUG - 2018-03-10 16:15:50 --> No URI present. Default controller set.
INFO - 2018-03-10 16:15:50 --> Router Class Initialized
INFO - 2018-03-10 16:15:50 --> Output Class Initialized
INFO - 2018-03-10 16:15:50 --> Security Class Initialized
DEBUG - 2018-03-10 16:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:15:50 --> Input Class Initialized
INFO - 2018-03-10 16:15:50 --> Language Class Initialized
INFO - 2018-03-10 16:15:50 --> Loader Class Initialized
INFO - 2018-03-10 16:15:50 --> Helper loaded: url_helper
INFO - 2018-03-10 16:15:50 --> Helper loaded: site_helper
INFO - 2018-03-10 16:15:50 --> Database Driver Class Initialized
INFO - 2018-03-10 16:15:50 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:15:50 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:15:50 --> Controller Class Initialized
INFO - 2018-03-10 16:15:50 --> User Agent Class Initialized
INFO - 2018-03-10 16:15:50 --> Model "site_model" initialized
INFO - 2018-03-10 16:15:50 --> Model "user_model" initialized
INFO - 2018-03-10 16:15:50 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-10 16:15:50 --> Severity: Warning --> A non-numeric value encountered /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php 82
ERROR - 2018-03-10 16:15:50 --> Severity: Warning --> A non-numeric value encountered /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php 82
ERROR - 2018-03-10 16:15:50 --> Severity: Warning --> Division by zero /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php 82
INFO - 2018-03-10 16:15:50 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 16:15:50 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 16:15:50 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 16:15:50 --> Final output sent to browser
DEBUG - 2018-03-10 16:15:50 --> Total execution time: 0.0275
INFO - 2018-03-10 16:15:50 --> Database Driver Class Initialized
INFO - 2018-03-10 16:15:50 --> Config Class Initialized
INFO - 2018-03-10 16:15:50 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:15:50 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:15:50 --> Utf8 Class Initialized
INFO - 2018-03-10 16:15:50 --> URI Class Initialized
DEBUG - 2018-03-10 16:15:50 --> No URI present. Default controller set.
INFO - 2018-03-10 16:15:50 --> Router Class Initialized
INFO - 2018-03-10 16:15:50 --> Output Class Initialized
INFO - 2018-03-10 16:15:50 --> Security Class Initialized
DEBUG - 2018-03-10 16:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:15:50 --> Input Class Initialized
INFO - 2018-03-10 16:15:50 --> Language Class Initialized
INFO - 2018-03-10 16:15:50 --> Loader Class Initialized
INFO - 2018-03-10 16:15:50 --> Helper loaded: url_helper
INFO - 2018-03-10 16:15:50 --> Helper loaded: site_helper
INFO - 2018-03-10 16:15:50 --> Database Driver Class Initialized
INFO - 2018-03-10 16:15:50 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:15:50 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:15:50 --> Controller Class Initialized
INFO - 2018-03-10 16:15:50 --> User Agent Class Initialized
INFO - 2018-03-10 16:15:50 --> Model "site_model" initialized
INFO - 2018-03-10 16:15:50 --> Model "user_model" initialized
INFO - 2018-03-10 16:15:50 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-10 16:15:50 --> Severity: Warning --> A non-numeric value encountered /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php 82
ERROR - 2018-03-10 16:15:50 --> Severity: Warning --> A non-numeric value encountered /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php 82
ERROR - 2018-03-10 16:15:50 --> Severity: Warning --> Division by zero /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php 82
INFO - 2018-03-10 16:15:50 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 16:15:50 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 16:15:50 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 16:15:50 --> Final output sent to browser
DEBUG - 2018-03-10 16:15:50 --> Total execution time: 0.0212
INFO - 2018-03-10 16:16:08 --> Database Driver Class Initialized
INFO - 2018-03-10 16:16:08 --> Config Class Initialized
INFO - 2018-03-10 16:16:08 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:16:08 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:16:08 --> Utf8 Class Initialized
INFO - 2018-03-10 16:16:08 --> URI Class Initialized
DEBUG - 2018-03-10 16:16:08 --> No URI present. Default controller set.
INFO - 2018-03-10 16:16:08 --> Router Class Initialized
INFO - 2018-03-10 16:16:08 --> Output Class Initialized
INFO - 2018-03-10 16:16:08 --> Security Class Initialized
DEBUG - 2018-03-10 16:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:16:08 --> Input Class Initialized
INFO - 2018-03-10 16:16:08 --> Language Class Initialized
INFO - 2018-03-10 16:16:08 --> Loader Class Initialized
INFO - 2018-03-10 16:16:08 --> Helper loaded: url_helper
INFO - 2018-03-10 16:16:08 --> Helper loaded: site_helper
INFO - 2018-03-10 16:16:08 --> Database Driver Class Initialized
INFO - 2018-03-10 16:16:08 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:16:08 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:16:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:16:08 --> Controller Class Initialized
INFO - 2018-03-10 16:16:08 --> User Agent Class Initialized
INFO - 2018-03-10 16:16:08 --> Model "site_model" initialized
INFO - 2018-03-10 16:16:08 --> Model "user_model" initialized
INFO - 2018-03-10 16:16:08 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-10 16:16:08 --> Severity: Warning --> A non-numeric value encountered /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php 82
ERROR - 2018-03-10 16:16:08 --> Severity: Warning --> A non-numeric value encountered /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php 82
ERROR - 2018-03-10 16:16:08 --> Severity: Warning --> Division by zero /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php 82
INFO - 2018-03-10 16:16:08 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 16:16:08 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 16:16:08 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 16:16:08 --> Final output sent to browser
DEBUG - 2018-03-10 16:16:08 --> Total execution time: 0.0350
INFO - 2018-03-10 16:16:09 --> Database Driver Class Initialized
INFO - 2018-03-10 16:16:09 --> Config Class Initialized
INFO - 2018-03-10 16:16:09 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:16:09 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:16:09 --> Utf8 Class Initialized
INFO - 2018-03-10 16:16:09 --> URI Class Initialized
DEBUG - 2018-03-10 16:16:09 --> No URI present. Default controller set.
INFO - 2018-03-10 16:16:09 --> Router Class Initialized
INFO - 2018-03-10 16:16:09 --> Output Class Initialized
INFO - 2018-03-10 16:16:09 --> Security Class Initialized
DEBUG - 2018-03-10 16:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:16:09 --> Input Class Initialized
INFO - 2018-03-10 16:16:09 --> Language Class Initialized
INFO - 2018-03-10 16:16:09 --> Loader Class Initialized
INFO - 2018-03-10 16:16:09 --> Helper loaded: url_helper
INFO - 2018-03-10 16:16:09 --> Helper loaded: site_helper
INFO - 2018-03-10 16:16:09 --> Database Driver Class Initialized
INFO - 2018-03-10 16:16:09 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:16:09 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:16:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:16:09 --> Controller Class Initialized
INFO - 2018-03-10 16:16:09 --> User Agent Class Initialized
INFO - 2018-03-10 16:16:09 --> Model "site_model" initialized
INFO - 2018-03-10 16:16:09 --> Model "user_model" initialized
INFO - 2018-03-10 16:16:09 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-10 16:16:09 --> Severity: Warning --> A non-numeric value encountered /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php 82
ERROR - 2018-03-10 16:16:09 --> Severity: Warning --> A non-numeric value encountered /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php 82
ERROR - 2018-03-10 16:16:09 --> Severity: Warning --> Division by zero /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php 82
INFO - 2018-03-10 16:16:09 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 16:16:09 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 16:16:09 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 16:16:09 --> Final output sent to browser
DEBUG - 2018-03-10 16:16:09 --> Total execution time: 0.0191
INFO - 2018-03-10 16:16:40 --> Database Driver Class Initialized
INFO - 2018-03-10 16:16:40 --> Config Class Initialized
INFO - 2018-03-10 16:16:40 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:16:40 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:16:40 --> Utf8 Class Initialized
INFO - 2018-03-10 16:16:40 --> URI Class Initialized
DEBUG - 2018-03-10 16:16:40 --> No URI present. Default controller set.
INFO - 2018-03-10 16:16:40 --> Router Class Initialized
INFO - 2018-03-10 16:16:40 --> Output Class Initialized
INFO - 2018-03-10 16:16:40 --> Security Class Initialized
DEBUG - 2018-03-10 16:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:16:40 --> Input Class Initialized
INFO - 2018-03-10 16:16:40 --> Language Class Initialized
INFO - 2018-03-10 16:16:40 --> Loader Class Initialized
INFO - 2018-03-10 16:16:40 --> Helper loaded: url_helper
INFO - 2018-03-10 16:16:40 --> Helper loaded: site_helper
INFO - 2018-03-10 16:16:40 --> Database Driver Class Initialized
INFO - 2018-03-10 16:16:40 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:16:40 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:16:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:16:40 --> Controller Class Initialized
INFO - 2018-03-10 16:16:40 --> User Agent Class Initialized
INFO - 2018-03-10 16:16:40 --> Model "site_model" initialized
INFO - 2018-03-10 16:16:40 --> Model "user_model" initialized
INFO - 2018-03-10 16:16:40 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 16:16:40 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 16:16:40 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 16:16:40 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 16:16:40 --> Final output sent to browser
DEBUG - 2018-03-10 16:16:40 --> Total execution time: 0.0193
INFO - 2018-03-10 16:16:49 --> Database Driver Class Initialized
INFO - 2018-03-10 16:16:49 --> Config Class Initialized
INFO - 2018-03-10 16:16:49 --> Hooks Class Initialized
DEBUG - 2018-03-10 16:16:49 --> UTF-8 Support Enabled
INFO - 2018-03-10 16:16:49 --> Utf8 Class Initialized
INFO - 2018-03-10 16:16:49 --> URI Class Initialized
DEBUG - 2018-03-10 16:16:49 --> No URI present. Default controller set.
INFO - 2018-03-10 16:16:49 --> Router Class Initialized
INFO - 2018-03-10 16:16:49 --> Output Class Initialized
INFO - 2018-03-10 16:16:49 --> Security Class Initialized
DEBUG - 2018-03-10 16:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 16:16:49 --> Input Class Initialized
INFO - 2018-03-10 16:16:49 --> Language Class Initialized
INFO - 2018-03-10 16:16:49 --> Loader Class Initialized
INFO - 2018-03-10 16:16:49 --> Helper loaded: url_helper
INFO - 2018-03-10 16:16:49 --> Helper loaded: site_helper
INFO - 2018-03-10 16:16:49 --> Database Driver Class Initialized
INFO - 2018-03-10 16:16:49 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 16:16:49 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 16:16:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 16:16:49 --> Controller Class Initialized
INFO - 2018-03-10 16:16:49 --> User Agent Class Initialized
INFO - 2018-03-10 16:16:49 --> Model "site_model" initialized
INFO - 2018-03-10 16:16:49 --> Model "user_model" initialized
INFO - 2018-03-10 16:16:49 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 16:16:49 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 16:16:49 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 16:16:49 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 16:16:49 --> Final output sent to browser
DEBUG - 2018-03-10 16:16:49 --> Total execution time: 0.0189
INFO - 2018-03-10 19:34:00 --> Database Driver Class Initialized
INFO - 2018-03-10 19:34:00 --> Config Class Initialized
INFO - 2018-03-10 19:34:00 --> Hooks Class Initialized
DEBUG - 2018-03-10 19:34:00 --> UTF-8 Support Enabled
INFO - 2018-03-10 19:34:00 --> Utf8 Class Initialized
INFO - 2018-03-10 19:34:00 --> URI Class Initialized
DEBUG - 2018-03-10 19:34:00 --> No URI present. Default controller set.
INFO - 2018-03-10 19:34:00 --> Router Class Initialized
INFO - 2018-03-10 19:34:00 --> Output Class Initialized
INFO - 2018-03-10 19:34:00 --> Security Class Initialized
DEBUG - 2018-03-10 19:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 19:34:00 --> Input Class Initialized
INFO - 2018-03-10 19:34:00 --> Language Class Initialized
INFO - 2018-03-10 19:34:00 --> Loader Class Initialized
INFO - 2018-03-10 19:34:00 --> Helper loaded: url_helper
INFO - 2018-03-10 19:34:00 --> Helper loaded: site_helper
INFO - 2018-03-10 19:34:00 --> Database Driver Class Initialized
INFO - 2018-03-10 19:34:00 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-10 19:34:00 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-10 19:34:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 19:34:00 --> Controller Class Initialized
INFO - 2018-03-10 19:34:00 --> User Agent Class Initialized
INFO - 2018-03-10 19:34:00 --> Model "site_model" initialized
INFO - 2018-03-10 19:34:00 --> Model "user_model" initialized
INFO - 2018-03-10 19:34:00 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-10 19:34:00 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-10 19:34:00 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-10 19:34:00 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-10 19:34:00 --> Final output sent to browser
DEBUG - 2018-03-10 19:34:00 --> Total execution time: 0.0417
