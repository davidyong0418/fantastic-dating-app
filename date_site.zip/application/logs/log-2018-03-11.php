<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>


INFO - 2018-03-11 09:18:45 --> Database Driver Class Initialized
INFO - 2018-03-11 09:18:45 --> Config Class Initialized
INFO - 2018-03-11 09:18:45 --> Hooks Class Initialized
DEBUG - 2018-03-11 09:18:45 --> UTF-8 Support Enabled
INFO - 2018-03-11 09:18:45 --> Utf8 Class Initialized
INFO - 2018-03-11 09:18:45 --> URI Class Initialized
INFO - 2018-03-11 09:18:45 --> Router Class Initialized
INFO - 2018-03-11 09:18:45 --> Output Class Initialized
INFO - 2018-03-11 09:18:45 --> Security Class Initialized
DEBUG - 2018-03-11 09:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 09:18:45 --> Input Class Initialized
INFO - 2018-03-11 09:18:45 --> Language Class Initialized
ERROR - 2018-03-11 09:18:45 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/controllers/User.php 2421
INFO - 2018-03-11 09:35:51 --> Database Driver Class Initialized
INFO - 2018-03-11 09:35:51 --> Config Class Initialized
INFO - 2018-03-11 09:35:51 --> Hooks Class Initialized
DEBUG - 2018-03-11 09:35:51 --> UTF-8 Support Enabled
INFO - 2018-03-11 09:35:51 --> Utf8 Class Initialized
INFO - 2018-03-11 09:35:51 --> URI Class Initialized
DEBUG - 2018-03-11 09:35:51 --> No URI present. Default controller set.
INFO - 2018-03-11 09:35:51 --> Router Class Initialized
INFO - 2018-03-11 09:35:51 --> Output Class Initialized
INFO - 2018-03-11 09:35:51 --> Security Class Initialized
DEBUG - 2018-03-11 09:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 09:35:51 --> Input Class Initialized
INFO - 2018-03-11 09:35:51 --> Language Class Initialized
INFO - 2018-03-11 09:35:51 --> Loader Class Initialized
INFO - 2018-03-11 09:35:51 --> Helper loaded: url_helper
INFO - 2018-03-11 09:35:51 --> Helper loaded: site_helper
INFO - 2018-03-11 09:35:51 --> Database Driver Class Initialized
INFO - 2018-03-11 09:35:51 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 09:35:51 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 09:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 09:35:51 --> Controller Class Initialized
INFO - 2018-03-11 09:35:51 --> User Agent Class Initialized
INFO - 2018-03-11 09:35:51 --> Model "site_model" initialized
INFO - 2018-03-11 09:35:51 --> Model "user_model" initialized
INFO - 2018-03-11 09:35:51 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 09:35:51 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-11 09:35:51 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-11 09:35:51 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-11 09:35:51 --> Final output sent to browser
DEBUG - 2018-03-11 09:35:51 --> Total execution time: 0.0348
INFO - 2018-03-11 09:36:30 --> Database Driver Class Initialized
INFO - 2018-03-11 09:36:30 --> Config Class Initialized
INFO - 2018-03-11 09:36:30 --> Hooks Class Initialized
DEBUG - 2018-03-11 09:36:30 --> UTF-8 Support Enabled
INFO - 2018-03-11 09:36:30 --> Utf8 Class Initialized
INFO - 2018-03-11 09:36:30 --> URI Class Initialized
INFO - 2018-03-11 09:36:30 --> Router Class Initialized
INFO - 2018-03-11 09:36:30 --> Output Class Initialized
INFO - 2018-03-11 09:36:30 --> Security Class Initialized
DEBUG - 2018-03-11 09:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 09:36:30 --> Input Class Initialized
INFO - 2018-03-11 09:36:30 --> Language Class Initialized
INFO - 2018-03-11 09:36:30 --> Loader Class Initialized
INFO - 2018-03-11 09:36:30 --> Helper loaded: url_helper
INFO - 2018-03-11 09:36:30 --> Helper loaded: site_helper
INFO - 2018-03-11 09:36:30 --> Database Driver Class Initialized
INFO - 2018-03-11 09:36:30 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 09:36:30 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 09:36:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 09:36:30 --> Controller Class Initialized
INFO - 2018-03-11 09:36:30 --> Model "user_model" initialized
INFO - 2018-03-11 09:36:30 --> Model "site_model" initialized
INFO - 2018-03-11 09:36:30 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 09:36:30 --> Final output sent to browser
DEBUG - 2018-03-11 09:36:30 --> Total execution time: 0.0266
INFO - 2018-03-11 10:02:17 --> Database Driver Class Initialized
INFO - 2018-03-11 10:02:17 --> Config Class Initialized
INFO - 2018-03-11 10:02:17 --> Hooks Class Initialized
DEBUG - 2018-03-11 10:02:17 --> UTF-8 Support Enabled
INFO - 2018-03-11 10:02:17 --> Utf8 Class Initialized
INFO - 2018-03-11 10:02:17 --> URI Class Initialized
INFO - 2018-03-11 10:02:17 --> Router Class Initialized
INFO - 2018-03-11 10:02:17 --> Output Class Initialized
INFO - 2018-03-11 10:02:17 --> Security Class Initialized
DEBUG - 2018-03-11 10:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 10:02:17 --> Input Class Initialized
INFO - 2018-03-11 10:02:17 --> Language Class Initialized
INFO - 2018-03-11 10:02:17 --> Loader Class Initialized
INFO - 2018-03-11 10:02:17 --> Helper loaded: url_helper
INFO - 2018-03-11 10:02:17 --> Helper loaded: site_helper
INFO - 2018-03-11 10:02:17 --> Database Driver Class Initialized
INFO - 2018-03-11 10:02:17 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 10:02:17 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 10:02:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 10:02:17 --> Controller Class Initialized
INFO - 2018-03-11 10:02:17 --> Model "user_model" initialized
INFO - 2018-03-11 10:02:17 --> Model "site_model" initialized
INFO - 2018-03-11 10:02:17 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 10:02:17 --> Final output sent to browser
DEBUG - 2018-03-11 10:02:17 --> Total execution time: 0.0371
INFO - 2018-03-11 10:03:49 --> Database Driver Class Initialized
INFO - 2018-03-11 10:03:49 --> Config Class Initialized
INFO - 2018-03-11 10:03:49 --> Hooks Class Initialized
DEBUG - 2018-03-11 10:03:49 --> UTF-8 Support Enabled
INFO - 2018-03-11 10:03:49 --> Utf8 Class Initialized
INFO - 2018-03-11 10:03:49 --> URI Class Initialized
INFO - 2018-03-11 10:03:49 --> Router Class Initialized
INFO - 2018-03-11 10:03:49 --> Output Class Initialized
INFO - 2018-03-11 10:03:49 --> Security Class Initialized
DEBUG - 2018-03-11 10:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 10:03:49 --> Input Class Initialized
INFO - 2018-03-11 10:03:49 --> Language Class Initialized
INFO - 2018-03-11 10:03:49 --> Loader Class Initialized
INFO - 2018-03-11 10:03:49 --> Helper loaded: url_helper
INFO - 2018-03-11 10:03:49 --> Helper loaded: site_helper
INFO - 2018-03-11 10:03:49 --> Database Driver Class Initialized
INFO - 2018-03-11 10:03:49 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 10:03:49 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 10:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 10:03:49 --> Controller Class Initialized
INFO - 2018-03-11 10:04:04 --> Database Driver Class Initialized
INFO - 2018-03-11 10:04:04 --> Config Class Initialized
INFO - 2018-03-11 10:04:04 --> Hooks Class Initialized
DEBUG - 2018-03-11 10:04:04 --> UTF-8 Support Enabled
INFO - 2018-03-11 10:04:04 --> Utf8 Class Initialized
INFO - 2018-03-11 10:04:04 --> URI Class Initialized
INFO - 2018-03-11 10:04:04 --> Router Class Initialized
INFO - 2018-03-11 10:04:04 --> Output Class Initialized
INFO - 2018-03-11 10:04:04 --> Security Class Initialized
DEBUG - 2018-03-11 10:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 10:04:04 --> Input Class Initialized
INFO - 2018-03-11 10:04:04 --> Language Class Initialized
INFO - 2018-03-11 10:04:04 --> Loader Class Initialized
INFO - 2018-03-11 10:04:04 --> Helper loaded: url_helper
INFO - 2018-03-11 10:04:04 --> Helper loaded: site_helper
INFO - 2018-03-11 10:04:04 --> Database Driver Class Initialized
INFO - 2018-03-11 10:04:04 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 10:04:04 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 10:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 10:04:04 --> Controller Class Initialized
INFO - 2018-03-11 10:04:04 --> Model "user_model" initialized
INFO - 2018-03-11 10:04:04 --> Model "site_model" initialized
INFO - 2018-03-11 10:04:04 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 10:04:04 --> Final output sent to browser
DEBUG - 2018-03-11 10:04:04 --> Total execution time: 0.0275
INFO - 2018-03-11 10:04:44 --> Database Driver Class Initialized
INFO - 2018-03-11 10:04:44 --> Config Class Initialized
INFO - 2018-03-11 10:04:44 --> Hooks Class Initialized
DEBUG - 2018-03-11 10:04:44 --> UTF-8 Support Enabled
INFO - 2018-03-11 10:04:44 --> Utf8 Class Initialized
INFO - 2018-03-11 10:04:44 --> URI Class Initialized
INFO - 2018-03-11 10:04:44 --> Router Class Initialized
INFO - 2018-03-11 10:04:44 --> Output Class Initialized
INFO - 2018-03-11 10:04:44 --> Security Class Initialized
DEBUG - 2018-03-11 10:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 10:04:44 --> Input Class Initialized
INFO - 2018-03-11 10:04:44 --> Language Class Initialized
INFO - 2018-03-11 10:04:44 --> Loader Class Initialized
INFO - 2018-03-11 10:04:44 --> Helper loaded: url_helper
INFO - 2018-03-11 10:04:44 --> Helper loaded: site_helper
INFO - 2018-03-11 10:04:44 --> Database Driver Class Initialized
INFO - 2018-03-11 10:04:44 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 10:04:44 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 10:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 10:04:44 --> Controller Class Initialized
INFO - 2018-03-11 10:04:44 --> Model "user_model" initialized
INFO - 2018-03-11 10:04:44 --> Model "site_model" initialized
INFO - 2018-03-11 10:04:44 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 10:04:44 --> Final output sent to browser
DEBUG - 2018-03-11 10:04:44 --> Total execution time: 0.0236
INFO - 2018-03-11 10:04:57 --> Database Driver Class Initialized
INFO - 2018-03-11 10:04:57 --> Config Class Initialized
INFO - 2018-03-11 10:04:57 --> Hooks Class Initialized
DEBUG - 2018-03-11 10:04:57 --> UTF-8 Support Enabled
INFO - 2018-03-11 10:04:57 --> Utf8 Class Initialized
INFO - 2018-03-11 10:04:57 --> URI Class Initialized
INFO - 2018-03-11 10:04:57 --> Router Class Initialized
INFO - 2018-03-11 10:04:57 --> Output Class Initialized
INFO - 2018-03-11 10:04:57 --> Security Class Initialized
DEBUG - 2018-03-11 10:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 10:04:57 --> Input Class Initialized
INFO - 2018-03-11 10:04:57 --> Language Class Initialized
INFO - 2018-03-11 10:04:57 --> Loader Class Initialized
INFO - 2018-03-11 10:04:57 --> Helper loaded: url_helper
INFO - 2018-03-11 10:04:57 --> Helper loaded: site_helper
INFO - 2018-03-11 10:04:57 --> Database Driver Class Initialized
INFO - 2018-03-11 10:04:57 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 10:04:57 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 10:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 10:04:57 --> Controller Class Initialized
INFO - 2018-03-11 10:04:57 --> Model "user_model" initialized
INFO - 2018-03-11 10:04:57 --> Model "site_model" initialized
INFO - 2018-03-11 10:04:57 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 10:04:57 --> Final output sent to browser
DEBUG - 2018-03-11 10:04:57 --> Total execution time: 0.0243
INFO - 2018-03-11 10:05:32 --> Database Driver Class Initialized
INFO - 2018-03-11 10:05:32 --> Config Class Initialized
INFO - 2018-03-11 10:05:32 --> Hooks Class Initialized
DEBUG - 2018-03-11 10:05:32 --> UTF-8 Support Enabled
INFO - 2018-03-11 10:05:32 --> Utf8 Class Initialized
INFO - 2018-03-11 10:05:32 --> URI Class Initialized
INFO - 2018-03-11 10:05:32 --> Router Class Initialized
INFO - 2018-03-11 10:05:32 --> Output Class Initialized
INFO - 2018-03-11 10:05:32 --> Security Class Initialized
DEBUG - 2018-03-11 10:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 10:05:32 --> Input Class Initialized
INFO - 2018-03-11 10:05:32 --> Language Class Initialized
INFO - 2018-03-11 10:05:32 --> Loader Class Initialized
INFO - 2018-03-11 10:05:32 --> Helper loaded: url_helper
INFO - 2018-03-11 10:05:32 --> Helper loaded: site_helper
INFO - 2018-03-11 10:05:32 --> Database Driver Class Initialized
INFO - 2018-03-11 10:05:32 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 10:05:32 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 10:05:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 10:05:32 --> Controller Class Initialized
INFO - 2018-03-11 10:05:32 --> Model "user_model" initialized
INFO - 2018-03-11 10:05:32 --> Model "site_model" initialized
INFO - 2018-03-11 10:05:32 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 10:05:32 --> Final output sent to browser
DEBUG - 2018-03-11 10:05:32 --> Total execution time: 0.0210
INFO - 2018-03-11 10:06:03 --> Database Driver Class Initialized
INFO - 2018-03-11 10:06:03 --> Config Class Initialized
INFO - 2018-03-11 10:06:03 --> Hooks Class Initialized
DEBUG - 2018-03-11 10:06:03 --> UTF-8 Support Enabled
INFO - 2018-03-11 10:06:03 --> Utf8 Class Initialized
INFO - 2018-03-11 10:06:03 --> URI Class Initialized
INFO - 2018-03-11 10:06:03 --> Router Class Initialized
INFO - 2018-03-11 10:06:03 --> Output Class Initialized
INFO - 2018-03-11 10:06:03 --> Security Class Initialized
DEBUG - 2018-03-11 10:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 10:06:03 --> Input Class Initialized
INFO - 2018-03-11 10:06:03 --> Language Class Initialized
INFO - 2018-03-11 10:06:03 --> Loader Class Initialized
INFO - 2018-03-11 10:06:03 --> Helper loaded: url_helper
INFO - 2018-03-11 10:06:03 --> Helper loaded: site_helper
INFO - 2018-03-11 10:06:03 --> Database Driver Class Initialized
INFO - 2018-03-11 10:06:03 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 10:06:03 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 10:06:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 10:06:03 --> Controller Class Initialized
INFO - 2018-03-11 10:06:03 --> Model "user_model" initialized
INFO - 2018-03-11 10:06:03 --> Model "site_model" initialized
INFO - 2018-03-11 10:06:03 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 10:06:30 --> Database Driver Class Initialized
INFO - 2018-03-11 10:06:30 --> Config Class Initialized
INFO - 2018-03-11 10:06:30 --> Hooks Class Initialized
DEBUG - 2018-03-11 10:06:30 --> UTF-8 Support Enabled
INFO - 2018-03-11 10:06:30 --> Utf8 Class Initialized
INFO - 2018-03-11 10:06:30 --> URI Class Initialized
INFO - 2018-03-11 10:06:30 --> Router Class Initialized
INFO - 2018-03-11 10:06:30 --> Output Class Initialized
INFO - 2018-03-11 10:06:30 --> Security Class Initialized
DEBUG - 2018-03-11 10:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 10:06:30 --> Input Class Initialized
INFO - 2018-03-11 10:06:30 --> Language Class Initialized
INFO - 2018-03-11 10:06:30 --> Loader Class Initialized
INFO - 2018-03-11 10:06:30 --> Helper loaded: url_helper
INFO - 2018-03-11 10:06:30 --> Helper loaded: site_helper
INFO - 2018-03-11 10:06:30 --> Database Driver Class Initialized
INFO - 2018-03-11 10:06:30 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 10:06:30 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 10:06:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 10:06:30 --> Controller Class Initialized
INFO - 2018-03-11 10:07:13 --> Database Driver Class Initialized
INFO - 2018-03-11 10:07:13 --> Config Class Initialized
INFO - 2018-03-11 10:07:13 --> Hooks Class Initialized
DEBUG - 2018-03-11 10:07:13 --> UTF-8 Support Enabled
INFO - 2018-03-11 10:07:13 --> Utf8 Class Initialized
INFO - 2018-03-11 10:07:13 --> URI Class Initialized
INFO - 2018-03-11 10:07:13 --> Router Class Initialized
INFO - 2018-03-11 10:07:13 --> Output Class Initialized
INFO - 2018-03-11 10:07:13 --> Security Class Initialized
DEBUG - 2018-03-11 10:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 10:07:13 --> Input Class Initialized
INFO - 2018-03-11 10:07:13 --> Language Class Initialized
INFO - 2018-03-11 10:07:13 --> Loader Class Initialized
INFO - 2018-03-11 10:07:13 --> Helper loaded: url_helper
INFO - 2018-03-11 10:07:13 --> Helper loaded: site_helper
INFO - 2018-03-11 10:07:13 --> Database Driver Class Initialized
INFO - 2018-03-11 10:07:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 10:07:13 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 10:07:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 10:07:13 --> Controller Class Initialized
INFO - 2018-03-11 10:09:07 --> Database Driver Class Initialized
INFO - 2018-03-11 10:09:07 --> Config Class Initialized
INFO - 2018-03-11 10:09:07 --> Hooks Class Initialized
DEBUG - 2018-03-11 10:09:07 --> UTF-8 Support Enabled
INFO - 2018-03-11 10:09:07 --> Utf8 Class Initialized
INFO - 2018-03-11 10:09:07 --> URI Class Initialized
DEBUG - 2018-03-11 10:09:07 --> No URI present. Default controller set.
INFO - 2018-03-11 10:09:07 --> Router Class Initialized
INFO - 2018-03-11 10:09:07 --> Output Class Initialized
INFO - 2018-03-11 10:09:07 --> Security Class Initialized
DEBUG - 2018-03-11 10:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 10:09:07 --> Input Class Initialized
INFO - 2018-03-11 10:09:07 --> Language Class Initialized
INFO - 2018-03-11 10:09:07 --> Loader Class Initialized
INFO - 2018-03-11 10:09:07 --> Helper loaded: url_helper
INFO - 2018-03-11 10:09:07 --> Helper loaded: site_helper
INFO - 2018-03-11 10:09:07 --> Database Driver Class Initialized
INFO - 2018-03-11 10:09:07 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 10:09:07 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 10:09:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 10:09:07 --> Controller Class Initialized
INFO - 2018-03-11 10:09:07 --> User Agent Class Initialized
INFO - 2018-03-11 10:09:07 --> Model "site_model" initialized
INFO - 2018-03-11 10:09:07 --> Model "user_model" initialized
INFO - 2018-03-11 10:09:07 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 10:09:07 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-11 10:09:07 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-11 10:09:07 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-11 10:09:07 --> Final output sent to browser
DEBUG - 2018-03-11 10:09:07 --> Total execution time: 0.0475
INFO - 2018-03-11 10:09:40 --> Database Driver Class Initialized
INFO - 2018-03-11 10:09:40 --> Config Class Initialized
INFO - 2018-03-11 10:09:40 --> Hooks Class Initialized
DEBUG - 2018-03-11 10:09:40 --> UTF-8 Support Enabled
INFO - 2018-03-11 10:09:40 --> Utf8 Class Initialized
INFO - 2018-03-11 10:09:40 --> URI Class Initialized
INFO - 2018-03-11 10:09:40 --> Router Class Initialized
INFO - 2018-03-11 10:09:40 --> Output Class Initialized
INFO - 2018-03-11 10:09:40 --> Security Class Initialized
DEBUG - 2018-03-11 10:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 10:09:40 --> Input Class Initialized
INFO - 2018-03-11 10:09:40 --> Language Class Initialized
INFO - 2018-03-11 10:09:40 --> Loader Class Initialized
INFO - 2018-03-11 10:09:40 --> Helper loaded: url_helper
INFO - 2018-03-11 10:09:40 --> Helper loaded: site_helper
INFO - 2018-03-11 10:09:40 --> Database Driver Class Initialized
INFO - 2018-03-11 10:09:40 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 10:09:40 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 10:09:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 10:09:40 --> Controller Class Initialized
INFO - 2018-03-11 10:11:42 --> Database Driver Class Initialized
INFO - 2018-03-11 10:11:42 --> Config Class Initialized
INFO - 2018-03-11 10:11:42 --> Hooks Class Initialized
DEBUG - 2018-03-11 10:11:42 --> UTF-8 Support Enabled
INFO - 2018-03-11 10:11:42 --> Utf8 Class Initialized
INFO - 2018-03-11 10:11:42 --> URI Class Initialized
DEBUG - 2018-03-11 10:11:42 --> No URI present. Default controller set.
INFO - 2018-03-11 10:11:42 --> Router Class Initialized
INFO - 2018-03-11 10:11:42 --> Output Class Initialized
INFO - 2018-03-11 10:11:42 --> Security Class Initialized
DEBUG - 2018-03-11 10:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 10:11:42 --> Input Class Initialized
INFO - 2018-03-11 10:11:42 --> Language Class Initialized
INFO - 2018-03-11 10:11:42 --> Loader Class Initialized
INFO - 2018-03-11 10:11:42 --> Helper loaded: url_helper
INFO - 2018-03-11 10:11:42 --> Helper loaded: site_helper
INFO - 2018-03-11 10:11:42 --> Database Driver Class Initialized
INFO - 2018-03-11 10:11:42 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 10:11:42 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 10:11:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 10:11:42 --> Controller Class Initialized
INFO - 2018-03-11 10:11:42 --> User Agent Class Initialized
INFO - 2018-03-11 10:11:42 --> Model "site_model" initialized
INFO - 2018-03-11 10:11:42 --> Model "user_model" initialized
INFO - 2018-03-11 10:11:42 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 10:11:42 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-11 10:11:42 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-11 10:11:42 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-11 10:11:42 --> Final output sent to browser
DEBUG - 2018-03-11 10:11:42 --> Total execution time: 0.0230
INFO - 2018-03-11 10:12:09 --> Database Driver Class Initialized
INFO - 2018-03-11 10:12:09 --> Config Class Initialized
INFO - 2018-03-11 10:12:09 --> Hooks Class Initialized
DEBUG - 2018-03-11 10:12:09 --> UTF-8 Support Enabled
INFO - 2018-03-11 10:12:09 --> Utf8 Class Initialized
INFO - 2018-03-11 10:12:09 --> URI Class Initialized
INFO - 2018-03-11 10:12:09 --> Router Class Initialized
INFO - 2018-03-11 10:12:09 --> Output Class Initialized
INFO - 2018-03-11 10:12:09 --> Security Class Initialized
DEBUG - 2018-03-11 10:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 10:12:09 --> Input Class Initialized
INFO - 2018-03-11 10:12:09 --> Language Class Initialized
INFO - 2018-03-11 10:12:09 --> Loader Class Initialized
INFO - 2018-03-11 10:12:09 --> Helper loaded: url_helper
INFO - 2018-03-11 10:12:09 --> Helper loaded: site_helper
INFO - 2018-03-11 10:12:09 --> Database Driver Class Initialized
INFO - 2018-03-11 10:12:09 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 10:12:09 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 10:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 10:12:09 --> Controller Class Initialized
INFO - 2018-03-11 10:12:41 --> Database Driver Class Initialized
INFO - 2018-03-11 10:12:41 --> Config Class Initialized
INFO - 2018-03-11 10:12:41 --> Hooks Class Initialized
DEBUG - 2018-03-11 10:12:41 --> UTF-8 Support Enabled
INFO - 2018-03-11 10:12:41 --> Utf8 Class Initialized
INFO - 2018-03-11 10:12:41 --> URI Class Initialized
INFO - 2018-03-11 10:12:41 --> Router Class Initialized
INFO - 2018-03-11 10:12:41 --> Output Class Initialized
INFO - 2018-03-11 10:12:41 --> Security Class Initialized
DEBUG - 2018-03-11 10:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 10:12:41 --> Input Class Initialized
INFO - 2018-03-11 10:12:41 --> Language Class Initialized
INFO - 2018-03-11 10:12:41 --> Loader Class Initialized
INFO - 2018-03-11 10:12:41 --> Helper loaded: url_helper
INFO - 2018-03-11 10:12:41 --> Helper loaded: site_helper
INFO - 2018-03-11 10:12:41 --> Database Driver Class Initialized
INFO - 2018-03-11 10:12:41 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 10:12:41 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 10:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 10:12:41 --> Controller Class Initialized
INFO - 2018-03-11 10:12:41 --> Model "user_model" initialized
INFO - 2018-03-11 10:12:41 --> Model "site_model" initialized
INFO - 2018-03-11 10:12:41 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 10:12:41 --> Final output sent to browser
DEBUG - 2018-03-11 10:12:41 --> Total execution time: 0.0454
INFO - 2018-03-11 10:12:42 --> Database Driver Class Initialized
INFO - 2018-03-11 10:12:42 --> Config Class Initialized
INFO - 2018-03-11 10:12:42 --> Hooks Class Initialized
DEBUG - 2018-03-11 10:12:42 --> UTF-8 Support Enabled
INFO - 2018-03-11 10:12:42 --> Utf8 Class Initialized
INFO - 2018-03-11 10:12:42 --> URI Class Initialized
INFO - 2018-03-11 10:12:42 --> Router Class Initialized
INFO - 2018-03-11 10:12:42 --> Output Class Initialized
INFO - 2018-03-11 10:12:42 --> Security Class Initialized
DEBUG - 2018-03-11 10:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 10:12:42 --> Input Class Initialized
INFO - 2018-03-11 10:12:42 --> Language Class Initialized
INFO - 2018-03-11 10:12:42 --> Loader Class Initialized
INFO - 2018-03-11 10:12:42 --> Helper loaded: url_helper
INFO - 2018-03-11 10:12:42 --> Helper loaded: site_helper
INFO - 2018-03-11 10:12:42 --> Database Driver Class Initialized
INFO - 2018-03-11 10:12:42 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 10:12:42 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 10:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 10:12:42 --> Controller Class Initialized
INFO - 2018-03-11 10:12:43 --> Model "user_model" initialized
INFO - 2018-03-11 10:12:43 --> Model "site_model" initialized
INFO - 2018-03-11 10:12:43 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 10:12:43 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:08:09 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:09 --> Config Class Initialized
INFO - 2018-03-11 13:08:09 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:08:09 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:08:09 --> Utf8 Class Initialized
INFO - 2018-03-11 13:08:09 --> URI Class Initialized
INFO - 2018-03-11 13:08:09 --> Router Class Initialized
INFO - 2018-03-11 13:08:09 --> Output Class Initialized
INFO - 2018-03-11 13:08:09 --> Security Class Initialized
DEBUG - 2018-03-11 13:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:08:09 --> Input Class Initialized
INFO - 2018-03-11 13:08:09 --> Language Class Initialized
INFO - 2018-03-11 13:08:09 --> Loader Class Initialized
INFO - 2018-03-11 13:08:09 --> Helper loaded: url_helper
INFO - 2018-03-11 13:08:09 --> Helper loaded: site_helper
INFO - 2018-03-11 13:08:09 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:09 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:08:09 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:08:09 --> Controller Class Initialized
INFO - 2018-03-11 13:08:09 --> Model "user_model" initialized
INFO - 2018-03-11 13:08:09 --> Model "site_model" initialized
INFO - 2018-03-11 13:08:09 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:08:09 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:08:11 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:11 --> Config Class Initialized
INFO - 2018-03-11 13:08:11 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:08:11 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:08:11 --> Utf8 Class Initialized
INFO - 2018-03-11 13:08:11 --> URI Class Initialized
DEBUG - 2018-03-11 13:08:11 --> No URI present. Default controller set.
INFO - 2018-03-11 13:08:11 --> Router Class Initialized
INFO - 2018-03-11 13:08:11 --> Output Class Initialized
INFO - 2018-03-11 13:08:11 --> Security Class Initialized
DEBUG - 2018-03-11 13:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:08:11 --> Input Class Initialized
INFO - 2018-03-11 13:08:11 --> Language Class Initialized
INFO - 2018-03-11 13:08:11 --> Loader Class Initialized
INFO - 2018-03-11 13:08:11 --> Helper loaded: url_helper
INFO - 2018-03-11 13:08:11 --> Helper loaded: site_helper
INFO - 2018-03-11 13:08:11 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:11 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:08:11 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:08:11 --> Controller Class Initialized
INFO - 2018-03-11 13:08:11 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:11 --> Config Class Initialized
INFO - 2018-03-11 13:08:11 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:08:11 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:08:11 --> Utf8 Class Initialized
INFO - 2018-03-11 13:08:11 --> URI Class Initialized
INFO - 2018-03-11 13:08:11 --> Router Class Initialized
INFO - 2018-03-11 13:08:11 --> Output Class Initialized
INFO - 2018-03-11 13:08:11 --> Security Class Initialized
DEBUG - 2018-03-11 13:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:08:11 --> Input Class Initialized
INFO - 2018-03-11 13:08:11 --> Language Class Initialized
INFO - 2018-03-11 13:08:11 --> Loader Class Initialized
INFO - 2018-03-11 13:08:11 --> Helper loaded: url_helper
INFO - 2018-03-11 13:08:11 --> Helper loaded: site_helper
INFO - 2018-03-11 13:08:11 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:11 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:08:11 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:08:11 --> Controller Class Initialized
INFO - 2018-03-11 13:08:11 --> Model "user_model" initialized
INFO - 2018-03-11 13:08:11 --> Model "site_model" initialized
INFO - 2018-03-11 13:08:11 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:08:11 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:08:11 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:11 --> Config Class Initialized
INFO - 2018-03-11 13:08:11 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:08:11 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:08:11 --> Utf8 Class Initialized
INFO - 2018-03-11 13:08:11 --> URI Class Initialized
INFO - 2018-03-11 13:08:11 --> Router Class Initialized
INFO - 2018-03-11 13:08:11 --> Output Class Initialized
INFO - 2018-03-11 13:08:11 --> Security Class Initialized
DEBUG - 2018-03-11 13:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:08:11 --> Input Class Initialized
INFO - 2018-03-11 13:08:11 --> Language Class Initialized
INFO - 2018-03-11 13:08:11 --> Loader Class Initialized
INFO - 2018-03-11 13:08:11 --> Helper loaded: url_helper
INFO - 2018-03-11 13:08:11 --> Helper loaded: site_helper
INFO - 2018-03-11 13:08:11 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:11 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:08:11 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:08:11 --> Controller Class Initialized
INFO - 2018-03-11 13:08:11 --> Model "user_model" initialized
INFO - 2018-03-11 13:08:11 --> Model "site_model" initialized
INFO - 2018-03-11 13:08:11 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:08:11 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:08:13 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:13 --> Config Class Initialized
INFO - 2018-03-11 13:08:13 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:08:13 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:08:13 --> Utf8 Class Initialized
INFO - 2018-03-11 13:08:13 --> URI Class Initialized
DEBUG - 2018-03-11 13:08:13 --> No URI present. Default controller set.
INFO - 2018-03-11 13:08:13 --> Router Class Initialized
INFO - 2018-03-11 13:08:13 --> Output Class Initialized
INFO - 2018-03-11 13:08:13 --> Security Class Initialized
DEBUG - 2018-03-11 13:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:08:13 --> Input Class Initialized
INFO - 2018-03-11 13:08:13 --> Language Class Initialized
INFO - 2018-03-11 13:08:13 --> Loader Class Initialized
INFO - 2018-03-11 13:08:13 --> Helper loaded: url_helper
INFO - 2018-03-11 13:08:13 --> Helper loaded: site_helper
INFO - 2018-03-11 13:08:13 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:08:13 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:08:13 --> Controller Class Initialized
INFO - 2018-03-11 13:08:13 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:13 --> Config Class Initialized
INFO - 2018-03-11 13:08:13 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:08:13 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:08:13 --> Utf8 Class Initialized
INFO - 2018-03-11 13:08:13 --> URI Class Initialized
INFO - 2018-03-11 13:08:13 --> Router Class Initialized
INFO - 2018-03-11 13:08:13 --> Output Class Initialized
INFO - 2018-03-11 13:08:13 --> Security Class Initialized
DEBUG - 2018-03-11 13:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:08:13 --> Input Class Initialized
INFO - 2018-03-11 13:08:13 --> Language Class Initialized
INFO - 2018-03-11 13:08:13 --> Loader Class Initialized
INFO - 2018-03-11 13:08:13 --> Helper loaded: url_helper
INFO - 2018-03-11 13:08:13 --> Helper loaded: site_helper
INFO - 2018-03-11 13:08:13 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:08:13 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:08:13 --> Controller Class Initialized
INFO - 2018-03-11 13:08:13 --> Model "user_model" initialized
INFO - 2018-03-11 13:08:13 --> Model "site_model" initialized
INFO - 2018-03-11 13:08:13 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:08:13 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:08:13 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:13 --> Config Class Initialized
INFO - 2018-03-11 13:08:13 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:08:14 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:08:14 --> Utf8 Class Initialized
INFO - 2018-03-11 13:08:14 --> URI Class Initialized
INFO - 2018-03-11 13:08:14 --> Router Class Initialized
INFO - 2018-03-11 13:08:14 --> Output Class Initialized
INFO - 2018-03-11 13:08:14 --> Security Class Initialized
DEBUG - 2018-03-11 13:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:08:14 --> Input Class Initialized
INFO - 2018-03-11 13:08:14 --> Language Class Initialized
INFO - 2018-03-11 13:08:14 --> Loader Class Initialized
INFO - 2018-03-11 13:08:14 --> Helper loaded: url_helper
INFO - 2018-03-11 13:08:14 --> Helper loaded: site_helper
INFO - 2018-03-11 13:08:14 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:14 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:08:14 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:08:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:08:14 --> Controller Class Initialized
INFO - 2018-03-11 13:08:14 --> Model "user_model" initialized
INFO - 2018-03-11 13:08:14 --> Model "site_model" initialized
INFO - 2018-03-11 13:08:14 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:08:14 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:08:15 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:15 --> Config Class Initialized
INFO - 2018-03-11 13:08:15 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:08:15 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:08:15 --> Utf8 Class Initialized
INFO - 2018-03-11 13:08:15 --> URI Class Initialized
DEBUG - 2018-03-11 13:08:15 --> No URI present. Default controller set.
INFO - 2018-03-11 13:08:15 --> Router Class Initialized
INFO - 2018-03-11 13:08:15 --> Output Class Initialized
INFO - 2018-03-11 13:08:15 --> Security Class Initialized
DEBUG - 2018-03-11 13:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:08:15 --> Input Class Initialized
INFO - 2018-03-11 13:08:15 --> Language Class Initialized
INFO - 2018-03-11 13:08:15 --> Loader Class Initialized
INFO - 2018-03-11 13:08:15 --> Helper loaded: url_helper
INFO - 2018-03-11 13:08:15 --> Helper loaded: site_helper
INFO - 2018-03-11 13:08:15 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:15 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:08:15 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:08:15 --> Controller Class Initialized
INFO - 2018-03-11 13:08:15 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:15 --> Config Class Initialized
INFO - 2018-03-11 13:08:15 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:08:15 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:08:15 --> Utf8 Class Initialized
INFO - 2018-03-11 13:08:15 --> URI Class Initialized
INFO - 2018-03-11 13:08:15 --> Router Class Initialized
INFO - 2018-03-11 13:08:15 --> Output Class Initialized
INFO - 2018-03-11 13:08:15 --> Security Class Initialized
DEBUG - 2018-03-11 13:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:08:15 --> Input Class Initialized
INFO - 2018-03-11 13:08:15 --> Language Class Initialized
INFO - 2018-03-11 13:08:15 --> Loader Class Initialized
INFO - 2018-03-11 13:08:15 --> Helper loaded: url_helper
INFO - 2018-03-11 13:08:15 --> Helper loaded: site_helper
INFO - 2018-03-11 13:08:15 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:15 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:08:15 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:08:15 --> Controller Class Initialized
INFO - 2018-03-11 13:08:15 --> Model "user_model" initialized
INFO - 2018-03-11 13:08:15 --> Model "site_model" initialized
INFO - 2018-03-11 13:08:15 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:08:15 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:08:15 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:15 --> Config Class Initialized
INFO - 2018-03-11 13:08:15 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:08:15 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:08:15 --> Utf8 Class Initialized
INFO - 2018-03-11 13:08:15 --> URI Class Initialized
INFO - 2018-03-11 13:08:15 --> Router Class Initialized
INFO - 2018-03-11 13:08:15 --> Output Class Initialized
INFO - 2018-03-11 13:08:15 --> Security Class Initialized
DEBUG - 2018-03-11 13:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:08:15 --> Input Class Initialized
INFO - 2018-03-11 13:08:15 --> Language Class Initialized
INFO - 2018-03-11 13:08:15 --> Loader Class Initialized
INFO - 2018-03-11 13:08:15 --> Helper loaded: url_helper
INFO - 2018-03-11 13:08:15 --> Helper loaded: site_helper
INFO - 2018-03-11 13:08:15 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:15 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:08:15 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:08:15 --> Controller Class Initialized
INFO - 2018-03-11 13:08:15 --> Model "user_model" initialized
INFO - 2018-03-11 13:08:15 --> Model "site_model" initialized
INFO - 2018-03-11 13:08:15 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:08:15 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:08:16 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:16 --> Config Class Initialized
INFO - 2018-03-11 13:08:16 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:08:16 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:08:16 --> Utf8 Class Initialized
INFO - 2018-03-11 13:08:16 --> URI Class Initialized
DEBUG - 2018-03-11 13:08:16 --> No URI present. Default controller set.
INFO - 2018-03-11 13:08:16 --> Router Class Initialized
INFO - 2018-03-11 13:08:16 --> Output Class Initialized
INFO - 2018-03-11 13:08:16 --> Security Class Initialized
DEBUG - 2018-03-11 13:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:08:16 --> Input Class Initialized
INFO - 2018-03-11 13:08:16 --> Language Class Initialized
INFO - 2018-03-11 13:08:16 --> Loader Class Initialized
INFO - 2018-03-11 13:08:16 --> Helper loaded: url_helper
INFO - 2018-03-11 13:08:16 --> Helper loaded: site_helper
INFO - 2018-03-11 13:08:16 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:16 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:08:16 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:08:16 --> Controller Class Initialized
INFO - 2018-03-11 13:08:16 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:16 --> Config Class Initialized
INFO - 2018-03-11 13:08:16 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:08:16 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:08:16 --> Utf8 Class Initialized
INFO - 2018-03-11 13:08:16 --> URI Class Initialized
INFO - 2018-03-11 13:08:16 --> Router Class Initialized
INFO - 2018-03-11 13:08:16 --> Output Class Initialized
INFO - 2018-03-11 13:08:16 --> Security Class Initialized
DEBUG - 2018-03-11 13:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:08:16 --> Input Class Initialized
INFO - 2018-03-11 13:08:16 --> Language Class Initialized
INFO - 2018-03-11 13:08:16 --> Loader Class Initialized
INFO - 2018-03-11 13:08:16 --> Helper loaded: url_helper
INFO - 2018-03-11 13:08:16 --> Helper loaded: site_helper
INFO - 2018-03-11 13:08:16 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:16 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:08:16 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:08:16 --> Controller Class Initialized
INFO - 2018-03-11 13:08:16 --> Model "user_model" initialized
INFO - 2018-03-11 13:08:16 --> Model "site_model" initialized
INFO - 2018-03-11 13:08:16 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:08:16 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:08:16 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:16 --> Config Class Initialized
INFO - 2018-03-11 13:08:16 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:08:16 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:08:16 --> Utf8 Class Initialized
INFO - 2018-03-11 13:08:16 --> URI Class Initialized
INFO - 2018-03-11 13:08:16 --> Router Class Initialized
INFO - 2018-03-11 13:08:16 --> Output Class Initialized
INFO - 2018-03-11 13:08:16 --> Security Class Initialized
DEBUG - 2018-03-11 13:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:08:16 --> Input Class Initialized
INFO - 2018-03-11 13:08:16 --> Language Class Initialized
INFO - 2018-03-11 13:08:16 --> Loader Class Initialized
INFO - 2018-03-11 13:08:16 --> Helper loaded: url_helper
INFO - 2018-03-11 13:08:16 --> Helper loaded: site_helper
INFO - 2018-03-11 13:08:16 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:16 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:08:16 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:08:16 --> Controller Class Initialized
INFO - 2018-03-11 13:08:16 --> Model "user_model" initialized
INFO - 2018-03-11 13:08:16 --> Model "site_model" initialized
INFO - 2018-03-11 13:08:16 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:08:16 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:08:33 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:33 --> Config Class Initialized
INFO - 2018-03-11 13:08:33 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:08:33 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:08:33 --> Utf8 Class Initialized
INFO - 2018-03-11 13:08:33 --> URI Class Initialized
DEBUG - 2018-03-11 13:08:33 --> No URI present. Default controller set.
INFO - 2018-03-11 13:08:33 --> Router Class Initialized
INFO - 2018-03-11 13:08:33 --> Output Class Initialized
INFO - 2018-03-11 13:08:33 --> Security Class Initialized
DEBUG - 2018-03-11 13:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:08:33 --> Input Class Initialized
INFO - 2018-03-11 13:08:33 --> Language Class Initialized
INFO - 2018-03-11 13:08:33 --> Loader Class Initialized
INFO - 2018-03-11 13:08:33 --> Helper loaded: url_helper
INFO - 2018-03-11 13:08:33 --> Helper loaded: site_helper
INFO - 2018-03-11 13:08:33 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:33 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:08:33 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:08:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:08:33 --> Controller Class Initialized
INFO - 2018-03-11 13:08:33 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:33 --> Config Class Initialized
INFO - 2018-03-11 13:08:33 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:08:33 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:08:33 --> Utf8 Class Initialized
INFO - 2018-03-11 13:08:33 --> URI Class Initialized
INFO - 2018-03-11 13:08:33 --> Router Class Initialized
INFO - 2018-03-11 13:08:33 --> Output Class Initialized
INFO - 2018-03-11 13:08:33 --> Security Class Initialized
DEBUG - 2018-03-11 13:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:08:33 --> Input Class Initialized
INFO - 2018-03-11 13:08:33 --> Language Class Initialized
INFO - 2018-03-11 13:08:33 --> Loader Class Initialized
INFO - 2018-03-11 13:08:33 --> Helper loaded: url_helper
INFO - 2018-03-11 13:08:33 --> Helper loaded: site_helper
INFO - 2018-03-11 13:08:33 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:33 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:08:33 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:08:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:08:33 --> Controller Class Initialized
INFO - 2018-03-11 13:08:33 --> Model "user_model" initialized
INFO - 2018-03-11 13:08:33 --> Model "site_model" initialized
INFO - 2018-03-11 13:08:33 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:08:33 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:08:33 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:33 --> Config Class Initialized
INFO - 2018-03-11 13:08:33 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:08:33 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:08:33 --> Utf8 Class Initialized
INFO - 2018-03-11 13:08:33 --> URI Class Initialized
INFO - 2018-03-11 13:08:33 --> Router Class Initialized
INFO - 2018-03-11 13:08:33 --> Output Class Initialized
INFO - 2018-03-11 13:08:33 --> Security Class Initialized
DEBUG - 2018-03-11 13:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:08:33 --> Input Class Initialized
INFO - 2018-03-11 13:08:33 --> Language Class Initialized
INFO - 2018-03-11 13:08:33 --> Loader Class Initialized
INFO - 2018-03-11 13:08:33 --> Helper loaded: url_helper
INFO - 2018-03-11 13:08:33 --> Helper loaded: site_helper
INFO - 2018-03-11 13:08:33 --> Database Driver Class Initialized
INFO - 2018-03-11 13:08:33 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:08:33 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:08:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:08:33 --> Controller Class Initialized
INFO - 2018-03-11 13:08:33 --> Model "user_model" initialized
INFO - 2018-03-11 13:08:33 --> Model "site_model" initialized
INFO - 2018-03-11 13:08:33 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:08:33 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:09:17 --> Database Driver Class Initialized
INFO - 2018-03-11 13:09:17 --> Config Class Initialized
INFO - 2018-03-11 13:09:17 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:09:17 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:09:17 --> Utf8 Class Initialized
INFO - 2018-03-11 13:09:17 --> URI Class Initialized
INFO - 2018-03-11 13:09:17 --> Router Class Initialized
INFO - 2018-03-11 13:09:17 --> Output Class Initialized
INFO - 2018-03-11 13:09:17 --> Security Class Initialized
DEBUG - 2018-03-11 13:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:09:17 --> Input Class Initialized
INFO - 2018-03-11 13:09:17 --> Language Class Initialized
INFO - 2018-03-11 13:09:17 --> Loader Class Initialized
INFO - 2018-03-11 13:09:17 --> Helper loaded: url_helper
INFO - 2018-03-11 13:09:17 --> Helper loaded: site_helper
INFO - 2018-03-11 13:09:17 --> Database Driver Class Initialized
INFO - 2018-03-11 13:09:17 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:09:17 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:09:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:09:17 --> Controller Class Initialized
INFO - 2018-03-11 13:09:17 --> Database Driver Class Initialized
INFO - 2018-03-11 13:09:17 --> Config Class Initialized
INFO - 2018-03-11 13:09:17 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:09:17 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:09:17 --> Utf8 Class Initialized
INFO - 2018-03-11 13:09:17 --> URI Class Initialized
DEBUG - 2018-03-11 13:09:17 --> No URI present. Default controller set.
INFO - 2018-03-11 13:09:17 --> Router Class Initialized
INFO - 2018-03-11 13:09:17 --> Output Class Initialized
INFO - 2018-03-11 13:09:17 --> Security Class Initialized
DEBUG - 2018-03-11 13:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:09:17 --> Input Class Initialized
INFO - 2018-03-11 13:09:17 --> Language Class Initialized
INFO - 2018-03-11 13:09:17 --> Loader Class Initialized
INFO - 2018-03-11 13:09:17 --> Helper loaded: url_helper
INFO - 2018-03-11 13:09:17 --> Helper loaded: site_helper
INFO - 2018-03-11 13:09:17 --> Database Driver Class Initialized
INFO - 2018-03-11 13:09:17 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:09:17 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:09:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:09:17 --> Controller Class Initialized
INFO - 2018-03-11 13:09:17 --> User Agent Class Initialized
INFO - 2018-03-11 13:09:17 --> Model "site_model" initialized
INFO - 2018-03-11 13:09:17 --> Model "user_model" initialized
INFO - 2018-03-11 13:09:17 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:09:17 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-11 13:09:17 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-11 13:09:17 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-11 13:09:17 --> Final output sent to browser
DEBUG - 2018-03-11 13:09:17 --> Total execution time: 0.0228
INFO - 2018-03-11 13:17:08 --> Database Driver Class Initialized
INFO - 2018-03-11 13:17:08 --> Config Class Initialized
INFO - 2018-03-11 13:17:08 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:17:08 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:17:08 --> Utf8 Class Initialized
INFO - 2018-03-11 13:17:08 --> URI Class Initialized
DEBUG - 2018-03-11 13:17:08 --> No URI present. Default controller set.
INFO - 2018-03-11 13:17:08 --> Router Class Initialized
INFO - 2018-03-11 13:17:08 --> Output Class Initialized
INFO - 2018-03-11 13:17:08 --> Security Class Initialized
DEBUG - 2018-03-11 13:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:17:08 --> Input Class Initialized
INFO - 2018-03-11 13:17:08 --> Language Class Initialized
INFO - 2018-03-11 13:17:08 --> Loader Class Initialized
INFO - 2018-03-11 13:17:08 --> Helper loaded: url_helper
INFO - 2018-03-11 13:17:08 --> Helper loaded: site_helper
INFO - 2018-03-11 13:17:08 --> Database Driver Class Initialized
INFO - 2018-03-11 13:17:08 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:17:08 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:17:08 --> Controller Class Initialized
INFO - 2018-03-11 13:17:08 --> User Agent Class Initialized
INFO - 2018-03-11 13:17:08 --> Model "site_model" initialized
INFO - 2018-03-11 13:17:08 --> Model "user_model" initialized
INFO - 2018-03-11 13:17:08 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:17:08 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-11 13:17:08 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-11 13:17:08 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-11 13:17:08 --> Final output sent to browser
DEBUG - 2018-03-11 13:17:08 --> Total execution time: 0.0448
INFO - 2018-03-11 13:17:31 --> Database Driver Class Initialized
INFO - 2018-03-11 13:17:31 --> Config Class Initialized
INFO - 2018-03-11 13:17:31 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:17:31 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:17:31 --> Utf8 Class Initialized
INFO - 2018-03-11 13:17:31 --> URI Class Initialized
INFO - 2018-03-11 13:17:31 --> Router Class Initialized
INFO - 2018-03-11 13:17:31 --> Output Class Initialized
INFO - 2018-03-11 13:17:31 --> Security Class Initialized
DEBUG - 2018-03-11 13:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:17:31 --> Input Class Initialized
INFO - 2018-03-11 13:17:31 --> Language Class Initialized
INFO - 2018-03-11 13:17:31 --> Loader Class Initialized
INFO - 2018-03-11 13:17:31 --> Helper loaded: url_helper
INFO - 2018-03-11 13:17:31 --> Helper loaded: site_helper
INFO - 2018-03-11 13:17:31 --> Database Driver Class Initialized
INFO - 2018-03-11 13:17:31 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:17:31 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:17:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:17:31 --> Controller Class Initialized
INFO - 2018-03-11 13:17:31 --> Model "user_model" initialized
INFO - 2018-03-11 13:17:31 --> Model "site_model" initialized
INFO - 2018-03-11 13:17:31 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:17:31 --> Final output sent to browser
DEBUG - 2018-03-11 13:17:31 --> Total execution time: 0.0343
INFO - 2018-03-11 13:19:22 --> Database Driver Class Initialized
INFO - 2018-03-11 13:19:22 --> Config Class Initialized
INFO - 2018-03-11 13:19:22 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:19:22 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:19:22 --> Utf8 Class Initialized
INFO - 2018-03-11 13:19:22 --> URI Class Initialized
DEBUG - 2018-03-11 13:19:22 --> No URI present. Default controller set.
INFO - 2018-03-11 13:19:22 --> Router Class Initialized
INFO - 2018-03-11 13:19:22 --> Output Class Initialized
INFO - 2018-03-11 13:19:22 --> Security Class Initialized
DEBUG - 2018-03-11 13:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:19:22 --> Input Class Initialized
INFO - 2018-03-11 13:19:22 --> Language Class Initialized
INFO - 2018-03-11 13:19:22 --> Loader Class Initialized
INFO - 2018-03-11 13:19:22 --> Helper loaded: url_helper
INFO - 2018-03-11 13:19:22 --> Helper loaded: site_helper
INFO - 2018-03-11 13:19:22 --> Database Driver Class Initialized
INFO - 2018-03-11 13:19:22 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:19:22 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:19:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:19:22 --> Controller Class Initialized
INFO - 2018-03-11 13:19:22 --> User Agent Class Initialized
INFO - 2018-03-11 13:19:22 --> Model "site_model" initialized
INFO - 2018-03-11 13:19:22 --> Model "user_model" initialized
INFO - 2018-03-11 13:19:22 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:19:22 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-11 13:19:22 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-11 13:19:22 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-11 13:19:22 --> Final output sent to browser
DEBUG - 2018-03-11 13:19:22 --> Total execution time: 0.0261
INFO - 2018-03-11 13:19:37 --> Database Driver Class Initialized
INFO - 2018-03-11 13:19:37 --> Config Class Initialized
INFO - 2018-03-11 13:19:37 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:19:37 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:19:37 --> Utf8 Class Initialized
INFO - 2018-03-11 13:19:37 --> URI Class Initialized
INFO - 2018-03-11 13:19:37 --> Router Class Initialized
INFO - 2018-03-11 13:19:37 --> Output Class Initialized
INFO - 2018-03-11 13:19:37 --> Security Class Initialized
DEBUG - 2018-03-11 13:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:19:37 --> Input Class Initialized
INFO - 2018-03-11 13:19:37 --> Language Class Initialized
INFO - 2018-03-11 13:19:37 --> Loader Class Initialized
INFO - 2018-03-11 13:19:37 --> Helper loaded: url_helper
INFO - 2018-03-11 13:19:37 --> Helper loaded: site_helper
INFO - 2018-03-11 13:19:37 --> Database Driver Class Initialized
INFO - 2018-03-11 13:19:37 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:19:37 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:19:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:19:37 --> Controller Class Initialized
INFO - 2018-03-11 13:19:37 --> Model "user_model" initialized
INFO - 2018-03-11 13:19:37 --> Model "site_model" initialized
INFO - 2018-03-11 13:19:37 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:19:37 --> Final output sent to browser
DEBUG - 2018-03-11 13:19:37 --> Total execution time: 0.0206
INFO - 2018-03-11 13:19:46 --> Database Driver Class Initialized
INFO - 2018-03-11 13:19:46 --> Config Class Initialized
INFO - 2018-03-11 13:19:46 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:19:46 --> Utf8 Class Initialized
INFO - 2018-03-11 13:19:46 --> URI Class Initialized
INFO - 2018-03-11 13:19:46 --> Router Class Initialized
INFO - 2018-03-11 13:19:46 --> Output Class Initialized
INFO - 2018-03-11 13:19:46 --> Security Class Initialized
DEBUG - 2018-03-11 13:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:19:46 --> Input Class Initialized
INFO - 2018-03-11 13:19:46 --> Language Class Initialized
INFO - 2018-03-11 13:19:46 --> Loader Class Initialized
INFO - 2018-03-11 13:19:46 --> Helper loaded: url_helper
INFO - 2018-03-11 13:19:46 --> Helper loaded: site_helper
INFO - 2018-03-11 13:19:46 --> Database Driver Class Initialized
INFO - 2018-03-11 13:19:46 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:19:46 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:19:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:19:46 --> Controller Class Initialized
INFO - 2018-03-11 13:19:46 --> Model "user_model" initialized
INFO - 2018-03-11 13:19:46 --> Model "site_model" initialized
INFO - 2018-03-11 13:19:46 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:19:46 --> Final output sent to browser
DEBUG - 2018-03-11 13:19:46 --> Total execution time: 0.0213
INFO - 2018-03-11 13:19:46 --> Database Driver Class Initialized
INFO - 2018-03-11 13:19:46 --> Config Class Initialized
INFO - 2018-03-11 13:19:46 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:19:46 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:19:46 --> Utf8 Class Initialized
INFO - 2018-03-11 13:19:46 --> URI Class Initialized
INFO - 2018-03-11 13:19:46 --> Router Class Initialized
INFO - 2018-03-11 13:19:46 --> Output Class Initialized
INFO - 2018-03-11 13:19:46 --> Security Class Initialized
DEBUG - 2018-03-11 13:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:19:46 --> Input Class Initialized
INFO - 2018-03-11 13:19:46 --> Language Class Initialized
INFO - 2018-03-11 13:19:46 --> Loader Class Initialized
INFO - 2018-03-11 13:19:46 --> Helper loaded: url_helper
INFO - 2018-03-11 13:19:46 --> Helper loaded: site_helper
INFO - 2018-03-11 13:19:46 --> Database Driver Class Initialized
INFO - 2018-03-11 13:19:46 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:19:46 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:19:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:19:46 --> Controller Class Initialized
INFO - 2018-03-11 13:19:46 --> Model "user_model" initialized
INFO - 2018-03-11 13:19:46 --> Model "site_model" initialized
INFO - 2018-03-11 13:19:46 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:19:46 --> Final output sent to browser
DEBUG - 2018-03-11 13:19:46 --> Total execution time: 0.0178
INFO - 2018-03-11 13:19:47 --> Database Driver Class Initialized
INFO - 2018-03-11 13:19:47 --> Config Class Initialized
INFO - 2018-03-11 13:19:47 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:19:47 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:19:47 --> Utf8 Class Initialized
INFO - 2018-03-11 13:19:47 --> URI Class Initialized
INFO - 2018-03-11 13:19:47 --> Router Class Initialized
INFO - 2018-03-11 13:19:47 --> Output Class Initialized
INFO - 2018-03-11 13:19:47 --> Security Class Initialized
DEBUG - 2018-03-11 13:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:19:47 --> Input Class Initialized
INFO - 2018-03-11 13:19:47 --> Language Class Initialized
INFO - 2018-03-11 13:19:47 --> Loader Class Initialized
INFO - 2018-03-11 13:19:47 --> Helper loaded: url_helper
INFO - 2018-03-11 13:19:47 --> Helper loaded: site_helper
INFO - 2018-03-11 13:19:47 --> Database Driver Class Initialized
INFO - 2018-03-11 13:19:47 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:19:47 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:19:47 --> Controller Class Initialized
INFO - 2018-03-11 13:19:47 --> Model "user_model" initialized
INFO - 2018-03-11 13:19:47 --> Model "site_model" initialized
INFO - 2018-03-11 13:19:47 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:19:47 --> Final output sent to browser
DEBUG - 2018-03-11 13:19:47 --> Total execution time: 0.0196
INFO - 2018-03-11 13:20:08 --> Database Driver Class Initialized
INFO - 2018-03-11 13:20:08 --> Config Class Initialized
INFO - 2018-03-11 13:20:08 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:20:08 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:20:08 --> Utf8 Class Initialized
INFO - 2018-03-11 13:20:08 --> URI Class Initialized
DEBUG - 2018-03-11 13:20:08 --> No URI present. Default controller set.
INFO - 2018-03-11 13:20:08 --> Router Class Initialized
INFO - 2018-03-11 13:20:08 --> Output Class Initialized
INFO - 2018-03-11 13:20:08 --> Security Class Initialized
DEBUG - 2018-03-11 13:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:20:08 --> Input Class Initialized
INFO - 2018-03-11 13:20:08 --> Language Class Initialized
INFO - 2018-03-11 13:20:08 --> Loader Class Initialized
INFO - 2018-03-11 13:20:08 --> Helper loaded: url_helper
INFO - 2018-03-11 13:20:08 --> Helper loaded: site_helper
INFO - 2018-03-11 13:20:08 --> Database Driver Class Initialized
INFO - 2018-03-11 13:20:08 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:20:08 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:20:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:20:08 --> Controller Class Initialized
INFO - 2018-03-11 13:20:08 --> User Agent Class Initialized
INFO - 2018-03-11 13:20:08 --> Model "site_model" initialized
INFO - 2018-03-11 13:20:08 --> Model "user_model" initialized
INFO - 2018-03-11 13:20:08 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:20:08 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-11 13:20:08 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-11 13:20:08 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-11 13:20:08 --> Final output sent to browser
DEBUG - 2018-03-11 13:20:08 --> Total execution time: 0.0244
INFO - 2018-03-11 13:20:14 --> Database Driver Class Initialized
INFO - 2018-03-11 13:20:14 --> Config Class Initialized
INFO - 2018-03-11 13:20:14 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:20:14 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:20:14 --> Utf8 Class Initialized
INFO - 2018-03-11 13:20:14 --> URI Class Initialized
INFO - 2018-03-11 13:20:14 --> Router Class Initialized
INFO - 2018-03-11 13:20:14 --> Output Class Initialized
INFO - 2018-03-11 13:20:14 --> Security Class Initialized
DEBUG - 2018-03-11 13:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:20:14 --> Input Class Initialized
INFO - 2018-03-11 13:20:14 --> Language Class Initialized
INFO - 2018-03-11 13:20:14 --> Loader Class Initialized
INFO - 2018-03-11 13:20:14 --> Helper loaded: url_helper
INFO - 2018-03-11 13:20:14 --> Helper loaded: site_helper
INFO - 2018-03-11 13:20:14 --> Database Driver Class Initialized
INFO - 2018-03-11 13:20:14 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:20:14 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:20:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:20:14 --> Controller Class Initialized
INFO - 2018-03-11 13:20:14 --> Model "user_model" initialized
INFO - 2018-03-11 13:20:14 --> Model "site_model" initialized
INFO - 2018-03-11 13:20:14 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:20:14 --> Final output sent to browser
DEBUG - 2018-03-11 13:20:14 --> Total execution time: 0.0211
INFO - 2018-03-11 13:21:53 --> Database Driver Class Initialized
INFO - 2018-03-11 13:21:53 --> Config Class Initialized
INFO - 2018-03-11 13:21:53 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:21:53 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:21:53 --> Utf8 Class Initialized
INFO - 2018-03-11 13:21:53 --> URI Class Initialized
DEBUG - 2018-03-11 13:21:53 --> No URI present. Default controller set.
INFO - 2018-03-11 13:21:53 --> Router Class Initialized
INFO - 2018-03-11 13:21:53 --> Output Class Initialized
INFO - 2018-03-11 13:21:53 --> Security Class Initialized
DEBUG - 2018-03-11 13:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:21:53 --> Input Class Initialized
INFO - 2018-03-11 13:21:53 --> Language Class Initialized
INFO - 2018-03-11 13:21:53 --> Loader Class Initialized
INFO - 2018-03-11 13:21:53 --> Helper loaded: url_helper
INFO - 2018-03-11 13:21:53 --> Helper loaded: site_helper
INFO - 2018-03-11 13:21:53 --> Database Driver Class Initialized
INFO - 2018-03-11 13:21:53 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:21:53 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:21:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:21:53 --> Controller Class Initialized
INFO - 2018-03-11 13:21:53 --> User Agent Class Initialized
INFO - 2018-03-11 13:21:53 --> Model "site_model" initialized
INFO - 2018-03-11 13:21:53 --> Model "user_model" initialized
INFO - 2018-03-11 13:21:53 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:21:53 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-11 13:21:53 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-11 13:21:53 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-11 13:21:53 --> Final output sent to browser
DEBUG - 2018-03-11 13:21:53 --> Total execution time: 0.0260
INFO - 2018-03-11 13:22:04 --> Database Driver Class Initialized
INFO - 2018-03-11 13:22:04 --> Config Class Initialized
INFO - 2018-03-11 13:22:04 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:22:04 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:22:04 --> Utf8 Class Initialized
INFO - 2018-03-11 13:22:04 --> URI Class Initialized
INFO - 2018-03-11 13:22:04 --> Router Class Initialized
INFO - 2018-03-11 13:22:04 --> Output Class Initialized
INFO - 2018-03-11 13:22:04 --> Security Class Initialized
DEBUG - 2018-03-11 13:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:22:04 --> Input Class Initialized
INFO - 2018-03-11 13:22:04 --> Language Class Initialized
INFO - 2018-03-11 13:22:04 --> Loader Class Initialized
INFO - 2018-03-11 13:22:04 --> Helper loaded: url_helper
INFO - 2018-03-11 13:22:04 --> Helper loaded: site_helper
INFO - 2018-03-11 13:22:04 --> Database Driver Class Initialized
INFO - 2018-03-11 13:22:04 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:22:04 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:22:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:22:04 --> Controller Class Initialized
INFO - 2018-03-11 13:22:04 --> Model "user_model" initialized
INFO - 2018-03-11 13:22:04 --> Model "site_model" initialized
INFO - 2018-03-11 13:22:04 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:22:04 --> Final output sent to browser
DEBUG - 2018-03-11 13:22:04 --> Total execution time: 0.0285
INFO - 2018-03-11 13:22:13 --> Database Driver Class Initialized
INFO - 2018-03-11 13:22:13 --> Config Class Initialized
INFO - 2018-03-11 13:22:13 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:22:13 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:22:13 --> Utf8 Class Initialized
INFO - 2018-03-11 13:22:13 --> URI Class Initialized
INFO - 2018-03-11 13:22:13 --> Router Class Initialized
INFO - 2018-03-11 13:22:13 --> Output Class Initialized
INFO - 2018-03-11 13:22:13 --> Security Class Initialized
DEBUG - 2018-03-11 13:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:22:13 --> Input Class Initialized
INFO - 2018-03-11 13:22:13 --> Language Class Initialized
INFO - 2018-03-11 13:22:13 --> Loader Class Initialized
INFO - 2018-03-11 13:22:13 --> Helper loaded: url_helper
INFO - 2018-03-11 13:22:13 --> Helper loaded: site_helper
INFO - 2018-03-11 13:22:13 --> Database Driver Class Initialized
INFO - 2018-03-11 13:22:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:22:13 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:22:13 --> Controller Class Initialized
INFO - 2018-03-11 13:22:13 --> Model "user_model" initialized
INFO - 2018-03-11 13:22:13 --> Model "site_model" initialized
INFO - 2018-03-11 13:22:13 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:22:13 --> Final output sent to browser
DEBUG - 2018-03-11 13:22:13 --> Total execution time: 0.0200
INFO - 2018-03-11 13:22:13 --> Database Driver Class Initialized
INFO - 2018-03-11 13:22:13 --> Config Class Initialized
INFO - 2018-03-11 13:22:13 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:22:13 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:22:13 --> Utf8 Class Initialized
INFO - 2018-03-11 13:22:13 --> URI Class Initialized
INFO - 2018-03-11 13:22:13 --> Router Class Initialized
INFO - 2018-03-11 13:22:13 --> Output Class Initialized
INFO - 2018-03-11 13:22:13 --> Security Class Initialized
DEBUG - 2018-03-11 13:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:22:13 --> Input Class Initialized
INFO - 2018-03-11 13:22:13 --> Language Class Initialized
INFO - 2018-03-11 13:22:13 --> Loader Class Initialized
INFO - 2018-03-11 13:22:13 --> Helper loaded: url_helper
INFO - 2018-03-11 13:22:13 --> Helper loaded: site_helper
INFO - 2018-03-11 13:22:13 --> Database Driver Class Initialized
INFO - 2018-03-11 13:22:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:22:13 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:22:13 --> Controller Class Initialized
INFO - 2018-03-11 13:22:13 --> Model "user_model" initialized
INFO - 2018-03-11 13:22:13 --> Model "site_model" initialized
INFO - 2018-03-11 13:22:13 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:22:13 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:22:22 --> Database Driver Class Initialized
INFO - 2018-03-11 13:22:22 --> Config Class Initialized
INFO - 2018-03-11 13:22:22 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:22:22 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:22:22 --> Utf8 Class Initialized
INFO - 2018-03-11 13:22:22 --> URI Class Initialized
INFO - 2018-03-11 13:22:22 --> Router Class Initialized
INFO - 2018-03-11 13:22:22 --> Output Class Initialized
INFO - 2018-03-11 13:22:22 --> Security Class Initialized
DEBUG - 2018-03-11 13:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:22:22 --> Input Class Initialized
INFO - 2018-03-11 13:22:22 --> Language Class Initialized
INFO - 2018-03-11 13:22:22 --> Loader Class Initialized
INFO - 2018-03-11 13:22:22 --> Helper loaded: url_helper
INFO - 2018-03-11 13:22:22 --> Helper loaded: site_helper
INFO - 2018-03-11 13:22:22 --> Database Driver Class Initialized
INFO - 2018-03-11 13:22:22 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:22:22 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:22:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:22:22 --> Controller Class Initialized
INFO - 2018-03-11 13:22:22 --> Database Driver Class Initialized
INFO - 2018-03-11 13:22:22 --> Config Class Initialized
INFO - 2018-03-11 13:22:22 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:22:22 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:22:22 --> Utf8 Class Initialized
INFO - 2018-03-11 13:22:22 --> URI Class Initialized
DEBUG - 2018-03-11 13:22:22 --> No URI present. Default controller set.
INFO - 2018-03-11 13:22:22 --> Router Class Initialized
INFO - 2018-03-11 13:22:22 --> Output Class Initialized
INFO - 2018-03-11 13:22:22 --> Security Class Initialized
DEBUG - 2018-03-11 13:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:22:22 --> Input Class Initialized
INFO - 2018-03-11 13:22:22 --> Language Class Initialized
INFO - 2018-03-11 13:22:22 --> Loader Class Initialized
INFO - 2018-03-11 13:22:22 --> Helper loaded: url_helper
INFO - 2018-03-11 13:22:22 --> Helper loaded: site_helper
INFO - 2018-03-11 13:22:22 --> Database Driver Class Initialized
INFO - 2018-03-11 13:22:22 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:22:22 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:22:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:22:22 --> Controller Class Initialized
INFO - 2018-03-11 13:22:22 --> User Agent Class Initialized
INFO - 2018-03-11 13:22:22 --> Model "site_model" initialized
INFO - 2018-03-11 13:22:22 --> Model "user_model" initialized
INFO - 2018-03-11 13:22:22 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:22:22 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-11 13:22:22 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-11 13:22:22 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-11 13:22:22 --> Final output sent to browser
DEBUG - 2018-03-11 13:22:22 --> Total execution time: 0.0187
INFO - 2018-03-11 13:27:00 --> Database Driver Class Initialized
INFO - 2018-03-11 13:27:00 --> Config Class Initialized
INFO - 2018-03-11 13:27:00 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:27:00 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:27:00 --> Utf8 Class Initialized
INFO - 2018-03-11 13:27:00 --> URI Class Initialized
DEBUG - 2018-03-11 13:27:00 --> No URI present. Default controller set.
INFO - 2018-03-11 13:27:00 --> Router Class Initialized
INFO - 2018-03-11 13:27:00 --> Output Class Initialized
INFO - 2018-03-11 13:27:00 --> Security Class Initialized
DEBUG - 2018-03-11 13:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:27:00 --> Input Class Initialized
INFO - 2018-03-11 13:27:00 --> Language Class Initialized
INFO - 2018-03-11 13:27:00 --> Loader Class Initialized
INFO - 2018-03-11 13:27:00 --> Helper loaded: url_helper
INFO - 2018-03-11 13:27:00 --> Helper loaded: site_helper
INFO - 2018-03-11 13:27:00 --> Database Driver Class Initialized
INFO - 2018-03-11 13:27:00 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:27:00 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:27:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:27:00 --> Controller Class Initialized
INFO - 2018-03-11 13:27:00 --> User Agent Class Initialized
INFO - 2018-03-11 13:27:00 --> Model "site_model" initialized
INFO - 2018-03-11 13:27:00 --> Model "user_model" initialized
INFO - 2018-03-11 13:27:00 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:27:00 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-11 13:27:00 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-11 13:27:00 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-11 13:27:00 --> Final output sent to browser
DEBUG - 2018-03-11 13:27:00 --> Total execution time: 0.0297
INFO - 2018-03-11 13:27:21 --> Database Driver Class Initialized
INFO - 2018-03-11 13:27:21 --> Config Class Initialized
INFO - 2018-03-11 13:27:21 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:27:21 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:27:21 --> Utf8 Class Initialized
INFO - 2018-03-11 13:27:21 --> URI Class Initialized
INFO - 2018-03-11 13:27:21 --> Router Class Initialized
INFO - 2018-03-11 13:27:21 --> Output Class Initialized
INFO - 2018-03-11 13:27:21 --> Security Class Initialized
DEBUG - 2018-03-11 13:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:27:21 --> Input Class Initialized
INFO - 2018-03-11 13:27:21 --> Language Class Initialized
INFO - 2018-03-11 13:27:21 --> Loader Class Initialized
INFO - 2018-03-11 13:27:21 --> Helper loaded: url_helper
INFO - 2018-03-11 13:27:21 --> Helper loaded: site_helper
INFO - 2018-03-11 13:27:21 --> Database Driver Class Initialized
INFO - 2018-03-11 13:27:21 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:27:21 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:27:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:27:21 --> Controller Class Initialized
INFO - 2018-03-11 13:27:21 --> Model "user_model" initialized
INFO - 2018-03-11 13:27:21 --> Model "site_model" initialized
INFO - 2018-03-11 13:27:21 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-11 13:27:21 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/email/send-content.php
INFO - 2018-03-11 13:27:21 --> Email Class Initialized
INFO - 2018-03-11 13:27:21 --> Language file loaded: language/english/email_lang.php
DEBUG - 2018-03-11 13:27:21 --> E-mail to : Unable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Sun, 11 Mar 2018 13:27:21 +0100
From: &quot;OKDate&quot; &lt;noreply@example.com&gt;
Return-Path: &lt;noreply@example.com&gt;
X-SMTPAPI: {&quot;sub&quot;:{&quot;-id-&quot;:[null],&quot;-username-&quot;:[null],&quot;-photo-&quot;:[&quot;http:\/\/localhost\/myteenmatch\/images\/avatar.png&quot;],&quot;-country-&quot;:[&quot;&quot;]}}
Reply-To: &lt;noreply@example.com&gt;
User-Agent: CodeIgniter
X-Sender: noreply@example.com
X-Mailer: CodeIgniter
X-Priority: 1 (Highest)
Message-ID: &lt;5aa520a941929@example.com&gt;
Mime-Version: 1.0
Content-Type: multipart/alternative; boundary=&quot;B_ALT_5aa520a94193e&quot;
=?UTF-8?Q??=
This is a multi-part message in MIME format.
Your email application may not support this format.

--B_ALT_5aa520a94193e
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit




--B_ALT_5aa520a94193e
Content-Type: text/html; charset=UTF-8
Content-Transfer-Encoding: quoted-printable



--B_ALT_5aa520a94193e--</pre>
INFO - 2018-03-11 13:27:21 --> Final output sent to browser
DEBUG - 2018-03-11 13:27:21 --> Total execution time: 0.0972
INFO - 2018-03-11 13:29:28 --> Database Driver Class Initialized
INFO - 2018-03-11 13:29:28 --> Config Class Initialized
INFO - 2018-03-11 13:29:28 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:29:28 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:29:28 --> Utf8 Class Initialized
INFO - 2018-03-11 13:29:28 --> URI Class Initialized
DEBUG - 2018-03-11 13:29:28 --> No URI present. Default controller set.
INFO - 2018-03-11 13:29:28 --> Router Class Initialized
INFO - 2018-03-11 13:29:28 --> Output Class Initialized
INFO - 2018-03-11 13:29:28 --> Security Class Initialized
DEBUG - 2018-03-11 13:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:29:28 --> Input Class Initialized
INFO - 2018-03-11 13:29:28 --> Language Class Initialized
INFO - 2018-03-11 13:29:28 --> Loader Class Initialized
INFO - 2018-03-11 13:29:28 --> Helper loaded: url_helper
INFO - 2018-03-11 13:29:28 --> Helper loaded: site_helper
INFO - 2018-03-11 13:29:28 --> Database Driver Class Initialized
INFO - 2018-03-11 13:29:28 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:29:28 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:29:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:29:28 --> Controller Class Initialized
INFO - 2018-03-11 13:29:28 --> User Agent Class Initialized
INFO - 2018-03-11 13:29:28 --> Model "site_model" initialized
INFO - 2018-03-11 13:29:28 --> Model "user_model" initialized
INFO - 2018-03-11 13:29:28 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:29:28 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-11 13:29:28 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-11 13:29:28 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-11 13:29:28 --> Final output sent to browser
DEBUG - 2018-03-11 13:29:28 --> Total execution time: 0.0236
INFO - 2018-03-11 13:31:25 --> Database Driver Class Initialized
INFO - 2018-03-11 13:31:25 --> Config Class Initialized
INFO - 2018-03-11 13:31:25 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:31:25 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:31:25 --> Utf8 Class Initialized
INFO - 2018-03-11 13:31:25 --> URI Class Initialized
DEBUG - 2018-03-11 13:31:25 --> No URI present. Default controller set.
INFO - 2018-03-11 13:31:25 --> Router Class Initialized
INFO - 2018-03-11 13:31:25 --> Output Class Initialized
INFO - 2018-03-11 13:31:25 --> Security Class Initialized
DEBUG - 2018-03-11 13:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:31:25 --> Input Class Initialized
INFO - 2018-03-11 13:31:25 --> Language Class Initialized
INFO - 2018-03-11 13:31:25 --> Loader Class Initialized
INFO - 2018-03-11 13:31:25 --> Helper loaded: url_helper
INFO - 2018-03-11 13:31:25 --> Helper loaded: site_helper
INFO - 2018-03-11 13:31:25 --> Database Driver Class Initialized
INFO - 2018-03-11 13:31:25 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:31:25 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:31:25 --> Controller Class Initialized
INFO - 2018-03-11 13:31:25 --> User Agent Class Initialized
INFO - 2018-03-11 13:31:25 --> Model "site_model" initialized
INFO - 2018-03-11 13:31:25 --> Model "user_model" initialized
INFO - 2018-03-11 13:31:25 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:31:25 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-11 13:31:25 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-11 13:31:25 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-11 13:31:25 --> Final output sent to browser
DEBUG - 2018-03-11 13:31:25 --> Total execution time: 0.0308
INFO - 2018-03-11 13:31:32 --> Database Driver Class Initialized
INFO - 2018-03-11 13:31:32 --> Config Class Initialized
INFO - 2018-03-11 13:31:32 --> Hooks Class Initialized
DEBUG - 2018-03-11 13:31:32 --> UTF-8 Support Enabled
INFO - 2018-03-11 13:31:32 --> Utf8 Class Initialized
INFO - 2018-03-11 13:31:32 --> URI Class Initialized
DEBUG - 2018-03-11 13:31:32 --> No URI present. Default controller set.
INFO - 2018-03-11 13:31:32 --> Router Class Initialized
INFO - 2018-03-11 13:31:32 --> Output Class Initialized
INFO - 2018-03-11 13:31:32 --> Security Class Initialized
DEBUG - 2018-03-11 13:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-11 13:31:32 --> Input Class Initialized
INFO - 2018-03-11 13:31:32 --> Language Class Initialized
INFO - 2018-03-11 13:31:32 --> Loader Class Initialized
INFO - 2018-03-11 13:31:32 --> Helper loaded: url_helper
INFO - 2018-03-11 13:31:32 --> Helper loaded: site_helper
INFO - 2018-03-11 13:31:32 --> Database Driver Class Initialized
INFO - 2018-03-11 13:31:32 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-11 13:31:32 --> Config file loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/config/facebook.php
DEBUG - 2018-03-11 13:31:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-11 13:31:32 --> Controller Class Initialized
INFO - 2018-03-11 13:31:32 --> User Agent Class Initialized
INFO - 2018-03-11 13:31:32 --> Model "site_model" initialized
INFO - 2018-03-11 13:31:32 --> Model "user_model" initialized
INFO - 2018-03-11 13:31:32 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-11 13:31:32 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/headers/welcome_header.php
INFO - 2018-03-11 13:31:32 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/templates/footers/welcome_footer.php
INFO - 2018-03-11 13:31:32 --> File loaded: /Applications/XAMPP/xamppfiles/htdocs/myteenmatch/application/views/welcome.php
INFO - 2018-03-11 13:31:32 --> Final output sent to browser
DEBUG - 2018-03-11 13:31:32 --> Total execution time: 0.0190
