<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-16 13:42:56 --> Database Driver Class Initialized
INFO - 2018-03-16 13:42:56 --> Config Class Initialized
INFO - 2018-03-16 13:42:56 --> Hooks Class Initialized
DEBUG - 2018-03-16 13:42:56 --> UTF-8 Support Enabled
INFO - 2018-03-16 13:42:56 --> Utf8 Class Initialized
INFO - 2018-03-16 13:42:56 --> URI Class Initialized
DEBUG - 2018-03-16 13:42:56 --> No URI present. Default controller set.
INFO - 2018-03-16 13:42:56 --> Router Class Initialized
INFO - 2018-03-16 13:42:56 --> Output Class Initialized
INFO - 2018-03-16 13:42:56 --> Security Class Initialized
DEBUG - 2018-03-16 13:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 13:42:56 --> Input Class Initialized
INFO - 2018-03-16 13:42:56 --> Language Class Initialized
INFO - 2018-03-16 13:42:56 --> Loader Class Initialized
INFO - 2018-03-16 13:42:56 --> Helper loaded: url_helper
INFO - 2018-03-16 13:42:56 --> Helper loaded: site_helper
INFO - 2018-03-16 13:42:56 --> Database Driver Class Initialized
INFO - 2018-03-16 13:42:57 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 13:42:57 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 13:42:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 13:42:57 --> Controller Class Initialized
INFO - 2018-03-16 13:42:57 --> User Agent Class Initialized
INFO - 2018-03-16 13:42:57 --> Model "site_model" initialized
INFO - 2018-03-16 13:42:57 --> Model "user_model" initialized
INFO - 2018-03-16 13:42:57 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 13:42:57 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 13:42:57 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 13:42:57 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 13:42:57 --> Final output sent to browser
DEBUG - 2018-03-16 13:42:57 --> Total execution time: 0.3275
INFO - 2018-03-16 13:43:02 --> Database Driver Class Initialized
INFO - 2018-03-16 13:43:02 --> Config Class Initialized
INFO - 2018-03-16 13:43:02 --> Hooks Class Initialized
DEBUG - 2018-03-16 13:43:02 --> UTF-8 Support Enabled
INFO - 2018-03-16 13:43:02 --> Utf8 Class Initialized
INFO - 2018-03-16 13:43:02 --> URI Class Initialized
DEBUG - 2018-03-16 13:43:02 --> No URI present. Default controller set.
INFO - 2018-03-16 13:43:02 --> Router Class Initialized
INFO - 2018-03-16 13:43:02 --> Output Class Initialized
INFO - 2018-03-16 13:43:02 --> Security Class Initialized
DEBUG - 2018-03-16 13:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 13:43:02 --> Input Class Initialized
INFO - 2018-03-16 13:43:02 --> Language Class Initialized
INFO - 2018-03-16 13:43:02 --> Loader Class Initialized
INFO - 2018-03-16 13:43:02 --> Helper loaded: url_helper
INFO - 2018-03-16 13:43:02 --> Helper loaded: site_helper
INFO - 2018-03-16 13:43:02 --> Database Driver Class Initialized
INFO - 2018-03-16 13:43:02 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 13:43:02 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 13:43:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 13:43:02 --> Controller Class Initialized
INFO - 2018-03-16 13:43:02 --> User Agent Class Initialized
INFO - 2018-03-16 13:43:02 --> Model "site_model" initialized
INFO - 2018-03-16 13:43:02 --> Model "user_model" initialized
INFO - 2018-03-16 13:43:02 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 13:43:02 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 13:43:02 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 13:43:02 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 13:43:02 --> Final output sent to browser
DEBUG - 2018-03-16 13:43:02 --> Total execution time: 0.0775
INFO - 2018-03-16 13:43:13 --> Database Driver Class Initialized
INFO - 2018-03-16 13:43:13 --> Config Class Initialized
INFO - 2018-03-16 13:43:13 --> Hooks Class Initialized
DEBUG - 2018-03-16 13:43:13 --> UTF-8 Support Enabled
INFO - 2018-03-16 13:43:13 --> Utf8 Class Initialized
INFO - 2018-03-16 13:43:13 --> URI Class Initialized
DEBUG - 2018-03-16 13:43:13 --> No URI present. Default controller set.
INFO - 2018-03-16 13:43:13 --> Router Class Initialized
INFO - 2018-03-16 13:43:13 --> Output Class Initialized
INFO - 2018-03-16 13:43:13 --> Security Class Initialized
DEBUG - 2018-03-16 13:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 13:43:13 --> Input Class Initialized
INFO - 2018-03-16 13:43:13 --> Language Class Initialized
INFO - 2018-03-16 13:43:13 --> Loader Class Initialized
INFO - 2018-03-16 13:43:13 --> Helper loaded: url_helper
INFO - 2018-03-16 13:43:13 --> Helper loaded: site_helper
INFO - 2018-03-16 13:43:13 --> Database Driver Class Initialized
INFO - 2018-03-16 13:43:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 13:43:13 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 13:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 13:43:13 --> Controller Class Initialized
INFO - 2018-03-16 13:43:13 --> User Agent Class Initialized
INFO - 2018-03-16 13:43:13 --> Model "site_model" initialized
INFO - 2018-03-16 13:43:13 --> Model "user_model" initialized
INFO - 2018-03-16 13:43:13 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 13:43:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 13:43:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 13:43:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 13:43:13 --> Final output sent to browser
DEBUG - 2018-03-16 13:43:13 --> Total execution time: 0.0625
INFO - 2018-03-16 13:43:14 --> Database Driver Class Initialized
INFO - 2018-03-16 13:43:14 --> Config Class Initialized
INFO - 2018-03-16 13:43:14 --> Hooks Class Initialized
DEBUG - 2018-03-16 13:43:14 --> UTF-8 Support Enabled
INFO - 2018-03-16 13:43:14 --> Utf8 Class Initialized
INFO - 2018-03-16 13:43:14 --> URI Class Initialized
DEBUG - 2018-03-16 13:43:14 --> No URI present. Default controller set.
INFO - 2018-03-16 13:43:14 --> Router Class Initialized
INFO - 2018-03-16 13:43:14 --> Output Class Initialized
INFO - 2018-03-16 13:43:14 --> Security Class Initialized
DEBUG - 2018-03-16 13:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 13:43:14 --> Input Class Initialized
INFO - 2018-03-16 13:43:14 --> Language Class Initialized
INFO - 2018-03-16 13:43:14 --> Loader Class Initialized
INFO - 2018-03-16 13:43:14 --> Helper loaded: url_helper
INFO - 2018-03-16 13:43:14 --> Helper loaded: site_helper
INFO - 2018-03-16 13:43:14 --> Database Driver Class Initialized
INFO - 2018-03-16 13:43:14 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 13:43:14 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 13:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 13:43:14 --> Controller Class Initialized
INFO - 2018-03-16 13:43:14 --> User Agent Class Initialized
INFO - 2018-03-16 13:43:14 --> Model "site_model" initialized
INFO - 2018-03-16 13:43:14 --> Model "user_model" initialized
INFO - 2018-03-16 13:43:14 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 13:43:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 13:43:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 13:43:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 13:43:14 --> Final output sent to browser
DEBUG - 2018-03-16 13:43:14 --> Total execution time: 0.0525
INFO - 2018-03-16 13:43:18 --> Database Driver Class Initialized
INFO - 2018-03-16 13:43:18 --> Config Class Initialized
INFO - 2018-03-16 13:43:18 --> Hooks Class Initialized
DEBUG - 2018-03-16 13:43:18 --> UTF-8 Support Enabled
INFO - 2018-03-16 13:43:18 --> Utf8 Class Initialized
INFO - 2018-03-16 13:43:18 --> URI Class Initialized
DEBUG - 2018-03-16 13:43:18 --> No URI present. Default controller set.
INFO - 2018-03-16 13:43:18 --> Router Class Initialized
INFO - 2018-03-16 13:43:18 --> Output Class Initialized
INFO - 2018-03-16 13:43:18 --> Security Class Initialized
DEBUG - 2018-03-16 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 13:43:18 --> Input Class Initialized
INFO - 2018-03-16 13:43:18 --> Language Class Initialized
INFO - 2018-03-16 13:43:18 --> Loader Class Initialized
INFO - 2018-03-16 13:43:18 --> Helper loaded: url_helper
INFO - 2018-03-16 13:43:18 --> Helper loaded: site_helper
INFO - 2018-03-16 13:43:18 --> Database Driver Class Initialized
INFO - 2018-03-16 13:43:18 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 13:43:18 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 13:43:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 13:43:18 --> Controller Class Initialized
INFO - 2018-03-16 13:43:18 --> User Agent Class Initialized
INFO - 2018-03-16 13:43:18 --> Model "site_model" initialized
INFO - 2018-03-16 13:43:18 --> Model "user_model" initialized
INFO - 2018-03-16 13:43:18 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 13:43:18 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 13:43:18 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 13:43:18 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 13:43:18 --> Final output sent to browser
DEBUG - 2018-03-16 13:43:18 --> Total execution time: 0.0500
INFO - 2018-03-16 13:43:52 --> Database Driver Class Initialized
INFO - 2018-03-16 13:43:52 --> Config Class Initialized
INFO - 2018-03-16 13:43:52 --> Hooks Class Initialized
DEBUG - 2018-03-16 13:43:52 --> UTF-8 Support Enabled
INFO - 2018-03-16 13:43:52 --> Utf8 Class Initialized
INFO - 2018-03-16 13:43:52 --> URI Class Initialized
DEBUG - 2018-03-16 13:43:52 --> No URI present. Default controller set.
INFO - 2018-03-16 13:43:52 --> Router Class Initialized
INFO - 2018-03-16 13:43:52 --> Output Class Initialized
INFO - 2018-03-16 13:43:52 --> Security Class Initialized
DEBUG - 2018-03-16 13:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 13:43:52 --> Input Class Initialized
INFO - 2018-03-16 13:43:52 --> Language Class Initialized
INFO - 2018-03-16 13:43:52 --> Loader Class Initialized
INFO - 2018-03-16 13:43:52 --> Helper loaded: url_helper
INFO - 2018-03-16 13:43:52 --> Helper loaded: site_helper
INFO - 2018-03-16 13:43:52 --> Database Driver Class Initialized
INFO - 2018-03-16 13:43:52 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 13:43:52 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 13:43:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 13:43:52 --> Controller Class Initialized
INFO - 2018-03-16 13:43:52 --> User Agent Class Initialized
INFO - 2018-03-16 13:43:52 --> Model "site_model" initialized
INFO - 2018-03-16 13:43:52 --> Model "user_model" initialized
INFO - 2018-03-16 13:43:52 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 13:43:52 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 13:43:52 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 13:43:52 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 13:43:52 --> Final output sent to browser
DEBUG - 2018-03-16 13:43:52 --> Total execution time: 0.0525
INFO - 2018-03-16 13:44:48 --> Database Driver Class Initialized
INFO - 2018-03-16 13:44:48 --> Config Class Initialized
INFO - 2018-03-16 13:44:48 --> Hooks Class Initialized
DEBUG - 2018-03-16 13:44:48 --> UTF-8 Support Enabled
INFO - 2018-03-16 13:44:48 --> Utf8 Class Initialized
INFO - 2018-03-16 13:44:48 --> URI Class Initialized
DEBUG - 2018-03-16 13:44:48 --> No URI present. Default controller set.
INFO - 2018-03-16 13:44:48 --> Router Class Initialized
INFO - 2018-03-16 13:44:48 --> Output Class Initialized
INFO - 2018-03-16 13:44:48 --> Security Class Initialized
DEBUG - 2018-03-16 13:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 13:44:48 --> Input Class Initialized
INFO - 2018-03-16 13:44:49 --> Language Class Initialized
INFO - 2018-03-16 13:44:49 --> Loader Class Initialized
INFO - 2018-03-16 13:44:49 --> Helper loaded: url_helper
INFO - 2018-03-16 13:44:49 --> Helper loaded: site_helper
INFO - 2018-03-16 13:44:49 --> Database Driver Class Initialized
INFO - 2018-03-16 13:44:49 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 13:44:49 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 13:44:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 13:44:49 --> Controller Class Initialized
INFO - 2018-03-16 13:44:49 --> User Agent Class Initialized
INFO - 2018-03-16 13:44:49 --> Model "site_model" initialized
INFO - 2018-03-16 13:44:49 --> Model "user_model" initialized
INFO - 2018-03-16 13:44:49 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 13:44:49 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 13:44:49 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 13:44:49 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 13:44:49 --> Final output sent to browser
DEBUG - 2018-03-16 13:44:49 --> Total execution time: 0.1875
INFO - 2018-03-16 13:45:43 --> Database Driver Class Initialized
INFO - 2018-03-16 13:45:43 --> Config Class Initialized
INFO - 2018-03-16 13:45:43 --> Hooks Class Initialized
DEBUG - 2018-03-16 13:45:43 --> UTF-8 Support Enabled
INFO - 2018-03-16 13:45:43 --> Utf8 Class Initialized
INFO - 2018-03-16 13:45:43 --> URI Class Initialized
DEBUG - 2018-03-16 13:45:43 --> No URI present. Default controller set.
INFO - 2018-03-16 13:45:43 --> Router Class Initialized
INFO - 2018-03-16 13:45:43 --> Output Class Initialized
INFO - 2018-03-16 13:45:43 --> Security Class Initialized
DEBUG - 2018-03-16 13:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 13:45:43 --> Input Class Initialized
INFO - 2018-03-16 13:45:43 --> Language Class Initialized
INFO - 2018-03-16 13:45:43 --> Loader Class Initialized
INFO - 2018-03-16 13:45:43 --> Helper loaded: url_helper
INFO - 2018-03-16 13:45:43 --> Helper loaded: site_helper
INFO - 2018-03-16 13:45:43 --> Database Driver Class Initialized
INFO - 2018-03-16 13:45:43 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 13:45:43 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 13:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 13:45:43 --> Controller Class Initialized
INFO - 2018-03-16 13:45:43 --> User Agent Class Initialized
INFO - 2018-03-16 13:45:43 --> Model "site_model" initialized
INFO - 2018-03-16 13:45:43 --> Model "user_model" initialized
INFO - 2018-03-16 13:45:43 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 13:45:43 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 13:45:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 13:45:43 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 13:45:43 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 13:45:43 --> Final output sent to browser
DEBUG - 2018-03-16 13:45:43 --> Total execution time: 0.0850
INFO - 2018-03-16 13:45:44 --> Database Driver Class Initialized
INFO - 2018-03-16 13:45:45 --> Config Class Initialized
INFO - 2018-03-16 13:45:45 --> Hooks Class Initialized
DEBUG - 2018-03-16 13:45:45 --> UTF-8 Support Enabled
INFO - 2018-03-16 13:45:45 --> Utf8 Class Initialized
INFO - 2018-03-16 13:45:45 --> URI Class Initialized
DEBUG - 2018-03-16 13:45:45 --> No URI present. Default controller set.
INFO - 2018-03-16 13:45:45 --> Router Class Initialized
INFO - 2018-03-16 13:45:45 --> Output Class Initialized
INFO - 2018-03-16 13:45:45 --> Security Class Initialized
DEBUG - 2018-03-16 13:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 13:45:45 --> Input Class Initialized
INFO - 2018-03-16 13:45:45 --> Language Class Initialized
INFO - 2018-03-16 13:45:45 --> Loader Class Initialized
INFO - 2018-03-16 13:45:45 --> Helper loaded: url_helper
INFO - 2018-03-16 13:45:45 --> Helper loaded: site_helper
INFO - 2018-03-16 13:45:45 --> Database Driver Class Initialized
INFO - 2018-03-16 13:45:45 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 13:45:45 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 13:45:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 13:45:45 --> Controller Class Initialized
INFO - 2018-03-16 13:45:45 --> User Agent Class Initialized
INFO - 2018-03-16 13:45:45 --> Model "site_model" initialized
INFO - 2018-03-16 13:45:45 --> Model "user_model" initialized
INFO - 2018-03-16 13:45:45 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 13:45:45 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 13:45:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 13:45:45 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 13:45:45 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 13:45:45 --> Final output sent to browser
DEBUG - 2018-03-16 13:45:45 --> Total execution time: 0.0500
INFO - 2018-03-16 13:45:47 --> Database Driver Class Initialized
INFO - 2018-03-16 13:45:47 --> Config Class Initialized
INFO - 2018-03-16 13:45:47 --> Hooks Class Initialized
DEBUG - 2018-03-16 13:45:47 --> UTF-8 Support Enabled
INFO - 2018-03-16 13:45:47 --> Utf8 Class Initialized
INFO - 2018-03-16 13:45:47 --> URI Class Initialized
DEBUG - 2018-03-16 13:45:47 --> No URI present. Default controller set.
INFO - 2018-03-16 13:45:47 --> Router Class Initialized
INFO - 2018-03-16 13:45:47 --> Output Class Initialized
INFO - 2018-03-16 13:45:47 --> Security Class Initialized
DEBUG - 2018-03-16 13:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 13:45:47 --> Input Class Initialized
INFO - 2018-03-16 13:45:47 --> Language Class Initialized
INFO - 2018-03-16 13:45:47 --> Loader Class Initialized
INFO - 2018-03-16 13:45:47 --> Helper loaded: url_helper
INFO - 2018-03-16 13:45:47 --> Helper loaded: site_helper
INFO - 2018-03-16 13:45:47 --> Database Driver Class Initialized
INFO - 2018-03-16 13:45:47 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 13:45:47 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 13:45:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 13:45:47 --> Controller Class Initialized
INFO - 2018-03-16 13:45:47 --> User Agent Class Initialized
INFO - 2018-03-16 13:45:47 --> Model "site_model" initialized
INFO - 2018-03-16 13:45:47 --> Model "user_model" initialized
INFO - 2018-03-16 13:45:47 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 13:45:47 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 13:45:47 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 13:45:47 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 13:45:47 --> Final output sent to browser
DEBUG - 2018-03-16 13:45:47 --> Total execution time: 0.1225
INFO - 2018-03-16 13:45:50 --> Database Driver Class Initialized
INFO - 2018-03-16 13:45:50 --> Config Class Initialized
INFO - 2018-03-16 13:45:50 --> Hooks Class Initialized
DEBUG - 2018-03-16 13:45:50 --> UTF-8 Support Enabled
INFO - 2018-03-16 13:45:50 --> Utf8 Class Initialized
INFO - 2018-03-16 13:45:50 --> URI Class Initialized
DEBUG - 2018-03-16 13:45:50 --> No URI present. Default controller set.
INFO - 2018-03-16 13:45:50 --> Router Class Initialized
INFO - 2018-03-16 13:45:50 --> Output Class Initialized
INFO - 2018-03-16 13:45:50 --> Security Class Initialized
DEBUG - 2018-03-16 13:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 13:45:50 --> Input Class Initialized
INFO - 2018-03-16 13:45:50 --> Language Class Initialized
INFO - 2018-03-16 13:45:50 --> Loader Class Initialized
INFO - 2018-03-16 13:45:50 --> Helper loaded: url_helper
INFO - 2018-03-16 13:45:50 --> Helper loaded: site_helper
INFO - 2018-03-16 13:45:50 --> Database Driver Class Initialized
INFO - 2018-03-16 13:45:50 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 13:45:50 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 13:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 13:45:50 --> Controller Class Initialized
INFO - 2018-03-16 13:45:50 --> User Agent Class Initialized
INFO - 2018-03-16 13:45:50 --> Model "site_model" initialized
INFO - 2018-03-16 13:45:50 --> Model "user_model" initialized
INFO - 2018-03-16 13:45:50 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 13:45:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 13:45:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 13:45:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 13:45:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 13:45:50 --> Final output sent to browser
DEBUG - 2018-03-16 13:45:50 --> Total execution time: 0.0900
INFO - 2018-03-16 13:45:52 --> Database Driver Class Initialized
INFO - 2018-03-16 13:45:52 --> Config Class Initialized
INFO - 2018-03-16 13:45:52 --> Hooks Class Initialized
DEBUG - 2018-03-16 13:45:52 --> UTF-8 Support Enabled
INFO - 2018-03-16 13:45:52 --> Utf8 Class Initialized
INFO - 2018-03-16 13:45:52 --> URI Class Initialized
DEBUG - 2018-03-16 13:45:52 --> No URI present. Default controller set.
INFO - 2018-03-16 13:45:52 --> Router Class Initialized
INFO - 2018-03-16 13:45:52 --> Output Class Initialized
INFO - 2018-03-16 13:45:52 --> Security Class Initialized
DEBUG - 2018-03-16 13:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 13:45:52 --> Input Class Initialized
INFO - 2018-03-16 13:45:52 --> Language Class Initialized
INFO - 2018-03-16 13:45:52 --> Loader Class Initialized
INFO - 2018-03-16 13:45:52 --> Helper loaded: url_helper
INFO - 2018-03-16 13:45:52 --> Helper loaded: site_helper
INFO - 2018-03-16 13:45:52 --> Database Driver Class Initialized
INFO - 2018-03-16 13:45:52 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 13:45:52 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 13:45:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 13:45:52 --> Controller Class Initialized
INFO - 2018-03-16 13:45:52 --> User Agent Class Initialized
INFO - 2018-03-16 13:45:52 --> Model "site_model" initialized
INFO - 2018-03-16 13:45:52 --> Model "user_model" initialized
INFO - 2018-03-16 13:45:52 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 13:45:52 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 13:45:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 13:45:52 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 13:45:52 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 13:45:52 --> Final output sent to browser
DEBUG - 2018-03-16 13:45:52 --> Total execution time: 0.0450
INFO - 2018-03-16 18:27:06 --> Database Driver Class Initialized
INFO - 2018-03-16 18:27:06 --> Config Class Initialized
INFO - 2018-03-16 18:27:06 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:27:06 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:27:06 --> Utf8 Class Initialized
INFO - 2018-03-16 18:27:06 --> URI Class Initialized
DEBUG - 2018-03-16 18:27:06 --> No URI present. Default controller set.
INFO - 2018-03-16 18:27:06 --> Router Class Initialized
INFO - 2018-03-16 18:27:06 --> Output Class Initialized
INFO - 2018-03-16 18:27:06 --> Security Class Initialized
DEBUG - 2018-03-16 18:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:27:06 --> Input Class Initialized
INFO - 2018-03-16 18:27:06 --> Language Class Initialized
INFO - 2018-03-16 18:27:06 --> Loader Class Initialized
INFO - 2018-03-16 18:27:06 --> Helper loaded: url_helper
INFO - 2018-03-16 18:27:06 --> Helper loaded: site_helper
INFO - 2018-03-16 18:27:06 --> Database Driver Class Initialized
INFO - 2018-03-16 18:27:07 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:27:07 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:27:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:27:07 --> Controller Class Initialized
INFO - 2018-03-16 18:27:07 --> User Agent Class Initialized
INFO - 2018-03-16 18:27:07 --> Model "site_model" initialized
INFO - 2018-03-16 18:27:07 --> Model "user_model" initialized
INFO - 2018-03-16 18:27:07 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:27:07 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:27:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:27:07 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:27:07 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:27:07 --> Final output sent to browser
DEBUG - 2018-03-16 18:27:07 --> Total execution time: 0.5020
INFO - 2018-03-16 18:33:13 --> Database Driver Class Initialized
INFO - 2018-03-16 18:33:13 --> Config Class Initialized
INFO - 2018-03-16 18:33:13 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:33:13 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:33:13 --> Utf8 Class Initialized
INFO - 2018-03-16 18:33:13 --> URI Class Initialized
DEBUG - 2018-03-16 18:33:13 --> No URI present. Default controller set.
INFO - 2018-03-16 18:33:13 --> Router Class Initialized
INFO - 2018-03-16 18:33:13 --> Output Class Initialized
INFO - 2018-03-16 18:33:13 --> Security Class Initialized
DEBUG - 2018-03-16 18:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:33:13 --> Input Class Initialized
INFO - 2018-03-16 18:33:13 --> Language Class Initialized
INFO - 2018-03-16 18:33:13 --> Loader Class Initialized
INFO - 2018-03-16 18:33:13 --> Helper loaded: url_helper
INFO - 2018-03-16 18:33:13 --> Helper loaded: site_helper
INFO - 2018-03-16 18:33:13 --> Database Driver Class Initialized
INFO - 2018-03-16 18:33:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:33:13 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:33:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:33:13 --> Controller Class Initialized
INFO - 2018-03-16 18:33:13 --> User Agent Class Initialized
INFO - 2018-03-16 18:33:13 --> Model "site_model" initialized
INFO - 2018-03-16 18:33:13 --> Model "user_model" initialized
INFO - 2018-03-16 18:33:13 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:33:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:33:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:33:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:33:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:33:13 --> Final output sent to browser
DEBUG - 2018-03-16 18:33:13 --> Total execution time: 0.0575
INFO - 2018-03-16 18:33:37 --> Database Driver Class Initialized
INFO - 2018-03-16 18:33:37 --> Config Class Initialized
INFO - 2018-03-16 18:33:37 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:33:37 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:33:37 --> Utf8 Class Initialized
INFO - 2018-03-16 18:33:37 --> URI Class Initialized
DEBUG - 2018-03-16 18:33:37 --> No URI present. Default controller set.
INFO - 2018-03-16 18:33:37 --> Router Class Initialized
INFO - 2018-03-16 18:33:37 --> Output Class Initialized
INFO - 2018-03-16 18:33:37 --> Security Class Initialized
DEBUG - 2018-03-16 18:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:33:37 --> Input Class Initialized
INFO - 2018-03-16 18:33:37 --> Language Class Initialized
INFO - 2018-03-16 18:33:37 --> Loader Class Initialized
INFO - 2018-03-16 18:33:37 --> Helper loaded: url_helper
INFO - 2018-03-16 18:33:37 --> Helper loaded: site_helper
INFO - 2018-03-16 18:33:37 --> Database Driver Class Initialized
INFO - 2018-03-16 18:33:37 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:33:37 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:33:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:33:37 --> Controller Class Initialized
INFO - 2018-03-16 18:33:37 --> User Agent Class Initialized
INFO - 2018-03-16 18:33:37 --> Model "site_model" initialized
INFO - 2018-03-16 18:33:37 --> Model "user_model" initialized
INFO - 2018-03-16 18:33:37 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:33:37 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:33:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:33:37 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:33:37 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:33:37 --> Final output sent to browser
DEBUG - 2018-03-16 18:33:37 --> Total execution time: 0.0525
INFO - 2018-03-16 18:34:06 --> Database Driver Class Initialized
INFO - 2018-03-16 18:34:06 --> Config Class Initialized
INFO - 2018-03-16 18:34:06 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:34:06 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:34:06 --> Utf8 Class Initialized
INFO - 2018-03-16 18:34:06 --> URI Class Initialized
DEBUG - 2018-03-16 18:34:06 --> No URI present. Default controller set.
INFO - 2018-03-16 18:34:06 --> Router Class Initialized
INFO - 2018-03-16 18:34:06 --> Output Class Initialized
INFO - 2018-03-16 18:34:06 --> Security Class Initialized
DEBUG - 2018-03-16 18:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:34:06 --> Input Class Initialized
INFO - 2018-03-16 18:34:06 --> Language Class Initialized
INFO - 2018-03-16 18:34:06 --> Loader Class Initialized
INFO - 2018-03-16 18:34:06 --> Helper loaded: url_helper
INFO - 2018-03-16 18:34:06 --> Helper loaded: site_helper
INFO - 2018-03-16 18:34:06 --> Database Driver Class Initialized
INFO - 2018-03-16 18:34:06 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:34:06 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:34:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:34:06 --> Controller Class Initialized
INFO - 2018-03-16 18:34:06 --> User Agent Class Initialized
INFO - 2018-03-16 18:34:06 --> Model "site_model" initialized
INFO - 2018-03-16 18:34:06 --> Model "user_model" initialized
INFO - 2018-03-16 18:34:06 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:34:06 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:34:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:34:06 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:34:06 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:34:06 --> Final output sent to browser
DEBUG - 2018-03-16 18:34:06 --> Total execution time: 0.0500
INFO - 2018-03-16 18:34:11 --> Database Driver Class Initialized
INFO - 2018-03-16 18:34:11 --> Config Class Initialized
INFO - 2018-03-16 18:34:11 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:34:11 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:34:11 --> Utf8 Class Initialized
INFO - 2018-03-16 18:34:12 --> URI Class Initialized
INFO - 2018-03-16 18:34:12 --> Router Class Initialized
INFO - 2018-03-16 18:34:12 --> Output Class Initialized
INFO - 2018-03-16 18:34:12 --> Security Class Initialized
DEBUG - 2018-03-16 18:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:34:12 --> Input Class Initialized
INFO - 2018-03-16 18:34:12 --> Language Class Initialized
INFO - 2018-03-16 18:34:12 --> Loader Class Initialized
INFO - 2018-03-16 18:34:12 --> Helper loaded: url_helper
INFO - 2018-03-16 18:34:12 --> Helper loaded: site_helper
INFO - 2018-03-16 18:34:12 --> Database Driver Class Initialized
INFO - 2018-03-16 18:34:12 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:34:12 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:34:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:34:12 --> Controller Class Initialized
INFO - 2018-03-16 18:34:12 --> Model "user_model" initialized
INFO - 2018-03-16 18:34:12 --> Model "site_model" initialized
INFO - 2018-03-16 18:34:12 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 18:34:12 --> Final output sent to browser
DEBUG - 2018-03-16 18:34:12 --> Total execution time: 0.1650
INFO - 2018-03-16 18:34:16 --> Database Driver Class Initialized
INFO - 2018-03-16 18:34:16 --> Config Class Initialized
INFO - 2018-03-16 18:34:16 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:34:16 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:34:16 --> Utf8 Class Initialized
INFO - 2018-03-16 18:34:16 --> URI Class Initialized
DEBUG - 2018-03-16 18:34:16 --> No URI present. Default controller set.
INFO - 2018-03-16 18:34:16 --> Router Class Initialized
INFO - 2018-03-16 18:34:16 --> Output Class Initialized
INFO - 2018-03-16 18:34:16 --> Security Class Initialized
DEBUG - 2018-03-16 18:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:34:16 --> Input Class Initialized
INFO - 2018-03-16 18:34:16 --> Language Class Initialized
INFO - 2018-03-16 18:34:16 --> Loader Class Initialized
INFO - 2018-03-16 18:34:16 --> Helper loaded: url_helper
INFO - 2018-03-16 18:34:16 --> Helper loaded: site_helper
INFO - 2018-03-16 18:34:16 --> Database Driver Class Initialized
INFO - 2018-03-16 18:34:16 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:34:16 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:34:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:34:16 --> Controller Class Initialized
INFO - 2018-03-16 18:34:16 --> User Agent Class Initialized
INFO - 2018-03-16 18:34:16 --> Model "site_model" initialized
INFO - 2018-03-16 18:34:16 --> Model "user_model" initialized
INFO - 2018-03-16 18:34:16 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:34:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:34:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:34:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:34:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:34:16 --> Final output sent to browser
DEBUG - 2018-03-16 18:34:16 --> Total execution time: 0.0485
INFO - 2018-03-16 18:36:36 --> Database Driver Class Initialized
INFO - 2018-03-16 18:36:36 --> Config Class Initialized
INFO - 2018-03-16 18:36:36 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:36:36 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:36:36 --> Utf8 Class Initialized
INFO - 2018-03-16 18:36:36 --> URI Class Initialized
DEBUG - 2018-03-16 18:36:36 --> No URI present. Default controller set.
INFO - 2018-03-16 18:36:36 --> Router Class Initialized
INFO - 2018-03-16 18:36:36 --> Output Class Initialized
INFO - 2018-03-16 18:36:36 --> Security Class Initialized
DEBUG - 2018-03-16 18:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:36:36 --> Input Class Initialized
INFO - 2018-03-16 18:36:36 --> Language Class Initialized
INFO - 2018-03-16 18:36:36 --> Loader Class Initialized
INFO - 2018-03-16 18:36:36 --> Helper loaded: url_helper
INFO - 2018-03-16 18:36:36 --> Helper loaded: site_helper
INFO - 2018-03-16 18:36:36 --> Database Driver Class Initialized
INFO - 2018-03-16 18:36:36 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:36:36 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:36:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:36:36 --> Controller Class Initialized
INFO - 2018-03-16 18:36:36 --> User Agent Class Initialized
INFO - 2018-03-16 18:36:36 --> Model "site_model" initialized
INFO - 2018-03-16 18:36:36 --> Model "user_model" initialized
INFO - 2018-03-16 18:36:36 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:36:36 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:36:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:36:36 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:36:36 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:36:36 --> Final output sent to browser
DEBUG - 2018-03-16 18:36:36 --> Total execution time: 0.0500
INFO - 2018-03-16 18:36:40 --> Database Driver Class Initialized
INFO - 2018-03-16 18:36:40 --> Config Class Initialized
INFO - 2018-03-16 18:36:40 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:36:40 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:36:40 --> Utf8 Class Initialized
INFO - 2018-03-16 18:36:40 --> URI Class Initialized
DEBUG - 2018-03-16 18:36:40 --> No URI present. Default controller set.
INFO - 2018-03-16 18:36:40 --> Router Class Initialized
INFO - 2018-03-16 18:36:40 --> Output Class Initialized
INFO - 2018-03-16 18:36:40 --> Security Class Initialized
DEBUG - 2018-03-16 18:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:36:40 --> Input Class Initialized
INFO - 2018-03-16 18:36:40 --> Language Class Initialized
INFO - 2018-03-16 18:36:40 --> Loader Class Initialized
INFO - 2018-03-16 18:36:40 --> Helper loaded: url_helper
INFO - 2018-03-16 18:36:40 --> Helper loaded: site_helper
INFO - 2018-03-16 18:36:40 --> Database Driver Class Initialized
INFO - 2018-03-16 18:36:40 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:36:40 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:36:40 --> Controller Class Initialized
INFO - 2018-03-16 18:36:40 --> User Agent Class Initialized
INFO - 2018-03-16 18:36:40 --> Model "site_model" initialized
INFO - 2018-03-16 18:36:40 --> Model "user_model" initialized
INFO - 2018-03-16 18:36:40 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:36:40 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:36:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:36:40 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:36:40 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:36:40 --> Final output sent to browser
DEBUG - 2018-03-16 18:36:40 --> Total execution time: 0.0550
INFO - 2018-03-16 18:36:45 --> Database Driver Class Initialized
INFO - 2018-03-16 18:36:45 --> Config Class Initialized
INFO - 2018-03-16 18:36:45 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:36:45 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:36:45 --> Utf8 Class Initialized
INFO - 2018-03-16 18:36:45 --> URI Class Initialized
DEBUG - 2018-03-16 18:36:45 --> No URI present. Default controller set.
INFO - 2018-03-16 18:36:45 --> Router Class Initialized
INFO - 2018-03-16 18:36:45 --> Output Class Initialized
INFO - 2018-03-16 18:36:45 --> Security Class Initialized
DEBUG - 2018-03-16 18:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:36:45 --> Input Class Initialized
INFO - 2018-03-16 18:36:45 --> Language Class Initialized
INFO - 2018-03-16 18:36:45 --> Loader Class Initialized
INFO - 2018-03-16 18:36:45 --> Helper loaded: url_helper
INFO - 2018-03-16 18:36:45 --> Helper loaded: site_helper
INFO - 2018-03-16 18:36:45 --> Database Driver Class Initialized
INFO - 2018-03-16 18:36:45 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:36:45 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:36:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:36:45 --> Controller Class Initialized
INFO - 2018-03-16 18:36:45 --> User Agent Class Initialized
INFO - 2018-03-16 18:36:45 --> Model "site_model" initialized
INFO - 2018-03-16 18:36:45 --> Model "user_model" initialized
INFO - 2018-03-16 18:36:45 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:36:45 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:36:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:36:45 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:36:45 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:36:45 --> Final output sent to browser
DEBUG - 2018-03-16 18:36:45 --> Total execution time: 0.0550
INFO - 2018-03-16 18:36:49 --> Database Driver Class Initialized
INFO - 2018-03-16 18:36:49 --> Config Class Initialized
INFO - 2018-03-16 18:36:49 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:36:49 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:36:49 --> Utf8 Class Initialized
INFO - 2018-03-16 18:36:49 --> URI Class Initialized
DEBUG - 2018-03-16 18:36:49 --> No URI present. Default controller set.
INFO - 2018-03-16 18:36:49 --> Router Class Initialized
INFO - 2018-03-16 18:36:49 --> Output Class Initialized
INFO - 2018-03-16 18:36:49 --> Security Class Initialized
DEBUG - 2018-03-16 18:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:36:49 --> Input Class Initialized
INFO - 2018-03-16 18:36:49 --> Language Class Initialized
INFO - 2018-03-16 18:36:49 --> Loader Class Initialized
INFO - 2018-03-16 18:36:49 --> Helper loaded: url_helper
INFO - 2018-03-16 18:36:49 --> Helper loaded: site_helper
INFO - 2018-03-16 18:36:49 --> Database Driver Class Initialized
INFO - 2018-03-16 18:36:49 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:36:49 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:36:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:36:49 --> Controller Class Initialized
INFO - 2018-03-16 18:36:49 --> User Agent Class Initialized
INFO - 2018-03-16 18:36:49 --> Model "site_model" initialized
INFO - 2018-03-16 18:36:49 --> Model "user_model" initialized
INFO - 2018-03-16 18:36:49 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:36:49 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:36:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:36:49 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:36:49 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:36:49 --> Final output sent to browser
DEBUG - 2018-03-16 18:36:49 --> Total execution time: 0.0550
INFO - 2018-03-16 18:36:50 --> Database Driver Class Initialized
INFO - 2018-03-16 18:36:50 --> Config Class Initialized
INFO - 2018-03-16 18:36:50 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:36:50 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:36:50 --> Utf8 Class Initialized
INFO - 2018-03-16 18:36:50 --> URI Class Initialized
DEBUG - 2018-03-16 18:36:50 --> No URI present. Default controller set.
INFO - 2018-03-16 18:36:50 --> Router Class Initialized
INFO - 2018-03-16 18:36:50 --> Output Class Initialized
INFO - 2018-03-16 18:36:50 --> Security Class Initialized
DEBUG - 2018-03-16 18:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:36:50 --> Input Class Initialized
INFO - 2018-03-16 18:36:50 --> Language Class Initialized
INFO - 2018-03-16 18:36:50 --> Loader Class Initialized
INFO - 2018-03-16 18:36:50 --> Helper loaded: url_helper
INFO - 2018-03-16 18:36:50 --> Helper loaded: site_helper
INFO - 2018-03-16 18:36:50 --> Database Driver Class Initialized
INFO - 2018-03-16 18:36:50 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:36:50 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:36:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:36:50 --> Controller Class Initialized
INFO - 2018-03-16 18:36:50 --> User Agent Class Initialized
INFO - 2018-03-16 18:36:50 --> Model "site_model" initialized
INFO - 2018-03-16 18:36:50 --> Model "user_model" initialized
INFO - 2018-03-16 18:36:50 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:36:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:36:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:36:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:36:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:36:50 --> Final output sent to browser
DEBUG - 2018-03-16 18:36:50 --> Total execution time: 0.0935
INFO - 2018-03-16 18:36:55 --> Database Driver Class Initialized
INFO - 2018-03-16 18:36:55 --> Config Class Initialized
INFO - 2018-03-16 18:36:55 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:36:55 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:36:55 --> Utf8 Class Initialized
INFO - 2018-03-16 18:36:55 --> URI Class Initialized
DEBUG - 2018-03-16 18:36:55 --> No URI present. Default controller set.
INFO - 2018-03-16 18:36:55 --> Router Class Initialized
INFO - 2018-03-16 18:36:55 --> Output Class Initialized
INFO - 2018-03-16 18:36:55 --> Security Class Initialized
DEBUG - 2018-03-16 18:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:36:55 --> Input Class Initialized
INFO - 2018-03-16 18:36:55 --> Language Class Initialized
INFO - 2018-03-16 18:36:55 --> Loader Class Initialized
INFO - 2018-03-16 18:36:55 --> Helper loaded: url_helper
INFO - 2018-03-16 18:36:55 --> Helper loaded: site_helper
INFO - 2018-03-16 18:36:55 --> Database Driver Class Initialized
INFO - 2018-03-16 18:36:55 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:36:55 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:36:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:36:55 --> Controller Class Initialized
INFO - 2018-03-16 18:36:55 --> User Agent Class Initialized
INFO - 2018-03-16 18:36:55 --> Model "site_model" initialized
INFO - 2018-03-16 18:36:55 --> Model "user_model" initialized
INFO - 2018-03-16 18:36:55 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:36:55 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:36:55 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:36:55 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:36:55 --> Final output sent to browser
DEBUG - 2018-03-16 18:36:55 --> Total execution time: 0.0700
INFO - 2018-03-16 18:36:56 --> Database Driver Class Initialized
INFO - 2018-03-16 18:36:56 --> Config Class Initialized
INFO - 2018-03-16 18:36:56 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:36:56 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:36:56 --> Utf8 Class Initialized
INFO - 2018-03-16 18:36:56 --> URI Class Initialized
DEBUG - 2018-03-16 18:36:56 --> No URI present. Default controller set.
INFO - 2018-03-16 18:36:56 --> Router Class Initialized
INFO - 2018-03-16 18:36:56 --> Output Class Initialized
INFO - 2018-03-16 18:36:56 --> Security Class Initialized
DEBUG - 2018-03-16 18:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:36:56 --> Input Class Initialized
INFO - 2018-03-16 18:36:56 --> Language Class Initialized
INFO - 2018-03-16 18:36:56 --> Loader Class Initialized
INFO - 2018-03-16 18:36:56 --> Helper loaded: url_helper
INFO - 2018-03-16 18:36:56 --> Helper loaded: site_helper
INFO - 2018-03-16 18:36:56 --> Database Driver Class Initialized
INFO - 2018-03-16 18:36:56 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:36:56 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:36:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:36:56 --> Controller Class Initialized
INFO - 2018-03-16 18:36:56 --> User Agent Class Initialized
INFO - 2018-03-16 18:36:56 --> Model "site_model" initialized
INFO - 2018-03-16 18:36:56 --> Model "user_model" initialized
INFO - 2018-03-16 18:36:56 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:36:56 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:36:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:36:56 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:36:56 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:36:56 --> Final output sent to browser
DEBUG - 2018-03-16 18:36:56 --> Total execution time: 0.0625
INFO - 2018-03-16 18:37:12 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:12 --> Config Class Initialized
INFO - 2018-03-16 18:37:12 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:37:12 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:37:12 --> Utf8 Class Initialized
INFO - 2018-03-16 18:37:12 --> URI Class Initialized
DEBUG - 2018-03-16 18:37:12 --> No URI present. Default controller set.
INFO - 2018-03-16 18:37:12 --> Router Class Initialized
INFO - 2018-03-16 18:37:12 --> Output Class Initialized
INFO - 2018-03-16 18:37:12 --> Security Class Initialized
DEBUG - 2018-03-16 18:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:37:12 --> Input Class Initialized
INFO - 2018-03-16 18:37:12 --> Language Class Initialized
INFO - 2018-03-16 18:37:12 --> Loader Class Initialized
INFO - 2018-03-16 18:37:12 --> Helper loaded: url_helper
INFO - 2018-03-16 18:37:12 --> Helper loaded: site_helper
INFO - 2018-03-16 18:37:12 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:12 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:37:12 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:37:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:37:12 --> Controller Class Initialized
INFO - 2018-03-16 18:37:12 --> User Agent Class Initialized
INFO - 2018-03-16 18:37:12 --> Model "site_model" initialized
INFO - 2018-03-16 18:37:12 --> Model "user_model" initialized
INFO - 2018-03-16 18:37:12 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:37:12 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:37:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:37:12 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:37:12 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:37:12 --> Final output sent to browser
DEBUG - 2018-03-16 18:37:12 --> Total execution time: 0.0475
INFO - 2018-03-16 18:37:12 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:12 --> Config Class Initialized
INFO - 2018-03-16 18:37:12 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:37:12 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:37:12 --> Utf8 Class Initialized
INFO - 2018-03-16 18:37:12 --> URI Class Initialized
DEBUG - 2018-03-16 18:37:12 --> No URI present. Default controller set.
INFO - 2018-03-16 18:37:12 --> Router Class Initialized
INFO - 2018-03-16 18:37:12 --> Output Class Initialized
INFO - 2018-03-16 18:37:12 --> Security Class Initialized
DEBUG - 2018-03-16 18:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:37:12 --> Input Class Initialized
INFO - 2018-03-16 18:37:12 --> Language Class Initialized
INFO - 2018-03-16 18:37:12 --> Loader Class Initialized
INFO - 2018-03-16 18:37:12 --> Helper loaded: url_helper
INFO - 2018-03-16 18:37:12 --> Helper loaded: site_helper
INFO - 2018-03-16 18:37:12 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:12 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:37:12 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:37:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:37:12 --> Controller Class Initialized
INFO - 2018-03-16 18:37:12 --> User Agent Class Initialized
INFO - 2018-03-16 18:37:12 --> Model "site_model" initialized
INFO - 2018-03-16 18:37:12 --> Model "user_model" initialized
INFO - 2018-03-16 18:37:12 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:37:12 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:37:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:37:12 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:37:12 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:37:12 --> Final output sent to browser
DEBUG - 2018-03-16 18:37:12 --> Total execution time: 0.0550
INFO - 2018-03-16 18:37:13 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:13 --> Config Class Initialized
INFO - 2018-03-16 18:37:13 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:37:13 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:37:13 --> Utf8 Class Initialized
INFO - 2018-03-16 18:37:13 --> URI Class Initialized
DEBUG - 2018-03-16 18:37:13 --> No URI present. Default controller set.
INFO - 2018-03-16 18:37:13 --> Router Class Initialized
INFO - 2018-03-16 18:37:13 --> Output Class Initialized
INFO - 2018-03-16 18:37:13 --> Security Class Initialized
DEBUG - 2018-03-16 18:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:37:13 --> Input Class Initialized
INFO - 2018-03-16 18:37:13 --> Language Class Initialized
INFO - 2018-03-16 18:37:13 --> Loader Class Initialized
INFO - 2018-03-16 18:37:13 --> Helper loaded: url_helper
INFO - 2018-03-16 18:37:13 --> Helper loaded: site_helper
INFO - 2018-03-16 18:37:13 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:37:13 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:37:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:37:13 --> Controller Class Initialized
INFO - 2018-03-16 18:37:13 --> User Agent Class Initialized
INFO - 2018-03-16 18:37:13 --> Model "site_model" initialized
INFO - 2018-03-16 18:37:13 --> Model "user_model" initialized
INFO - 2018-03-16 18:37:13 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:37:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:37:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:37:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:37:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:37:13 --> Final output sent to browser
DEBUG - 2018-03-16 18:37:13 --> Total execution time: 0.0575
INFO - 2018-03-16 18:37:16 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:16 --> Config Class Initialized
INFO - 2018-03-16 18:37:16 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:37:16 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:37:16 --> Utf8 Class Initialized
INFO - 2018-03-16 18:37:16 --> URI Class Initialized
DEBUG - 2018-03-16 18:37:16 --> No URI present. Default controller set.
INFO - 2018-03-16 18:37:16 --> Router Class Initialized
INFO - 2018-03-16 18:37:16 --> Output Class Initialized
INFO - 2018-03-16 18:37:16 --> Security Class Initialized
DEBUG - 2018-03-16 18:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:37:16 --> Input Class Initialized
INFO - 2018-03-16 18:37:16 --> Language Class Initialized
INFO - 2018-03-16 18:37:16 --> Loader Class Initialized
INFO - 2018-03-16 18:37:16 --> Helper loaded: url_helper
INFO - 2018-03-16 18:37:16 --> Helper loaded: site_helper
INFO - 2018-03-16 18:37:16 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:16 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:37:16 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:37:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:37:16 --> Controller Class Initialized
INFO - 2018-03-16 18:37:16 --> User Agent Class Initialized
INFO - 2018-03-16 18:37:16 --> Model "site_model" initialized
INFO - 2018-03-16 18:37:16 --> Model "user_model" initialized
INFO - 2018-03-16 18:37:16 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:37:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:37:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:37:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:37:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:37:16 --> Final output sent to browser
DEBUG - 2018-03-16 18:37:16 --> Total execution time: 0.0475
INFO - 2018-03-16 18:37:17 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:17 --> Config Class Initialized
INFO - 2018-03-16 18:37:17 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:37:17 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:37:17 --> Utf8 Class Initialized
INFO - 2018-03-16 18:37:17 --> URI Class Initialized
DEBUG - 2018-03-16 18:37:17 --> No URI present. Default controller set.
INFO - 2018-03-16 18:37:17 --> Router Class Initialized
INFO - 2018-03-16 18:37:17 --> Output Class Initialized
INFO - 2018-03-16 18:37:17 --> Security Class Initialized
DEBUG - 2018-03-16 18:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:37:17 --> Input Class Initialized
INFO - 2018-03-16 18:37:17 --> Language Class Initialized
INFO - 2018-03-16 18:37:17 --> Loader Class Initialized
INFO - 2018-03-16 18:37:17 --> Helper loaded: url_helper
INFO - 2018-03-16 18:37:17 --> Helper loaded: site_helper
INFO - 2018-03-16 18:37:17 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:17 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:37:17 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:37:17 --> Controller Class Initialized
INFO - 2018-03-16 18:37:17 --> User Agent Class Initialized
INFO - 2018-03-16 18:37:17 --> Model "site_model" initialized
INFO - 2018-03-16 18:37:17 --> Model "user_model" initialized
INFO - 2018-03-16 18:37:17 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:37:17 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:37:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:37:17 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:37:17 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:37:17 --> Final output sent to browser
DEBUG - 2018-03-16 18:37:17 --> Total execution time: 0.0450
INFO - 2018-03-16 18:37:20 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:20 --> Config Class Initialized
INFO - 2018-03-16 18:37:20 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:37:20 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:37:20 --> Utf8 Class Initialized
INFO - 2018-03-16 18:37:20 --> URI Class Initialized
DEBUG - 2018-03-16 18:37:20 --> No URI present. Default controller set.
INFO - 2018-03-16 18:37:20 --> Router Class Initialized
INFO - 2018-03-16 18:37:20 --> Output Class Initialized
INFO - 2018-03-16 18:37:20 --> Security Class Initialized
DEBUG - 2018-03-16 18:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:37:20 --> Input Class Initialized
INFO - 2018-03-16 18:37:20 --> Language Class Initialized
INFO - 2018-03-16 18:37:20 --> Loader Class Initialized
INFO - 2018-03-16 18:37:20 --> Helper loaded: url_helper
INFO - 2018-03-16 18:37:20 --> Helper loaded: site_helper
INFO - 2018-03-16 18:37:20 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:20 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:37:20 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:37:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:37:20 --> Controller Class Initialized
INFO - 2018-03-16 18:37:20 --> User Agent Class Initialized
INFO - 2018-03-16 18:37:20 --> Model "site_model" initialized
INFO - 2018-03-16 18:37:20 --> Model "user_model" initialized
INFO - 2018-03-16 18:37:20 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:37:20 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:37:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:37:20 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:37:20 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:37:20 --> Final output sent to browser
DEBUG - 2018-03-16 18:37:20 --> Total execution time: 0.0450
INFO - 2018-03-16 18:37:20 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:20 --> Config Class Initialized
INFO - 2018-03-16 18:37:20 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:37:20 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:37:20 --> Utf8 Class Initialized
INFO - 2018-03-16 18:37:20 --> URI Class Initialized
DEBUG - 2018-03-16 18:37:20 --> No URI present. Default controller set.
INFO - 2018-03-16 18:37:20 --> Router Class Initialized
INFO - 2018-03-16 18:37:20 --> Output Class Initialized
INFO - 2018-03-16 18:37:20 --> Security Class Initialized
DEBUG - 2018-03-16 18:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:37:20 --> Input Class Initialized
INFO - 2018-03-16 18:37:20 --> Language Class Initialized
INFO - 2018-03-16 18:37:20 --> Loader Class Initialized
INFO - 2018-03-16 18:37:20 --> Helper loaded: url_helper
INFO - 2018-03-16 18:37:20 --> Helper loaded: site_helper
INFO - 2018-03-16 18:37:20 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:20 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:37:20 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:37:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:37:20 --> Controller Class Initialized
INFO - 2018-03-16 18:37:20 --> User Agent Class Initialized
INFO - 2018-03-16 18:37:20 --> Model "site_model" initialized
INFO - 2018-03-16 18:37:20 --> Model "user_model" initialized
INFO - 2018-03-16 18:37:20 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:37:20 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:37:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:37:20 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:37:20 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:37:20 --> Final output sent to browser
DEBUG - 2018-03-16 18:37:20 --> Total execution time: 0.0455
INFO - 2018-03-16 18:37:24 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:24 --> Config Class Initialized
INFO - 2018-03-16 18:37:24 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:37:24 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:37:24 --> Utf8 Class Initialized
INFO - 2018-03-16 18:37:24 --> URI Class Initialized
DEBUG - 2018-03-16 18:37:24 --> No URI present. Default controller set.
INFO - 2018-03-16 18:37:24 --> Router Class Initialized
INFO - 2018-03-16 18:37:24 --> Output Class Initialized
INFO - 2018-03-16 18:37:24 --> Security Class Initialized
DEBUG - 2018-03-16 18:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:37:24 --> Input Class Initialized
INFO - 2018-03-16 18:37:24 --> Language Class Initialized
INFO - 2018-03-16 18:37:24 --> Loader Class Initialized
INFO - 2018-03-16 18:37:24 --> Helper loaded: url_helper
INFO - 2018-03-16 18:37:24 --> Helper loaded: site_helper
INFO - 2018-03-16 18:37:24 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:24 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:37:24 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:37:24 --> Controller Class Initialized
INFO - 2018-03-16 18:37:24 --> User Agent Class Initialized
INFO - 2018-03-16 18:37:24 --> Model "site_model" initialized
INFO - 2018-03-16 18:37:24 --> Model "user_model" initialized
INFO - 2018-03-16 18:37:24 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:37:24 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:37:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:37:24 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:37:24 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:37:24 --> Final output sent to browser
DEBUG - 2018-03-16 18:37:24 --> Total execution time: 0.0790
INFO - 2018-03-16 18:37:39 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:39 --> Config Class Initialized
INFO - 2018-03-16 18:37:39 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:37:39 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:37:39 --> Utf8 Class Initialized
INFO - 2018-03-16 18:37:39 --> URI Class Initialized
DEBUG - 2018-03-16 18:37:39 --> No URI present. Default controller set.
INFO - 2018-03-16 18:37:39 --> Router Class Initialized
INFO - 2018-03-16 18:37:39 --> Output Class Initialized
INFO - 2018-03-16 18:37:39 --> Security Class Initialized
DEBUG - 2018-03-16 18:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:37:39 --> Input Class Initialized
INFO - 2018-03-16 18:37:39 --> Language Class Initialized
INFO - 2018-03-16 18:37:39 --> Loader Class Initialized
INFO - 2018-03-16 18:37:39 --> Helper loaded: url_helper
INFO - 2018-03-16 18:37:39 --> Helper loaded: site_helper
INFO - 2018-03-16 18:37:39 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:39 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:37:39 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:37:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:37:39 --> Controller Class Initialized
INFO - 2018-03-16 18:37:39 --> User Agent Class Initialized
INFO - 2018-03-16 18:37:39 --> Model "site_model" initialized
INFO - 2018-03-16 18:37:39 --> Model "user_model" initialized
INFO - 2018-03-16 18:37:39 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:37:39 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:37:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:37:39 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:37:39 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:37:39 --> Final output sent to browser
DEBUG - 2018-03-16 18:37:39 --> Total execution time: 0.0575
INFO - 2018-03-16 18:37:44 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:44 --> Config Class Initialized
INFO - 2018-03-16 18:37:44 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:37:44 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:37:44 --> Utf8 Class Initialized
INFO - 2018-03-16 18:37:44 --> URI Class Initialized
DEBUG - 2018-03-16 18:37:44 --> No URI present. Default controller set.
INFO - 2018-03-16 18:37:44 --> Router Class Initialized
INFO - 2018-03-16 18:37:44 --> Output Class Initialized
INFO - 2018-03-16 18:37:44 --> Security Class Initialized
DEBUG - 2018-03-16 18:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:37:44 --> Input Class Initialized
INFO - 2018-03-16 18:37:44 --> Language Class Initialized
INFO - 2018-03-16 18:37:44 --> Loader Class Initialized
INFO - 2018-03-16 18:37:44 --> Helper loaded: url_helper
INFO - 2018-03-16 18:37:44 --> Helper loaded: site_helper
INFO - 2018-03-16 18:37:44 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:44 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:37:44 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:37:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:37:44 --> Controller Class Initialized
INFO - 2018-03-16 18:37:44 --> User Agent Class Initialized
INFO - 2018-03-16 18:37:44 --> Model "site_model" initialized
INFO - 2018-03-16 18:37:44 --> Model "user_model" initialized
INFO - 2018-03-16 18:37:44 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:37:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:37:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:37:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:37:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:37:44 --> Final output sent to browser
DEBUG - 2018-03-16 18:37:44 --> Total execution time: 0.0525
INFO - 2018-03-16 18:37:49 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:49 --> Config Class Initialized
INFO - 2018-03-16 18:37:49 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:37:49 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:37:49 --> Utf8 Class Initialized
INFO - 2018-03-16 18:37:49 --> URI Class Initialized
DEBUG - 2018-03-16 18:37:49 --> No URI present. Default controller set.
INFO - 2018-03-16 18:37:49 --> Router Class Initialized
INFO - 2018-03-16 18:37:49 --> Output Class Initialized
INFO - 2018-03-16 18:37:49 --> Security Class Initialized
DEBUG - 2018-03-16 18:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:37:49 --> Input Class Initialized
INFO - 2018-03-16 18:37:50 --> Language Class Initialized
INFO - 2018-03-16 18:37:50 --> Loader Class Initialized
INFO - 2018-03-16 18:37:50 --> Helper loaded: url_helper
INFO - 2018-03-16 18:37:50 --> Helper loaded: site_helper
INFO - 2018-03-16 18:37:50 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:50 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:37:50 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:37:50 --> Controller Class Initialized
INFO - 2018-03-16 18:37:50 --> User Agent Class Initialized
INFO - 2018-03-16 18:37:50 --> Model "site_model" initialized
INFO - 2018-03-16 18:37:50 --> Model "user_model" initialized
INFO - 2018-03-16 18:37:50 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:37:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:37:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:37:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:37:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:37:50 --> Final output sent to browser
DEBUG - 2018-03-16 18:37:50 --> Total execution time: 0.0900
INFO - 2018-03-16 18:37:55 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:55 --> Config Class Initialized
INFO - 2018-03-16 18:37:55 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:37:55 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:37:55 --> Utf8 Class Initialized
INFO - 2018-03-16 18:37:55 --> URI Class Initialized
DEBUG - 2018-03-16 18:37:55 --> No URI present. Default controller set.
INFO - 2018-03-16 18:37:55 --> Router Class Initialized
INFO - 2018-03-16 18:37:55 --> Output Class Initialized
INFO - 2018-03-16 18:37:55 --> Security Class Initialized
DEBUG - 2018-03-16 18:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:37:55 --> Input Class Initialized
INFO - 2018-03-16 18:37:55 --> Language Class Initialized
INFO - 2018-03-16 18:37:55 --> Loader Class Initialized
INFO - 2018-03-16 18:37:55 --> Helper loaded: url_helper
INFO - 2018-03-16 18:37:55 --> Helper loaded: site_helper
INFO - 2018-03-16 18:37:55 --> Database Driver Class Initialized
INFO - 2018-03-16 18:37:55 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:37:55 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:37:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:37:55 --> Controller Class Initialized
INFO - 2018-03-16 18:37:55 --> User Agent Class Initialized
INFO - 2018-03-16 18:37:55 --> Model "site_model" initialized
INFO - 2018-03-16 18:37:55 --> Model "user_model" initialized
INFO - 2018-03-16 18:37:55 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:37:55 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:37:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:37:55 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:37:55 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:37:55 --> Final output sent to browser
DEBUG - 2018-03-16 18:37:55 --> Total execution time: 0.0525
INFO - 2018-03-16 18:38:04 --> Database Driver Class Initialized
INFO - 2018-03-16 18:38:04 --> Config Class Initialized
INFO - 2018-03-16 18:38:04 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:38:04 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:38:04 --> Utf8 Class Initialized
INFO - 2018-03-16 18:38:04 --> URI Class Initialized
DEBUG - 2018-03-16 18:38:04 --> No URI present. Default controller set.
INFO - 2018-03-16 18:38:04 --> Router Class Initialized
INFO - 2018-03-16 18:38:04 --> Output Class Initialized
INFO - 2018-03-16 18:38:04 --> Security Class Initialized
DEBUG - 2018-03-16 18:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:38:04 --> Input Class Initialized
INFO - 2018-03-16 18:38:04 --> Language Class Initialized
INFO - 2018-03-16 18:38:04 --> Loader Class Initialized
INFO - 2018-03-16 18:38:04 --> Helper loaded: url_helper
INFO - 2018-03-16 18:38:04 --> Helper loaded: site_helper
INFO - 2018-03-16 18:38:04 --> Database Driver Class Initialized
INFO - 2018-03-16 18:38:04 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:38:04 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:38:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:38:04 --> Controller Class Initialized
INFO - 2018-03-16 18:38:04 --> User Agent Class Initialized
INFO - 2018-03-16 18:38:04 --> Model "site_model" initialized
INFO - 2018-03-16 18:38:04 --> Model "user_model" initialized
INFO - 2018-03-16 18:38:04 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:38:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:38:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:38:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:38:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:38:04 --> Final output sent to browser
DEBUG - 2018-03-16 18:38:04 --> Total execution time: 0.0600
INFO - 2018-03-16 18:39:55 --> Database Driver Class Initialized
INFO - 2018-03-16 18:39:55 --> Config Class Initialized
INFO - 2018-03-16 18:39:55 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:39:55 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:39:55 --> Utf8 Class Initialized
INFO - 2018-03-16 18:39:55 --> URI Class Initialized
DEBUG - 2018-03-16 18:39:55 --> No URI present. Default controller set.
INFO - 2018-03-16 18:39:55 --> Router Class Initialized
INFO - 2018-03-16 18:39:55 --> Output Class Initialized
INFO - 2018-03-16 18:39:55 --> Security Class Initialized
DEBUG - 2018-03-16 18:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:39:55 --> Input Class Initialized
INFO - 2018-03-16 18:39:55 --> Language Class Initialized
INFO - 2018-03-16 18:39:55 --> Loader Class Initialized
INFO - 2018-03-16 18:39:55 --> Helper loaded: url_helper
INFO - 2018-03-16 18:39:55 --> Helper loaded: site_helper
INFO - 2018-03-16 18:39:55 --> Database Driver Class Initialized
INFO - 2018-03-16 18:39:55 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:39:55 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:39:55 --> Controller Class Initialized
INFO - 2018-03-16 18:39:55 --> User Agent Class Initialized
INFO - 2018-03-16 18:39:55 --> Model "site_model" initialized
INFO - 2018-03-16 18:39:55 --> Model "user_model" initialized
INFO - 2018-03-16 18:39:55 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:39:55 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:39:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:39:55 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:39:55 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:39:55 --> Final output sent to browser
DEBUG - 2018-03-16 18:39:55 --> Total execution time: 0.0775
INFO - 2018-03-16 18:39:59 --> Database Driver Class Initialized
INFO - 2018-03-16 18:39:59 --> Config Class Initialized
INFO - 2018-03-16 18:39:59 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:39:59 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:39:59 --> Utf8 Class Initialized
INFO - 2018-03-16 18:39:59 --> URI Class Initialized
DEBUG - 2018-03-16 18:39:59 --> No URI present. Default controller set.
INFO - 2018-03-16 18:39:59 --> Router Class Initialized
INFO - 2018-03-16 18:39:59 --> Output Class Initialized
INFO - 2018-03-16 18:39:59 --> Security Class Initialized
DEBUG - 2018-03-16 18:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:39:59 --> Input Class Initialized
INFO - 2018-03-16 18:39:59 --> Language Class Initialized
INFO - 2018-03-16 18:39:59 --> Loader Class Initialized
INFO - 2018-03-16 18:39:59 --> Helper loaded: url_helper
INFO - 2018-03-16 18:39:59 --> Helper loaded: site_helper
INFO - 2018-03-16 18:39:59 --> Database Driver Class Initialized
INFO - 2018-03-16 18:39:59 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:39:59 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:39:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:39:59 --> Controller Class Initialized
INFO - 2018-03-16 18:39:59 --> User Agent Class Initialized
INFO - 2018-03-16 18:39:59 --> Model "site_model" initialized
INFO - 2018-03-16 18:39:59 --> Model "user_model" initialized
INFO - 2018-03-16 18:39:59 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:39:59 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:39:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:39:59 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:39:59 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:39:59 --> Final output sent to browser
DEBUG - 2018-03-16 18:39:59 --> Total execution time: 0.0700
INFO - 2018-03-16 18:43:20 --> Database Driver Class Initialized
INFO - 2018-03-16 18:43:20 --> Config Class Initialized
INFO - 2018-03-16 18:43:20 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:43:20 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:43:20 --> Utf8 Class Initialized
INFO - 2018-03-16 18:43:20 --> URI Class Initialized
DEBUG - 2018-03-16 18:43:21 --> No URI present. Default controller set.
INFO - 2018-03-16 18:43:21 --> Router Class Initialized
INFO - 2018-03-16 18:43:21 --> Output Class Initialized
INFO - 2018-03-16 18:43:21 --> Security Class Initialized
DEBUG - 2018-03-16 18:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:43:21 --> Input Class Initialized
INFO - 2018-03-16 18:43:21 --> Language Class Initialized
INFO - 2018-03-16 18:43:21 --> Loader Class Initialized
INFO - 2018-03-16 18:43:21 --> Helper loaded: url_helper
INFO - 2018-03-16 18:43:21 --> Helper loaded: site_helper
INFO - 2018-03-16 18:43:21 --> Database Driver Class Initialized
INFO - 2018-03-16 18:43:21 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:43:21 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:43:21 --> Controller Class Initialized
INFO - 2018-03-16 18:43:21 --> User Agent Class Initialized
INFO - 2018-03-16 18:43:21 --> Model "site_model" initialized
INFO - 2018-03-16 18:43:21 --> Model "user_model" initialized
INFO - 2018-03-16 18:43:22 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:43:22 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 18:43:23 --> Database Driver Class Initialized
INFO - 2018-03-16 18:43:23 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:43:23 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:43:23 --> Final output sent to browser
DEBUG - 2018-03-16 18:43:23 --> Total execution time: 2.1695
INFO - 2018-03-16 18:43:23 --> Config Class Initialized
INFO - 2018-03-16 18:43:23 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:43:23 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:43:23 --> Utf8 Class Initialized
INFO - 2018-03-16 18:43:23 --> URI Class Initialized
DEBUG - 2018-03-16 18:43:23 --> No URI present. Default controller set.
INFO - 2018-03-16 18:43:23 --> Router Class Initialized
INFO - 2018-03-16 18:43:23 --> Output Class Initialized
INFO - 2018-03-16 18:43:23 --> Security Class Initialized
DEBUG - 2018-03-16 18:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:43:23 --> Input Class Initialized
INFO - 2018-03-16 18:43:23 --> Language Class Initialized
INFO - 2018-03-16 18:43:23 --> Loader Class Initialized
INFO - 2018-03-16 18:43:23 --> Helper loaded: url_helper
INFO - 2018-03-16 18:43:23 --> Helper loaded: site_helper
INFO - 2018-03-16 18:43:23 --> Database Driver Class Initialized
INFO - 2018-03-16 18:43:23 --> Database Driver Class Initialized
INFO - 2018-03-16 18:43:24 --> Config Class Initialized
INFO - 2018-03-16 18:43:24 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:43:24 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:43:24 --> Utf8 Class Initialized
INFO - 2018-03-16 18:43:24 --> URI Class Initialized
DEBUG - 2018-03-16 18:43:24 --> No URI present. Default controller set.
INFO - 2018-03-16 18:43:24 --> Router Class Initialized
INFO - 2018-03-16 18:43:24 --> Output Class Initialized
INFO - 2018-03-16 18:43:24 --> Security Class Initialized
DEBUG - 2018-03-16 18:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:43:24 --> Input Class Initialized
INFO - 2018-03-16 18:43:24 --> Language Class Initialized
INFO - 2018-03-16 18:43:24 --> Loader Class Initialized
INFO - 2018-03-16 18:43:24 --> Helper loaded: url_helper
INFO - 2018-03-16 18:43:24 --> Helper loaded: site_helper
INFO - 2018-03-16 18:43:24 --> Database Driver Class Initialized
INFO - 2018-03-16 18:43:24 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:43:24 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:43:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:43:24 --> Controller Class Initialized
INFO - 2018-03-16 18:43:24 --> User Agent Class Initialized
INFO - 2018-03-16 18:43:24 --> Model "site_model" initialized
INFO - 2018-03-16 18:43:24 --> Model "user_model" initialized
INFO - 2018-03-16 18:43:24 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:43:24 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 18:43:24 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:43:24 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:43:24 --> Final output sent to browser
DEBUG - 2018-03-16 18:43:24 --> Total execution time: 1.4700
INFO - 2018-03-16 18:43:25 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:43:25 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:43:25 --> Controller Class Initialized
INFO - 2018-03-16 18:43:25 --> User Agent Class Initialized
INFO - 2018-03-16 18:43:25 --> Model "site_model" initialized
INFO - 2018-03-16 18:43:25 --> Model "user_model" initialized
INFO - 2018-03-16 18:43:25 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:43:25 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 18:43:25 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:43:25 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:43:25 --> Final output sent to browser
DEBUG - 2018-03-16 18:43:25 --> Total execution time: 0.8690
INFO - 2018-03-16 18:44:04 --> Database Driver Class Initialized
INFO - 2018-03-16 18:44:04 --> Config Class Initialized
INFO - 2018-03-16 18:44:04 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:44:04 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:44:04 --> Utf8 Class Initialized
INFO - 2018-03-16 18:44:04 --> URI Class Initialized
DEBUG - 2018-03-16 18:44:04 --> No URI present. Default controller set.
INFO - 2018-03-16 18:44:04 --> Router Class Initialized
INFO - 2018-03-16 18:44:04 --> Output Class Initialized
INFO - 2018-03-16 18:44:04 --> Security Class Initialized
DEBUG - 2018-03-16 18:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:44:04 --> Input Class Initialized
INFO - 2018-03-16 18:44:04 --> Language Class Initialized
INFO - 2018-03-16 18:44:04 --> Loader Class Initialized
INFO - 2018-03-16 18:44:04 --> Helper loaded: url_helper
INFO - 2018-03-16 18:44:04 --> Helper loaded: site_helper
INFO - 2018-03-16 18:44:04 --> Database Driver Class Initialized
INFO - 2018-03-16 18:44:04 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:44:04 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:44:04 --> Controller Class Initialized
INFO - 2018-03-16 18:44:04 --> User Agent Class Initialized
INFO - 2018-03-16 18:44:04 --> Model "site_model" initialized
INFO - 2018-03-16 18:44:04 --> Model "user_model" initialized
INFO - 2018-03-16 18:44:04 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:44:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 18:44:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:44:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:44:04 --> Final output sent to browser
DEBUG - 2018-03-16 18:44:04 --> Total execution time: 0.2775
INFO - 2018-03-16 18:44:08 --> Database Driver Class Initialized
INFO - 2018-03-16 18:44:08 --> Config Class Initialized
INFO - 2018-03-16 18:44:08 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:44:08 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:44:08 --> Utf8 Class Initialized
INFO - 2018-03-16 18:44:08 --> URI Class Initialized
DEBUG - 2018-03-16 18:44:08 --> No URI present. Default controller set.
INFO - 2018-03-16 18:44:08 --> Router Class Initialized
INFO - 2018-03-16 18:44:08 --> Output Class Initialized
INFO - 2018-03-16 18:44:08 --> Security Class Initialized
DEBUG - 2018-03-16 18:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:44:08 --> Input Class Initialized
INFO - 2018-03-16 18:44:08 --> Language Class Initialized
INFO - 2018-03-16 18:44:08 --> Loader Class Initialized
INFO - 2018-03-16 18:44:08 --> Helper loaded: url_helper
INFO - 2018-03-16 18:44:08 --> Helper loaded: site_helper
INFO - 2018-03-16 18:44:08 --> Database Driver Class Initialized
INFO - 2018-03-16 18:44:08 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:44:08 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:44:08 --> Controller Class Initialized
INFO - 2018-03-16 18:44:08 --> User Agent Class Initialized
INFO - 2018-03-16 18:44:08 --> Model "site_model" initialized
INFO - 2018-03-16 18:44:08 --> Model "user_model" initialized
INFO - 2018-03-16 18:44:08 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:44:08 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 18:44:08 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:44:08 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:44:08 --> Final output sent to browser
DEBUG - 2018-03-16 18:44:08 --> Total execution time: 0.2200
INFO - 2018-03-16 18:44:16 --> Database Driver Class Initialized
INFO - 2018-03-16 18:44:16 --> Config Class Initialized
INFO - 2018-03-16 18:44:16 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:44:16 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:44:16 --> Utf8 Class Initialized
INFO - 2018-03-16 18:44:16 --> URI Class Initialized
DEBUG - 2018-03-16 18:44:16 --> No URI present. Default controller set.
INFO - 2018-03-16 18:44:16 --> Router Class Initialized
INFO - 2018-03-16 18:44:16 --> Output Class Initialized
INFO - 2018-03-16 18:44:16 --> Security Class Initialized
DEBUG - 2018-03-16 18:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:44:16 --> Input Class Initialized
INFO - 2018-03-16 18:44:16 --> Language Class Initialized
INFO - 2018-03-16 18:44:16 --> Loader Class Initialized
INFO - 2018-03-16 18:44:16 --> Helper loaded: url_helper
INFO - 2018-03-16 18:44:16 --> Helper loaded: site_helper
INFO - 2018-03-16 18:44:16 --> Database Driver Class Initialized
INFO - 2018-03-16 18:44:16 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:44:16 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:44:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:44:16 --> Controller Class Initialized
INFO - 2018-03-16 18:44:16 --> User Agent Class Initialized
INFO - 2018-03-16 18:44:16 --> Model "site_model" initialized
INFO - 2018-03-16 18:44:16 --> Model "user_model" initialized
INFO - 2018-03-16 18:44:16 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:44:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 18:44:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:44:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:44:16 --> Final output sent to browser
DEBUG - 2018-03-16 18:44:16 --> Total execution time: 0.2275
INFO - 2018-03-16 18:44:21 --> Database Driver Class Initialized
INFO - 2018-03-16 18:44:21 --> Config Class Initialized
INFO - 2018-03-16 18:44:21 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:44:21 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:44:21 --> Utf8 Class Initialized
INFO - 2018-03-16 18:44:21 --> URI Class Initialized
DEBUG - 2018-03-16 18:44:21 --> No URI present. Default controller set.
INFO - 2018-03-16 18:44:21 --> Router Class Initialized
INFO - 2018-03-16 18:44:21 --> Output Class Initialized
INFO - 2018-03-16 18:44:21 --> Security Class Initialized
DEBUG - 2018-03-16 18:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:44:21 --> Input Class Initialized
INFO - 2018-03-16 18:44:21 --> Language Class Initialized
INFO - 2018-03-16 18:44:21 --> Loader Class Initialized
INFO - 2018-03-16 18:44:21 --> Helper loaded: url_helper
INFO - 2018-03-16 18:44:21 --> Helper loaded: site_helper
INFO - 2018-03-16 18:44:21 --> Database Driver Class Initialized
INFO - 2018-03-16 18:44:21 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:44:21 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:44:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:44:21 --> Controller Class Initialized
INFO - 2018-03-16 18:44:21 --> User Agent Class Initialized
INFO - 2018-03-16 18:44:21 --> Model "site_model" initialized
INFO - 2018-03-16 18:44:21 --> Model "user_model" initialized
INFO - 2018-03-16 18:44:21 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:44:21 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 18:44:21 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:44:21 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:44:21 --> Final output sent to browser
DEBUG - 2018-03-16 18:44:21 --> Total execution time: 0.3010
INFO - 2018-03-16 18:44:44 --> Database Driver Class Initialized
INFO - 2018-03-16 18:44:44 --> Config Class Initialized
INFO - 2018-03-16 18:44:44 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:44:44 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:44:44 --> Utf8 Class Initialized
INFO - 2018-03-16 18:44:44 --> URI Class Initialized
DEBUG - 2018-03-16 18:44:44 --> No URI present. Default controller set.
INFO - 2018-03-16 18:44:44 --> Router Class Initialized
INFO - 2018-03-16 18:44:44 --> Output Class Initialized
INFO - 2018-03-16 18:44:44 --> Security Class Initialized
DEBUG - 2018-03-16 18:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:44:44 --> Input Class Initialized
INFO - 2018-03-16 18:44:44 --> Language Class Initialized
INFO - 2018-03-16 18:44:44 --> Loader Class Initialized
INFO - 2018-03-16 18:44:44 --> Helper loaded: url_helper
INFO - 2018-03-16 18:44:44 --> Helper loaded: site_helper
INFO - 2018-03-16 18:44:44 --> Database Driver Class Initialized
INFO - 2018-03-16 18:44:44 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:44:44 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:44:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:44:44 --> Controller Class Initialized
INFO - 2018-03-16 18:44:44 --> User Agent Class Initialized
INFO - 2018-03-16 18:44:44 --> Model "site_model" initialized
INFO - 2018-03-16 18:44:44 --> Model "user_model" initialized
INFO - 2018-03-16 18:44:44 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:44:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:44:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 18:44:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:44:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:44:44 --> Final output sent to browser
DEBUG - 2018-03-16 18:44:44 --> Total execution time: 0.2205
INFO - 2018-03-16 18:44:58 --> Database Driver Class Initialized
INFO - 2018-03-16 18:44:58 --> Config Class Initialized
INFO - 2018-03-16 18:44:58 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:44:58 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:44:58 --> Utf8 Class Initialized
INFO - 2018-03-16 18:44:58 --> URI Class Initialized
DEBUG - 2018-03-16 18:44:58 --> No URI present. Default controller set.
INFO - 2018-03-16 18:44:58 --> Router Class Initialized
INFO - 2018-03-16 18:44:58 --> Output Class Initialized
INFO - 2018-03-16 18:44:58 --> Security Class Initialized
DEBUG - 2018-03-16 18:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:44:58 --> Input Class Initialized
INFO - 2018-03-16 18:44:58 --> Language Class Initialized
INFO - 2018-03-16 18:44:58 --> Loader Class Initialized
INFO - 2018-03-16 18:44:58 --> Helper loaded: url_helper
INFO - 2018-03-16 18:44:58 --> Helper loaded: site_helper
INFO - 2018-03-16 18:44:58 --> Database Driver Class Initialized
INFO - 2018-03-16 18:44:58 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:44:58 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:44:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:44:58 --> Controller Class Initialized
INFO - 2018-03-16 18:44:58 --> User Agent Class Initialized
INFO - 2018-03-16 18:44:58 --> Model "site_model" initialized
INFO - 2018-03-16 18:44:58 --> Model "user_model" initialized
INFO - 2018-03-16 18:44:58 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:44:58 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 18:44:58 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:44:58 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:44:58 --> Final output sent to browser
DEBUG - 2018-03-16 18:44:58 --> Total execution time: 0.0525
INFO - 2018-03-16 18:45:02 --> Database Driver Class Initialized
INFO - 2018-03-16 18:45:02 --> Config Class Initialized
INFO - 2018-03-16 18:45:02 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:45:02 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:45:02 --> Utf8 Class Initialized
INFO - 2018-03-16 18:45:02 --> URI Class Initialized
DEBUG - 2018-03-16 18:45:02 --> No URI present. Default controller set.
INFO - 2018-03-16 18:45:02 --> Router Class Initialized
INFO - 2018-03-16 18:45:02 --> Output Class Initialized
INFO - 2018-03-16 18:45:02 --> Security Class Initialized
DEBUG - 2018-03-16 18:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:45:02 --> Input Class Initialized
INFO - 2018-03-16 18:45:02 --> Language Class Initialized
INFO - 2018-03-16 18:45:02 --> Loader Class Initialized
INFO - 2018-03-16 18:45:02 --> Helper loaded: url_helper
INFO - 2018-03-16 18:45:02 --> Helper loaded: site_helper
INFO - 2018-03-16 18:45:02 --> Database Driver Class Initialized
INFO - 2018-03-16 18:45:02 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:45:02 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:45:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:45:02 --> Controller Class Initialized
INFO - 2018-03-16 18:45:02 --> User Agent Class Initialized
INFO - 2018-03-16 18:45:02 --> Model "site_model" initialized
INFO - 2018-03-16 18:45:02 --> Model "user_model" initialized
INFO - 2018-03-16 18:45:02 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:45:02 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 18:45:02 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:45:02 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:45:02 --> Final output sent to browser
DEBUG - 2018-03-16 18:45:02 --> Total execution time: 0.0550
INFO - 2018-03-16 18:45:07 --> Database Driver Class Initialized
INFO - 2018-03-16 18:45:07 --> Config Class Initialized
INFO - 2018-03-16 18:45:07 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:45:07 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:45:07 --> Utf8 Class Initialized
INFO - 2018-03-16 18:45:07 --> URI Class Initialized
DEBUG - 2018-03-16 18:45:07 --> No URI present. Default controller set.
INFO - 2018-03-16 18:45:07 --> Router Class Initialized
INFO - 2018-03-16 18:45:07 --> Output Class Initialized
INFO - 2018-03-16 18:45:07 --> Security Class Initialized
DEBUG - 2018-03-16 18:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:45:07 --> Input Class Initialized
INFO - 2018-03-16 18:45:07 --> Language Class Initialized
INFO - 2018-03-16 18:45:07 --> Loader Class Initialized
INFO - 2018-03-16 18:45:07 --> Helper loaded: url_helper
INFO - 2018-03-16 18:45:07 --> Helper loaded: site_helper
INFO - 2018-03-16 18:45:07 --> Database Driver Class Initialized
INFO - 2018-03-16 18:45:07 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:45:07 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:45:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:45:07 --> Controller Class Initialized
INFO - 2018-03-16 18:45:07 --> User Agent Class Initialized
INFO - 2018-03-16 18:45:07 --> Model "site_model" initialized
INFO - 2018-03-16 18:45:07 --> Model "user_model" initialized
INFO - 2018-03-16 18:45:07 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:45:07 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 18:45:07 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:45:07 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:45:07 --> Final output sent to browser
DEBUG - 2018-03-16 18:45:07 --> Total execution time: 0.0570
INFO - 2018-03-16 18:45:13 --> Database Driver Class Initialized
INFO - 2018-03-16 18:45:13 --> Config Class Initialized
INFO - 2018-03-16 18:45:13 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:45:13 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:45:13 --> Utf8 Class Initialized
INFO - 2018-03-16 18:45:13 --> URI Class Initialized
DEBUG - 2018-03-16 18:45:13 --> No URI present. Default controller set.
INFO - 2018-03-16 18:45:13 --> Router Class Initialized
INFO - 2018-03-16 18:45:13 --> Output Class Initialized
INFO - 2018-03-16 18:45:13 --> Security Class Initialized
DEBUG - 2018-03-16 18:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:45:13 --> Input Class Initialized
INFO - 2018-03-16 18:45:13 --> Language Class Initialized
INFO - 2018-03-16 18:45:13 --> Loader Class Initialized
INFO - 2018-03-16 18:45:13 --> Helper loaded: url_helper
INFO - 2018-03-16 18:45:13 --> Helper loaded: site_helper
INFO - 2018-03-16 18:45:13 --> Database Driver Class Initialized
INFO - 2018-03-16 18:45:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:45:13 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:45:13 --> Controller Class Initialized
INFO - 2018-03-16 18:45:13 --> User Agent Class Initialized
INFO - 2018-03-16 18:45:13 --> Model "site_model" initialized
INFO - 2018-03-16 18:45:13 --> Model "user_model" initialized
INFO - 2018-03-16 18:45:13 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:45:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 18:45:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:45:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:45:13 --> Final output sent to browser
DEBUG - 2018-03-16 18:45:13 --> Total execution time: 0.0450
INFO - 2018-03-16 18:45:16 --> Database Driver Class Initialized
INFO - 2018-03-16 18:45:16 --> Config Class Initialized
INFO - 2018-03-16 18:45:16 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:45:16 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:45:16 --> Utf8 Class Initialized
INFO - 2018-03-16 18:45:16 --> URI Class Initialized
DEBUG - 2018-03-16 18:45:16 --> No URI present. Default controller set.
INFO - 2018-03-16 18:45:16 --> Router Class Initialized
INFO - 2018-03-16 18:45:16 --> Output Class Initialized
INFO - 2018-03-16 18:45:16 --> Security Class Initialized
DEBUG - 2018-03-16 18:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:45:16 --> Input Class Initialized
INFO - 2018-03-16 18:45:16 --> Language Class Initialized
INFO - 2018-03-16 18:45:16 --> Loader Class Initialized
INFO - 2018-03-16 18:45:16 --> Helper loaded: url_helper
INFO - 2018-03-16 18:45:16 --> Helper loaded: site_helper
INFO - 2018-03-16 18:45:16 --> Database Driver Class Initialized
INFO - 2018-03-16 18:45:16 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:45:16 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:45:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:45:16 --> Controller Class Initialized
INFO - 2018-03-16 18:45:16 --> User Agent Class Initialized
INFO - 2018-03-16 18:45:16 --> Model "site_model" initialized
INFO - 2018-03-16 18:45:16 --> Model "user_model" initialized
INFO - 2018-03-16 18:45:16 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:45:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 18:45:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:45:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:45:16 --> Final output sent to browser
DEBUG - 2018-03-16 18:45:16 --> Total execution time: 0.0525
INFO - 2018-03-16 18:45:17 --> Database Driver Class Initialized
INFO - 2018-03-16 18:45:17 --> Config Class Initialized
INFO - 2018-03-16 18:45:17 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:45:17 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:45:17 --> Utf8 Class Initialized
INFO - 2018-03-16 18:45:17 --> URI Class Initialized
DEBUG - 2018-03-16 18:45:17 --> No URI present. Default controller set.
INFO - 2018-03-16 18:45:17 --> Router Class Initialized
INFO - 2018-03-16 18:45:17 --> Output Class Initialized
INFO - 2018-03-16 18:45:17 --> Security Class Initialized
DEBUG - 2018-03-16 18:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:45:17 --> Input Class Initialized
INFO - 2018-03-16 18:45:17 --> Language Class Initialized
INFO - 2018-03-16 18:45:17 --> Loader Class Initialized
INFO - 2018-03-16 18:45:17 --> Helper loaded: url_helper
INFO - 2018-03-16 18:45:17 --> Helper loaded: site_helper
INFO - 2018-03-16 18:45:17 --> Database Driver Class Initialized
INFO - 2018-03-16 18:45:17 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:45:17 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:45:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:45:17 --> Controller Class Initialized
INFO - 2018-03-16 18:45:17 --> User Agent Class Initialized
INFO - 2018-03-16 18:45:17 --> Model "site_model" initialized
INFO - 2018-03-16 18:45:17 --> Model "user_model" initialized
INFO - 2018-03-16 18:45:17 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:45:17 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 18:45:17 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:45:17 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:45:17 --> Final output sent to browser
DEBUG - 2018-03-16 18:45:17 --> Total execution time: 0.0575
INFO - 2018-03-16 18:45:19 --> Database Driver Class Initialized
INFO - 2018-03-16 18:45:19 --> Config Class Initialized
INFO - 2018-03-16 18:45:19 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:45:19 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:45:19 --> Utf8 Class Initialized
INFO - 2018-03-16 18:45:19 --> URI Class Initialized
DEBUG - 2018-03-16 18:45:19 --> No URI present. Default controller set.
INFO - 2018-03-16 18:45:19 --> Router Class Initialized
INFO - 2018-03-16 18:45:19 --> Output Class Initialized
INFO - 2018-03-16 18:45:19 --> Security Class Initialized
DEBUG - 2018-03-16 18:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:45:19 --> Input Class Initialized
INFO - 2018-03-16 18:45:19 --> Language Class Initialized
INFO - 2018-03-16 18:45:19 --> Loader Class Initialized
INFO - 2018-03-16 18:45:19 --> Helper loaded: url_helper
INFO - 2018-03-16 18:45:19 --> Helper loaded: site_helper
INFO - 2018-03-16 18:45:19 --> Database Driver Class Initialized
INFO - 2018-03-16 18:45:19 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:45:19 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:45:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:45:19 --> Controller Class Initialized
INFO - 2018-03-16 18:45:19 --> User Agent Class Initialized
INFO - 2018-03-16 18:45:19 --> Model "site_model" initialized
INFO - 2018-03-16 18:45:19 --> Model "user_model" initialized
INFO - 2018-03-16 18:45:19 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:45:19 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 18:45:19 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:45:19 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:45:19 --> Final output sent to browser
DEBUG - 2018-03-16 18:45:19 --> Total execution time: 0.0550
INFO - 2018-03-16 18:47:25 --> Database Driver Class Initialized
INFO - 2018-03-16 18:47:25 --> Config Class Initialized
INFO - 2018-03-16 18:47:25 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:47:25 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:47:25 --> Utf8 Class Initialized
INFO - 2018-03-16 18:47:25 --> URI Class Initialized
DEBUG - 2018-03-16 18:47:25 --> No URI present. Default controller set.
INFO - 2018-03-16 18:47:25 --> Router Class Initialized
INFO - 2018-03-16 18:47:25 --> Output Class Initialized
INFO - 2018-03-16 18:47:25 --> Security Class Initialized
DEBUG - 2018-03-16 18:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:47:25 --> Input Class Initialized
INFO - 2018-03-16 18:47:25 --> Language Class Initialized
INFO - 2018-03-16 18:47:25 --> Loader Class Initialized
INFO - 2018-03-16 18:47:25 --> Helper loaded: url_helper
INFO - 2018-03-16 18:47:25 --> Helper loaded: site_helper
INFO - 2018-03-16 18:47:25 --> Database Driver Class Initialized
INFO - 2018-03-16 18:47:25 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:47:25 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:47:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:47:25 --> Controller Class Initialized
INFO - 2018-03-16 18:47:25 --> User Agent Class Initialized
INFO - 2018-03-16 18:47:25 --> Model "site_model" initialized
INFO - 2018-03-16 18:47:25 --> Model "user_model" initialized
INFO - 2018-03-16 18:47:25 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:47:25 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 18:47:25 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:47:25 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:47:25 --> Final output sent to browser
DEBUG - 2018-03-16 18:47:25 --> Total execution time: 0.0525
INFO - 2018-03-16 18:47:45 --> Database Driver Class Initialized
INFO - 2018-03-16 18:47:45 --> Config Class Initialized
INFO - 2018-03-16 18:47:45 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:47:45 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:47:45 --> Utf8 Class Initialized
INFO - 2018-03-16 18:47:45 --> URI Class Initialized
DEBUG - 2018-03-16 18:47:45 --> No URI present. Default controller set.
INFO - 2018-03-16 18:47:45 --> Router Class Initialized
INFO - 2018-03-16 18:47:45 --> Output Class Initialized
INFO - 2018-03-16 18:47:45 --> Security Class Initialized
DEBUG - 2018-03-16 18:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:47:45 --> Input Class Initialized
INFO - 2018-03-16 18:47:45 --> Language Class Initialized
INFO - 2018-03-16 18:47:45 --> Loader Class Initialized
INFO - 2018-03-16 18:47:45 --> Helper loaded: url_helper
INFO - 2018-03-16 18:47:45 --> Helper loaded: site_helper
INFO - 2018-03-16 18:47:45 --> Database Driver Class Initialized
INFO - 2018-03-16 18:47:45 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:47:45 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:47:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:47:45 --> Controller Class Initialized
INFO - 2018-03-16 18:47:45 --> User Agent Class Initialized
INFO - 2018-03-16 18:47:45 --> Model "site_model" initialized
INFO - 2018-03-16 18:47:45 --> Model "user_model" initialized
INFO - 2018-03-16 18:47:45 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:47:45 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 18:47:45 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:47:45 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:47:45 --> Final output sent to browser
DEBUG - 2018-03-16 18:47:45 --> Total execution time: 0.0550
INFO - 2018-03-16 18:48:08 --> Database Driver Class Initialized
INFO - 2018-03-16 18:48:08 --> Config Class Initialized
INFO - 2018-03-16 18:48:08 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:48:08 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:48:08 --> Utf8 Class Initialized
INFO - 2018-03-16 18:48:08 --> URI Class Initialized
DEBUG - 2018-03-16 18:48:08 --> No URI present. Default controller set.
INFO - 2018-03-16 18:48:08 --> Router Class Initialized
INFO - 2018-03-16 18:48:08 --> Output Class Initialized
INFO - 2018-03-16 18:48:08 --> Security Class Initialized
DEBUG - 2018-03-16 18:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:48:08 --> Input Class Initialized
INFO - 2018-03-16 18:48:08 --> Language Class Initialized
INFO - 2018-03-16 18:48:08 --> Loader Class Initialized
INFO - 2018-03-16 18:48:08 --> Helper loaded: url_helper
INFO - 2018-03-16 18:48:08 --> Helper loaded: site_helper
INFO - 2018-03-16 18:48:08 --> Database Driver Class Initialized
INFO - 2018-03-16 18:48:08 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:48:08 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:48:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:48:08 --> Controller Class Initialized
INFO - 2018-03-16 18:48:08 --> User Agent Class Initialized
INFO - 2018-03-16 18:48:08 --> Model "site_model" initialized
INFO - 2018-03-16 18:48:08 --> Model "user_model" initialized
INFO - 2018-03-16 18:48:08 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:48:08 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:48:08 --> Severity: error --> Exception: Call to undefined function site_name() D:\xampp\htdocs\myteenmatch\application\views\welcome.php 102
INFO - 2018-03-16 18:48:20 --> Database Driver Class Initialized
INFO - 2018-03-16 18:48:20 --> Config Class Initialized
INFO - 2018-03-16 18:48:20 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:48:20 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:48:20 --> Utf8 Class Initialized
INFO - 2018-03-16 18:48:20 --> URI Class Initialized
DEBUG - 2018-03-16 18:48:20 --> No URI present. Default controller set.
INFO - 2018-03-16 18:48:20 --> Router Class Initialized
INFO - 2018-03-16 18:48:20 --> Output Class Initialized
INFO - 2018-03-16 18:48:20 --> Security Class Initialized
DEBUG - 2018-03-16 18:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:48:20 --> Input Class Initialized
INFO - 2018-03-16 18:48:20 --> Language Class Initialized
INFO - 2018-03-16 18:48:20 --> Loader Class Initialized
INFO - 2018-03-16 18:48:20 --> Helper loaded: url_helper
INFO - 2018-03-16 18:48:20 --> Helper loaded: site_helper
INFO - 2018-03-16 18:48:20 --> Database Driver Class Initialized
INFO - 2018-03-16 18:48:20 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:48:20 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:48:20 --> Controller Class Initialized
INFO - 2018-03-16 18:48:20 --> User Agent Class Initialized
INFO - 2018-03-16 18:48:20 --> Model "site_model" initialized
INFO - 2018-03-16 18:48:20 --> Model "user_model" initialized
INFO - 2018-03-16 18:48:20 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:48:20 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:48:20 --> Severity: error --> Exception: Call to undefined function site_name() D:\xampp\htdocs\myteenmatch\application\views\welcome.php 102
INFO - 2018-03-16 18:48:37 --> Database Driver Class Initialized
INFO - 2018-03-16 18:48:37 --> Config Class Initialized
INFO - 2018-03-16 18:48:37 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:48:37 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:48:37 --> Utf8 Class Initialized
INFO - 2018-03-16 18:48:37 --> URI Class Initialized
DEBUG - 2018-03-16 18:48:37 --> No URI present. Default controller set.
INFO - 2018-03-16 18:48:37 --> Router Class Initialized
INFO - 2018-03-16 18:48:37 --> Output Class Initialized
INFO - 2018-03-16 18:48:37 --> Security Class Initialized
DEBUG - 2018-03-16 18:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:48:37 --> Input Class Initialized
INFO - 2018-03-16 18:48:37 --> Language Class Initialized
INFO - 2018-03-16 18:48:37 --> Loader Class Initialized
INFO - 2018-03-16 18:48:37 --> Helper loaded: url_helper
INFO - 2018-03-16 18:48:37 --> Helper loaded: site_helper
INFO - 2018-03-16 18:48:37 --> Database Driver Class Initialized
INFO - 2018-03-16 18:48:37 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:48:37 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:48:37 --> Controller Class Initialized
INFO - 2018-03-16 18:48:37 --> User Agent Class Initialized
INFO - 2018-03-16 18:48:37 --> Model "site_model" initialized
INFO - 2018-03-16 18:48:37 --> Model "user_model" initialized
INFO - 2018-03-16 18:48:37 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:48:37 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:48:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:48:37 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:48:37 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:48:37 --> Final output sent to browser
DEBUG - 2018-03-16 18:48:37 --> Total execution time: 0.0700
INFO - 2018-03-16 18:49:06 --> Database Driver Class Initialized
INFO - 2018-03-16 18:49:06 --> Config Class Initialized
INFO - 2018-03-16 18:49:06 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:49:06 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:49:06 --> Utf8 Class Initialized
INFO - 2018-03-16 18:49:06 --> URI Class Initialized
DEBUG - 2018-03-16 18:49:06 --> No URI present. Default controller set.
INFO - 2018-03-16 18:49:06 --> Router Class Initialized
INFO - 2018-03-16 18:49:06 --> Output Class Initialized
INFO - 2018-03-16 18:49:06 --> Security Class Initialized
DEBUG - 2018-03-16 18:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:49:06 --> Input Class Initialized
INFO - 2018-03-16 18:49:06 --> Language Class Initialized
INFO - 2018-03-16 18:49:06 --> Loader Class Initialized
INFO - 2018-03-16 18:49:06 --> Helper loaded: url_helper
INFO - 2018-03-16 18:49:06 --> Helper loaded: site_helper
INFO - 2018-03-16 18:49:06 --> Database Driver Class Initialized
INFO - 2018-03-16 18:49:06 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:49:06 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:49:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:49:06 --> Controller Class Initialized
INFO - 2018-03-16 18:49:06 --> User Agent Class Initialized
INFO - 2018-03-16 18:49:06 --> Model "site_model" initialized
INFO - 2018-03-16 18:49:06 --> Model "user_model" initialized
INFO - 2018-03-16 18:49:06 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:49:06 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:49:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:49:06 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:49:06 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:49:06 --> Final output sent to browser
DEBUG - 2018-03-16 18:49:06 --> Total execution time: 0.0550
INFO - 2018-03-16 18:49:26 --> Database Driver Class Initialized
INFO - 2018-03-16 18:49:26 --> Config Class Initialized
INFO - 2018-03-16 18:49:26 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:49:26 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:49:26 --> Utf8 Class Initialized
INFO - 2018-03-16 18:49:26 --> URI Class Initialized
DEBUG - 2018-03-16 18:49:26 --> No URI present. Default controller set.
INFO - 2018-03-16 18:49:26 --> Router Class Initialized
INFO - 2018-03-16 18:49:26 --> Output Class Initialized
INFO - 2018-03-16 18:49:26 --> Security Class Initialized
DEBUG - 2018-03-16 18:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:49:26 --> Input Class Initialized
INFO - 2018-03-16 18:49:26 --> Language Class Initialized
INFO - 2018-03-16 18:49:26 --> Loader Class Initialized
INFO - 2018-03-16 18:49:26 --> Helper loaded: url_helper
INFO - 2018-03-16 18:49:26 --> Helper loaded: site_helper
INFO - 2018-03-16 18:49:26 --> Database Driver Class Initialized
INFO - 2018-03-16 18:49:26 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:49:26 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:49:26 --> Controller Class Initialized
INFO - 2018-03-16 18:49:26 --> User Agent Class Initialized
INFO - 2018-03-16 18:49:26 --> Model "site_model" initialized
INFO - 2018-03-16 18:49:26 --> Model "user_model" initialized
INFO - 2018-03-16 18:49:26 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:49:26 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:49:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:49:26 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:49:26 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:49:26 --> Final output sent to browser
DEBUG - 2018-03-16 18:49:26 --> Total execution time: 0.0575
INFO - 2018-03-16 18:49:32 --> Database Driver Class Initialized
INFO - 2018-03-16 18:49:32 --> Config Class Initialized
INFO - 2018-03-16 18:49:32 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:49:32 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:49:32 --> Utf8 Class Initialized
INFO - 2018-03-16 18:49:32 --> URI Class Initialized
DEBUG - 2018-03-16 18:49:32 --> No URI present. Default controller set.
INFO - 2018-03-16 18:49:32 --> Router Class Initialized
INFO - 2018-03-16 18:49:32 --> Output Class Initialized
INFO - 2018-03-16 18:49:32 --> Security Class Initialized
DEBUG - 2018-03-16 18:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:49:32 --> Input Class Initialized
INFO - 2018-03-16 18:49:32 --> Language Class Initialized
INFO - 2018-03-16 18:49:32 --> Loader Class Initialized
INFO - 2018-03-16 18:49:32 --> Helper loaded: url_helper
INFO - 2018-03-16 18:49:32 --> Helper loaded: site_helper
INFO - 2018-03-16 18:49:32 --> Database Driver Class Initialized
INFO - 2018-03-16 18:49:32 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:49:32 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:49:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:49:32 --> Controller Class Initialized
INFO - 2018-03-16 18:49:32 --> User Agent Class Initialized
INFO - 2018-03-16 18:49:32 --> Model "site_model" initialized
INFO - 2018-03-16 18:49:32 --> Model "user_model" initialized
INFO - 2018-03-16 18:49:32 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:49:32 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:49:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:49:32 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:49:32 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:49:32 --> Final output sent to browser
DEBUG - 2018-03-16 18:49:32 --> Total execution time: 0.0525
INFO - 2018-03-16 18:49:39 --> Database Driver Class Initialized
INFO - 2018-03-16 18:49:39 --> Config Class Initialized
INFO - 2018-03-16 18:49:39 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:49:40 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:49:40 --> Utf8 Class Initialized
INFO - 2018-03-16 18:49:40 --> URI Class Initialized
DEBUG - 2018-03-16 18:49:40 --> No URI present. Default controller set.
INFO - 2018-03-16 18:49:40 --> Router Class Initialized
INFO - 2018-03-16 18:49:40 --> Output Class Initialized
INFO - 2018-03-16 18:49:40 --> Security Class Initialized
DEBUG - 2018-03-16 18:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:49:40 --> Input Class Initialized
INFO - 2018-03-16 18:49:40 --> Language Class Initialized
INFO - 2018-03-16 18:49:40 --> Loader Class Initialized
INFO - 2018-03-16 18:49:40 --> Helper loaded: url_helper
INFO - 2018-03-16 18:49:40 --> Helper loaded: site_helper
INFO - 2018-03-16 18:49:40 --> Database Driver Class Initialized
INFO - 2018-03-16 18:49:40 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:49:40 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:49:40 --> Controller Class Initialized
INFO - 2018-03-16 18:49:40 --> User Agent Class Initialized
INFO - 2018-03-16 18:49:40 --> Model "site_model" initialized
INFO - 2018-03-16 18:49:40 --> Model "user_model" initialized
INFO - 2018-03-16 18:49:40 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:49:40 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:49:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:49:40 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:49:40 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:49:40 --> Final output sent to browser
DEBUG - 2018-03-16 18:49:40 --> Total execution time: 0.0450
INFO - 2018-03-16 18:49:56 --> Database Driver Class Initialized
INFO - 2018-03-16 18:49:56 --> Config Class Initialized
INFO - 2018-03-16 18:49:56 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:49:56 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:49:56 --> Utf8 Class Initialized
INFO - 2018-03-16 18:49:56 --> URI Class Initialized
DEBUG - 2018-03-16 18:49:56 --> No URI present. Default controller set.
INFO - 2018-03-16 18:49:56 --> Router Class Initialized
INFO - 2018-03-16 18:49:56 --> Output Class Initialized
INFO - 2018-03-16 18:49:56 --> Security Class Initialized
DEBUG - 2018-03-16 18:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:49:56 --> Input Class Initialized
INFO - 2018-03-16 18:49:56 --> Language Class Initialized
INFO - 2018-03-16 18:49:56 --> Loader Class Initialized
INFO - 2018-03-16 18:49:56 --> Helper loaded: url_helper
INFO - 2018-03-16 18:49:56 --> Helper loaded: site_helper
INFO - 2018-03-16 18:49:56 --> Database Driver Class Initialized
INFO - 2018-03-16 18:49:56 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:49:56 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:49:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:49:57 --> Controller Class Initialized
INFO - 2018-03-16 18:49:57 --> User Agent Class Initialized
INFO - 2018-03-16 18:49:57 --> Model "site_model" initialized
INFO - 2018-03-16 18:49:57 --> Model "user_model" initialized
INFO - 2018-03-16 18:49:57 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:49:57 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:49:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:49:57 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:49:57 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:49:57 --> Final output sent to browser
DEBUG - 2018-03-16 18:49:57 --> Total execution time: 0.0625
INFO - 2018-03-16 18:50:08 --> Database Driver Class Initialized
INFO - 2018-03-16 18:50:08 --> Config Class Initialized
INFO - 2018-03-16 18:50:08 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:50:08 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:50:08 --> Utf8 Class Initialized
INFO - 2018-03-16 18:50:08 --> URI Class Initialized
DEBUG - 2018-03-16 18:50:08 --> No URI present. Default controller set.
INFO - 2018-03-16 18:50:08 --> Router Class Initialized
INFO - 2018-03-16 18:50:08 --> Output Class Initialized
INFO - 2018-03-16 18:50:08 --> Security Class Initialized
DEBUG - 2018-03-16 18:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:50:08 --> Input Class Initialized
INFO - 2018-03-16 18:50:08 --> Language Class Initialized
INFO - 2018-03-16 18:50:08 --> Loader Class Initialized
INFO - 2018-03-16 18:50:08 --> Helper loaded: url_helper
INFO - 2018-03-16 18:50:08 --> Helper loaded: site_helper
INFO - 2018-03-16 18:50:08 --> Database Driver Class Initialized
INFO - 2018-03-16 18:50:08 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:50:08 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:50:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:50:08 --> Controller Class Initialized
INFO - 2018-03-16 18:50:08 --> User Agent Class Initialized
INFO - 2018-03-16 18:50:08 --> Model "site_model" initialized
INFO - 2018-03-16 18:50:08 --> Model "user_model" initialized
INFO - 2018-03-16 18:50:08 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:50:08 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:50:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:50:08 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:50:08 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:50:08 --> Final output sent to browser
DEBUG - 2018-03-16 18:50:08 --> Total execution time: 0.0600
INFO - 2018-03-16 18:50:27 --> Database Driver Class Initialized
INFO - 2018-03-16 18:50:27 --> Config Class Initialized
INFO - 2018-03-16 18:50:27 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:50:27 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:50:27 --> Utf8 Class Initialized
INFO - 2018-03-16 18:50:27 --> URI Class Initialized
DEBUG - 2018-03-16 18:50:27 --> No URI present. Default controller set.
INFO - 2018-03-16 18:50:27 --> Router Class Initialized
INFO - 2018-03-16 18:50:27 --> Output Class Initialized
INFO - 2018-03-16 18:50:27 --> Security Class Initialized
DEBUG - 2018-03-16 18:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:50:27 --> Input Class Initialized
INFO - 2018-03-16 18:50:27 --> Language Class Initialized
INFO - 2018-03-16 18:50:27 --> Loader Class Initialized
INFO - 2018-03-16 18:50:27 --> Helper loaded: url_helper
INFO - 2018-03-16 18:50:27 --> Helper loaded: site_helper
INFO - 2018-03-16 18:50:27 --> Database Driver Class Initialized
INFO - 2018-03-16 18:50:27 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:50:27 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:50:27 --> Controller Class Initialized
INFO - 2018-03-16 18:50:27 --> User Agent Class Initialized
INFO - 2018-03-16 18:50:27 --> Model "site_model" initialized
INFO - 2018-03-16 18:50:27 --> Model "user_model" initialized
INFO - 2018-03-16 18:50:27 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:50:27 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:50:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:50:27 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:50:27 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:50:27 --> Final output sent to browser
DEBUG - 2018-03-16 18:50:27 --> Total execution time: 0.0575
INFO - 2018-03-16 18:50:28 --> Database Driver Class Initialized
INFO - 2018-03-16 18:50:28 --> Config Class Initialized
INFO - 2018-03-16 18:50:28 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:50:28 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:50:28 --> Utf8 Class Initialized
INFO - 2018-03-16 18:50:28 --> URI Class Initialized
DEBUG - 2018-03-16 18:50:28 --> No URI present. Default controller set.
INFO - 2018-03-16 18:50:28 --> Router Class Initialized
INFO - 2018-03-16 18:50:28 --> Output Class Initialized
INFO - 2018-03-16 18:50:28 --> Security Class Initialized
DEBUG - 2018-03-16 18:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:50:28 --> Input Class Initialized
INFO - 2018-03-16 18:50:28 --> Language Class Initialized
INFO - 2018-03-16 18:50:28 --> Loader Class Initialized
INFO - 2018-03-16 18:50:28 --> Helper loaded: url_helper
INFO - 2018-03-16 18:50:28 --> Helper loaded: site_helper
INFO - 2018-03-16 18:50:28 --> Database Driver Class Initialized
INFO - 2018-03-16 18:50:28 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:50:28 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:50:28 --> Controller Class Initialized
INFO - 2018-03-16 18:50:28 --> User Agent Class Initialized
INFO - 2018-03-16 18:50:28 --> Model "site_model" initialized
INFO - 2018-03-16 18:50:28 --> Model "user_model" initialized
INFO - 2018-03-16 18:50:28 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:50:28 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:50:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:50:28 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:50:28 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:50:28 --> Final output sent to browser
DEBUG - 2018-03-16 18:50:28 --> Total execution time: 0.0525
INFO - 2018-03-16 18:50:42 --> Database Driver Class Initialized
INFO - 2018-03-16 18:50:42 --> Config Class Initialized
INFO - 2018-03-16 18:50:42 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:50:42 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:50:42 --> Utf8 Class Initialized
INFO - 2018-03-16 18:50:42 --> URI Class Initialized
DEBUG - 2018-03-16 18:50:42 --> No URI present. Default controller set.
INFO - 2018-03-16 18:50:42 --> Router Class Initialized
INFO - 2018-03-16 18:50:42 --> Output Class Initialized
INFO - 2018-03-16 18:50:42 --> Security Class Initialized
DEBUG - 2018-03-16 18:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:50:42 --> Input Class Initialized
INFO - 2018-03-16 18:50:42 --> Language Class Initialized
INFO - 2018-03-16 18:50:42 --> Loader Class Initialized
INFO - 2018-03-16 18:50:42 --> Helper loaded: url_helper
INFO - 2018-03-16 18:50:42 --> Helper loaded: site_helper
INFO - 2018-03-16 18:50:42 --> Database Driver Class Initialized
INFO - 2018-03-16 18:50:42 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:50:42 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:50:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:50:42 --> Controller Class Initialized
INFO - 2018-03-16 18:50:42 --> User Agent Class Initialized
INFO - 2018-03-16 18:50:42 --> Model "site_model" initialized
INFO - 2018-03-16 18:50:42 --> Model "user_model" initialized
INFO - 2018-03-16 18:50:42 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:50:42 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:50:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:50:42 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:50:42 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:50:42 --> Final output sent to browser
DEBUG - 2018-03-16 18:50:42 --> Total execution time: 0.0900
INFO - 2018-03-16 18:51:44 --> Database Driver Class Initialized
INFO - 2018-03-16 18:51:44 --> Config Class Initialized
INFO - 2018-03-16 18:51:44 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:51:44 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:51:44 --> Utf8 Class Initialized
INFO - 2018-03-16 18:51:44 --> URI Class Initialized
DEBUG - 2018-03-16 18:51:44 --> No URI present. Default controller set.
INFO - 2018-03-16 18:51:44 --> Router Class Initialized
INFO - 2018-03-16 18:51:44 --> Output Class Initialized
INFO - 2018-03-16 18:51:44 --> Security Class Initialized
DEBUG - 2018-03-16 18:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:51:44 --> Input Class Initialized
INFO - 2018-03-16 18:51:44 --> Language Class Initialized
INFO - 2018-03-16 18:51:44 --> Loader Class Initialized
INFO - 2018-03-16 18:51:44 --> Helper loaded: url_helper
INFO - 2018-03-16 18:51:44 --> Helper loaded: site_helper
INFO - 2018-03-16 18:51:44 --> Database Driver Class Initialized
INFO - 2018-03-16 18:51:44 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:51:44 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:51:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:51:44 --> Controller Class Initialized
INFO - 2018-03-16 18:51:44 --> User Agent Class Initialized
INFO - 2018-03-16 18:51:44 --> Model "site_model" initialized
INFO - 2018-03-16 18:51:44 --> Model "user_model" initialized
INFO - 2018-03-16 18:51:44 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:51:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:51:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:51:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:51:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:51:44 --> Final output sent to browser
DEBUG - 2018-03-16 18:51:45 --> Total execution time: 0.0475
INFO - 2018-03-16 18:51:50 --> Database Driver Class Initialized
INFO - 2018-03-16 18:51:50 --> Config Class Initialized
INFO - 2018-03-16 18:51:50 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:51:50 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:51:50 --> Utf8 Class Initialized
INFO - 2018-03-16 18:51:50 --> URI Class Initialized
DEBUG - 2018-03-16 18:51:50 --> No URI present. Default controller set.
INFO - 2018-03-16 18:51:50 --> Router Class Initialized
INFO - 2018-03-16 18:51:50 --> Output Class Initialized
INFO - 2018-03-16 18:51:50 --> Security Class Initialized
DEBUG - 2018-03-16 18:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:51:50 --> Input Class Initialized
INFO - 2018-03-16 18:51:50 --> Language Class Initialized
INFO - 2018-03-16 18:51:50 --> Loader Class Initialized
INFO - 2018-03-16 18:51:50 --> Helper loaded: url_helper
INFO - 2018-03-16 18:51:50 --> Helper loaded: site_helper
INFO - 2018-03-16 18:51:50 --> Database Driver Class Initialized
INFO - 2018-03-16 18:51:50 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:51:50 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:51:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:51:50 --> Controller Class Initialized
INFO - 2018-03-16 18:51:50 --> User Agent Class Initialized
INFO - 2018-03-16 18:51:50 --> Model "site_model" initialized
INFO - 2018-03-16 18:51:50 --> Model "user_model" initialized
INFO - 2018-03-16 18:51:50 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:51:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:51:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:51:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:51:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:51:50 --> Final output sent to browser
DEBUG - 2018-03-16 18:51:50 --> Total execution time: 0.1200
INFO - 2018-03-16 18:52:01 --> Database Driver Class Initialized
INFO - 2018-03-16 18:52:01 --> Config Class Initialized
INFO - 2018-03-16 18:52:01 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:52:01 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:52:01 --> Utf8 Class Initialized
INFO - 2018-03-16 18:52:02 --> URI Class Initialized
DEBUG - 2018-03-16 18:52:02 --> No URI present. Default controller set.
INFO - 2018-03-16 18:52:02 --> Router Class Initialized
INFO - 2018-03-16 18:52:02 --> Output Class Initialized
INFO - 2018-03-16 18:52:02 --> Security Class Initialized
DEBUG - 2018-03-16 18:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:52:02 --> Input Class Initialized
INFO - 2018-03-16 18:52:02 --> Language Class Initialized
INFO - 2018-03-16 18:52:02 --> Loader Class Initialized
INFO - 2018-03-16 18:52:02 --> Helper loaded: url_helper
INFO - 2018-03-16 18:52:02 --> Helper loaded: site_helper
INFO - 2018-03-16 18:52:02 --> Database Driver Class Initialized
INFO - 2018-03-16 18:52:02 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:52:02 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:52:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:52:02 --> Controller Class Initialized
INFO - 2018-03-16 18:52:02 --> User Agent Class Initialized
INFO - 2018-03-16 18:52:02 --> Model "site_model" initialized
INFO - 2018-03-16 18:52:02 --> Model "user_model" initialized
INFO - 2018-03-16 18:52:02 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:52:02 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:52:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:52:02 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:52:02 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:52:02 --> Final output sent to browser
DEBUG - 2018-03-16 18:52:02 --> Total execution time: 0.0825
INFO - 2018-03-16 18:52:06 --> Database Driver Class Initialized
INFO - 2018-03-16 18:52:06 --> Config Class Initialized
INFO - 2018-03-16 18:52:06 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:52:06 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:52:06 --> Utf8 Class Initialized
INFO - 2018-03-16 18:52:06 --> URI Class Initialized
DEBUG - 2018-03-16 18:52:06 --> No URI present. Default controller set.
INFO - 2018-03-16 18:52:06 --> Router Class Initialized
INFO - 2018-03-16 18:52:06 --> Output Class Initialized
INFO - 2018-03-16 18:52:06 --> Security Class Initialized
DEBUG - 2018-03-16 18:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:52:06 --> Input Class Initialized
INFO - 2018-03-16 18:52:06 --> Language Class Initialized
INFO - 2018-03-16 18:52:06 --> Loader Class Initialized
INFO - 2018-03-16 18:52:06 --> Helper loaded: url_helper
INFO - 2018-03-16 18:52:06 --> Helper loaded: site_helper
INFO - 2018-03-16 18:52:06 --> Database Driver Class Initialized
INFO - 2018-03-16 18:52:06 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:52:06 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:52:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:52:06 --> Controller Class Initialized
INFO - 2018-03-16 18:52:06 --> User Agent Class Initialized
INFO - 2018-03-16 18:52:06 --> Model "site_model" initialized
INFO - 2018-03-16 18:52:06 --> Model "user_model" initialized
INFO - 2018-03-16 18:52:06 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:52:06 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:52:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:52:06 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:52:06 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:52:06 --> Final output sent to browser
DEBUG - 2018-03-16 18:52:06 --> Total execution time: 0.0550
INFO - 2018-03-16 18:52:08 --> Database Driver Class Initialized
INFO - 2018-03-16 18:52:08 --> Config Class Initialized
INFO - 2018-03-16 18:52:08 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:52:08 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:52:08 --> Utf8 Class Initialized
INFO - 2018-03-16 18:52:08 --> URI Class Initialized
DEBUG - 2018-03-16 18:52:08 --> No URI present. Default controller set.
INFO - 2018-03-16 18:52:08 --> Router Class Initialized
INFO - 2018-03-16 18:52:08 --> Output Class Initialized
INFO - 2018-03-16 18:52:08 --> Security Class Initialized
DEBUG - 2018-03-16 18:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:52:08 --> Input Class Initialized
INFO - 2018-03-16 18:52:08 --> Language Class Initialized
INFO - 2018-03-16 18:52:08 --> Loader Class Initialized
INFO - 2018-03-16 18:52:08 --> Helper loaded: url_helper
INFO - 2018-03-16 18:52:08 --> Helper loaded: site_helper
INFO - 2018-03-16 18:52:08 --> Database Driver Class Initialized
INFO - 2018-03-16 18:52:09 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:52:09 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:52:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:52:09 --> Controller Class Initialized
INFO - 2018-03-16 18:52:09 --> User Agent Class Initialized
INFO - 2018-03-16 18:52:09 --> Model "site_model" initialized
INFO - 2018-03-16 18:52:09 --> Model "user_model" initialized
INFO - 2018-03-16 18:52:09 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:52:09 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:52:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:52:09 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:52:09 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:52:09 --> Final output sent to browser
DEBUG - 2018-03-16 18:52:09 --> Total execution time: 0.0675
INFO - 2018-03-16 18:52:11 --> Database Driver Class Initialized
INFO - 2018-03-16 18:52:11 --> Config Class Initialized
INFO - 2018-03-16 18:52:11 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:52:11 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:52:11 --> Utf8 Class Initialized
INFO - 2018-03-16 18:52:11 --> URI Class Initialized
DEBUG - 2018-03-16 18:52:11 --> No URI present. Default controller set.
INFO - 2018-03-16 18:52:11 --> Router Class Initialized
INFO - 2018-03-16 18:52:11 --> Output Class Initialized
INFO - 2018-03-16 18:52:11 --> Security Class Initialized
DEBUG - 2018-03-16 18:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:52:11 --> Input Class Initialized
INFO - 2018-03-16 18:52:11 --> Language Class Initialized
INFO - 2018-03-16 18:52:11 --> Loader Class Initialized
INFO - 2018-03-16 18:52:11 --> Helper loaded: url_helper
INFO - 2018-03-16 18:52:11 --> Helper loaded: site_helper
INFO - 2018-03-16 18:52:11 --> Database Driver Class Initialized
INFO - 2018-03-16 18:52:11 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:52:11 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:52:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:52:11 --> Controller Class Initialized
INFO - 2018-03-16 18:52:11 --> User Agent Class Initialized
INFO - 2018-03-16 18:52:11 --> Model "site_model" initialized
INFO - 2018-03-16 18:52:11 --> Model "user_model" initialized
INFO - 2018-03-16 18:52:11 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:52:11 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:52:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:52:11 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:52:11 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:52:11 --> Final output sent to browser
DEBUG - 2018-03-16 18:52:11 --> Total execution time: 0.0525
INFO - 2018-03-16 18:52:14 --> Database Driver Class Initialized
INFO - 2018-03-16 18:52:14 --> Config Class Initialized
INFO - 2018-03-16 18:52:14 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:52:14 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:52:14 --> Utf8 Class Initialized
INFO - 2018-03-16 18:52:14 --> URI Class Initialized
DEBUG - 2018-03-16 18:52:14 --> No URI present. Default controller set.
INFO - 2018-03-16 18:52:14 --> Router Class Initialized
INFO - 2018-03-16 18:52:14 --> Output Class Initialized
INFO - 2018-03-16 18:52:14 --> Security Class Initialized
DEBUG - 2018-03-16 18:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:52:14 --> Input Class Initialized
INFO - 2018-03-16 18:52:14 --> Language Class Initialized
INFO - 2018-03-16 18:52:14 --> Loader Class Initialized
INFO - 2018-03-16 18:52:14 --> Helper loaded: url_helper
INFO - 2018-03-16 18:52:14 --> Helper loaded: site_helper
INFO - 2018-03-16 18:52:14 --> Database Driver Class Initialized
INFO - 2018-03-16 18:52:14 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:52:14 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:52:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:52:14 --> Controller Class Initialized
INFO - 2018-03-16 18:52:14 --> User Agent Class Initialized
INFO - 2018-03-16 18:52:14 --> Model "site_model" initialized
INFO - 2018-03-16 18:52:14 --> Model "user_model" initialized
INFO - 2018-03-16 18:52:14 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:52:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:52:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:52:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:52:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:52:14 --> Final output sent to browser
DEBUG - 2018-03-16 18:52:14 --> Total execution time: 0.0475
INFO - 2018-03-16 18:52:28 --> Database Driver Class Initialized
INFO - 2018-03-16 18:52:28 --> Config Class Initialized
INFO - 2018-03-16 18:52:28 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:52:28 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:52:28 --> Utf8 Class Initialized
INFO - 2018-03-16 18:52:28 --> URI Class Initialized
DEBUG - 2018-03-16 18:52:28 --> No URI present. Default controller set.
INFO - 2018-03-16 18:52:28 --> Router Class Initialized
INFO - 2018-03-16 18:52:28 --> Output Class Initialized
INFO - 2018-03-16 18:52:28 --> Security Class Initialized
DEBUG - 2018-03-16 18:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:52:28 --> Input Class Initialized
INFO - 2018-03-16 18:52:28 --> Language Class Initialized
INFO - 2018-03-16 18:52:28 --> Loader Class Initialized
INFO - 2018-03-16 18:52:28 --> Helper loaded: url_helper
INFO - 2018-03-16 18:52:28 --> Helper loaded: site_helper
INFO - 2018-03-16 18:52:28 --> Database Driver Class Initialized
INFO - 2018-03-16 18:52:28 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:52:28 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:52:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:52:28 --> Controller Class Initialized
INFO - 2018-03-16 18:52:28 --> User Agent Class Initialized
INFO - 2018-03-16 18:52:28 --> Model "site_model" initialized
INFO - 2018-03-16 18:52:28 --> Model "user_model" initialized
INFO - 2018-03-16 18:52:28 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:52:28 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:52:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:52:28 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:52:28 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:52:28 --> Final output sent to browser
DEBUG - 2018-03-16 18:52:28 --> Total execution time: 0.0600
INFO - 2018-03-16 18:52:32 --> Database Driver Class Initialized
INFO - 2018-03-16 18:52:32 --> Config Class Initialized
INFO - 2018-03-16 18:52:32 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:52:32 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:52:32 --> Utf8 Class Initialized
INFO - 2018-03-16 18:52:32 --> URI Class Initialized
DEBUG - 2018-03-16 18:52:32 --> No URI present. Default controller set.
INFO - 2018-03-16 18:52:32 --> Router Class Initialized
INFO - 2018-03-16 18:52:32 --> Output Class Initialized
INFO - 2018-03-16 18:52:32 --> Security Class Initialized
DEBUG - 2018-03-16 18:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:52:32 --> Input Class Initialized
INFO - 2018-03-16 18:52:32 --> Language Class Initialized
INFO - 2018-03-16 18:52:32 --> Loader Class Initialized
INFO - 2018-03-16 18:52:32 --> Helper loaded: url_helper
INFO - 2018-03-16 18:52:32 --> Helper loaded: site_helper
INFO - 2018-03-16 18:52:32 --> Database Driver Class Initialized
INFO - 2018-03-16 18:52:32 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:52:32 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:52:32 --> Controller Class Initialized
INFO - 2018-03-16 18:52:32 --> User Agent Class Initialized
INFO - 2018-03-16 18:52:32 --> Model "site_model" initialized
INFO - 2018-03-16 18:52:32 --> Model "user_model" initialized
INFO - 2018-03-16 18:52:32 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:52:32 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:52:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:52:32 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:52:32 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:52:32 --> Final output sent to browser
DEBUG - 2018-03-16 18:52:32 --> Total execution time: 0.0575
INFO - 2018-03-16 18:52:57 --> Database Driver Class Initialized
INFO - 2018-03-16 18:52:57 --> Config Class Initialized
INFO - 2018-03-16 18:52:57 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:52:57 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:52:57 --> Utf8 Class Initialized
INFO - 2018-03-16 18:52:57 --> URI Class Initialized
DEBUG - 2018-03-16 18:52:57 --> No URI present. Default controller set.
INFO - 2018-03-16 18:52:57 --> Router Class Initialized
INFO - 2018-03-16 18:52:57 --> Output Class Initialized
INFO - 2018-03-16 18:52:57 --> Security Class Initialized
DEBUG - 2018-03-16 18:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:52:57 --> Input Class Initialized
INFO - 2018-03-16 18:52:57 --> Language Class Initialized
INFO - 2018-03-16 18:52:57 --> Loader Class Initialized
INFO - 2018-03-16 18:52:57 --> Helper loaded: url_helper
INFO - 2018-03-16 18:52:57 --> Helper loaded: site_helper
INFO - 2018-03-16 18:52:57 --> Database Driver Class Initialized
INFO - 2018-03-16 18:52:57 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:52:57 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:52:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:52:57 --> Controller Class Initialized
INFO - 2018-03-16 18:52:57 --> User Agent Class Initialized
INFO - 2018-03-16 18:52:57 --> Model "site_model" initialized
INFO - 2018-03-16 18:52:57 --> Model "user_model" initialized
INFO - 2018-03-16 18:52:57 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:52:57 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:52:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:52:57 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:52:57 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:52:57 --> Final output sent to browser
DEBUG - 2018-03-16 18:52:57 --> Total execution time: 0.0525
INFO - 2018-03-16 18:53:24 --> Database Driver Class Initialized
INFO - 2018-03-16 18:53:24 --> Config Class Initialized
INFO - 2018-03-16 18:53:24 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:53:24 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:53:24 --> Utf8 Class Initialized
INFO - 2018-03-16 18:53:24 --> URI Class Initialized
DEBUG - 2018-03-16 18:53:24 --> No URI present. Default controller set.
INFO - 2018-03-16 18:53:24 --> Router Class Initialized
INFO - 2018-03-16 18:53:24 --> Output Class Initialized
INFO - 2018-03-16 18:53:25 --> Security Class Initialized
DEBUG - 2018-03-16 18:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:53:25 --> Input Class Initialized
INFO - 2018-03-16 18:53:25 --> Language Class Initialized
INFO - 2018-03-16 18:53:25 --> Loader Class Initialized
INFO - 2018-03-16 18:53:25 --> Helper loaded: url_helper
INFO - 2018-03-16 18:53:25 --> Helper loaded: site_helper
INFO - 2018-03-16 18:53:25 --> Database Driver Class Initialized
INFO - 2018-03-16 18:53:25 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:53:25 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:53:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:53:25 --> Controller Class Initialized
INFO - 2018-03-16 18:53:25 --> User Agent Class Initialized
INFO - 2018-03-16 18:53:25 --> Model "site_model" initialized
INFO - 2018-03-16 18:53:25 --> Model "user_model" initialized
INFO - 2018-03-16 18:53:25 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:53:25 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:53:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:53:25 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:53:25 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:53:25 --> Final output sent to browser
DEBUG - 2018-03-16 18:53:25 --> Total execution time: 0.0500
INFO - 2018-03-16 18:53:40 --> Database Driver Class Initialized
INFO - 2018-03-16 18:53:40 --> Config Class Initialized
INFO - 2018-03-16 18:53:40 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:53:40 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:53:40 --> Utf8 Class Initialized
INFO - 2018-03-16 18:53:40 --> URI Class Initialized
DEBUG - 2018-03-16 18:53:40 --> No URI present. Default controller set.
INFO - 2018-03-16 18:53:40 --> Router Class Initialized
INFO - 2018-03-16 18:53:40 --> Output Class Initialized
INFO - 2018-03-16 18:53:40 --> Security Class Initialized
DEBUG - 2018-03-16 18:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:53:40 --> Input Class Initialized
INFO - 2018-03-16 18:53:40 --> Language Class Initialized
INFO - 2018-03-16 18:53:40 --> Loader Class Initialized
INFO - 2018-03-16 18:53:40 --> Helper loaded: url_helper
INFO - 2018-03-16 18:53:40 --> Helper loaded: site_helper
INFO - 2018-03-16 18:53:40 --> Database Driver Class Initialized
INFO - 2018-03-16 18:53:40 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:53:40 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:53:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:53:40 --> Controller Class Initialized
INFO - 2018-03-16 18:53:40 --> User Agent Class Initialized
INFO - 2018-03-16 18:53:40 --> Model "site_model" initialized
INFO - 2018-03-16 18:53:40 --> Model "user_model" initialized
INFO - 2018-03-16 18:53:40 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:53:40 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:53:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:53:40 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:53:40 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:53:40 --> Final output sent to browser
DEBUG - 2018-03-16 18:53:40 --> Total execution time: 0.0550
INFO - 2018-03-16 18:54:17 --> Database Driver Class Initialized
INFO - 2018-03-16 18:54:17 --> Config Class Initialized
INFO - 2018-03-16 18:54:17 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:54:17 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:54:17 --> Utf8 Class Initialized
INFO - 2018-03-16 18:54:17 --> URI Class Initialized
DEBUG - 2018-03-16 18:54:17 --> No URI present. Default controller set.
INFO - 2018-03-16 18:54:17 --> Router Class Initialized
INFO - 2018-03-16 18:54:17 --> Output Class Initialized
INFO - 2018-03-16 18:54:17 --> Security Class Initialized
DEBUG - 2018-03-16 18:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:54:17 --> Input Class Initialized
INFO - 2018-03-16 18:54:17 --> Language Class Initialized
INFO - 2018-03-16 18:54:17 --> Loader Class Initialized
INFO - 2018-03-16 18:54:17 --> Helper loaded: url_helper
INFO - 2018-03-16 18:54:17 --> Helper loaded: site_helper
INFO - 2018-03-16 18:54:17 --> Database Driver Class Initialized
INFO - 2018-03-16 18:54:17 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:54:17 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:54:17 --> Controller Class Initialized
INFO - 2018-03-16 18:54:17 --> User Agent Class Initialized
INFO - 2018-03-16 18:54:17 --> Model "site_model" initialized
INFO - 2018-03-16 18:54:17 --> Model "user_model" initialized
INFO - 2018-03-16 18:54:17 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:54:17 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:54:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:54:17 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:54:17 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:54:17 --> Final output sent to browser
DEBUG - 2018-03-16 18:54:17 --> Total execution time: 0.0575
INFO - 2018-03-16 18:54:30 --> Database Driver Class Initialized
INFO - 2018-03-16 18:54:30 --> Config Class Initialized
INFO - 2018-03-16 18:54:30 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:54:30 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:54:30 --> Utf8 Class Initialized
INFO - 2018-03-16 18:54:30 --> URI Class Initialized
DEBUG - 2018-03-16 18:54:30 --> No URI present. Default controller set.
INFO - 2018-03-16 18:54:30 --> Router Class Initialized
INFO - 2018-03-16 18:54:30 --> Output Class Initialized
INFO - 2018-03-16 18:54:30 --> Security Class Initialized
DEBUG - 2018-03-16 18:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:54:30 --> Input Class Initialized
INFO - 2018-03-16 18:54:30 --> Language Class Initialized
INFO - 2018-03-16 18:54:30 --> Loader Class Initialized
INFO - 2018-03-16 18:54:30 --> Helper loaded: url_helper
INFO - 2018-03-16 18:54:30 --> Helper loaded: site_helper
INFO - 2018-03-16 18:54:30 --> Database Driver Class Initialized
INFO - 2018-03-16 18:54:30 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:54:30 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:54:30 --> Controller Class Initialized
INFO - 2018-03-16 18:54:30 --> User Agent Class Initialized
INFO - 2018-03-16 18:54:30 --> Model "site_model" initialized
INFO - 2018-03-16 18:54:30 --> Model "user_model" initialized
INFO - 2018-03-16 18:54:30 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:54:30 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:54:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:54:30 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:54:30 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:54:30 --> Final output sent to browser
DEBUG - 2018-03-16 18:54:30 --> Total execution time: 0.0735
INFO - 2018-03-16 18:54:37 --> Database Driver Class Initialized
INFO - 2018-03-16 18:54:37 --> Config Class Initialized
INFO - 2018-03-16 18:54:37 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:54:37 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:54:37 --> Utf8 Class Initialized
INFO - 2018-03-16 18:54:37 --> URI Class Initialized
DEBUG - 2018-03-16 18:54:37 --> No URI present. Default controller set.
INFO - 2018-03-16 18:54:37 --> Router Class Initialized
INFO - 2018-03-16 18:54:37 --> Output Class Initialized
INFO - 2018-03-16 18:54:37 --> Security Class Initialized
DEBUG - 2018-03-16 18:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:54:37 --> Input Class Initialized
INFO - 2018-03-16 18:54:37 --> Language Class Initialized
INFO - 2018-03-16 18:54:37 --> Loader Class Initialized
INFO - 2018-03-16 18:54:37 --> Helper loaded: url_helper
INFO - 2018-03-16 18:54:37 --> Helper loaded: site_helper
INFO - 2018-03-16 18:54:37 --> Database Driver Class Initialized
INFO - 2018-03-16 18:54:37 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:54:37 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:54:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:54:37 --> Controller Class Initialized
INFO - 2018-03-16 18:54:37 --> User Agent Class Initialized
INFO - 2018-03-16 18:54:37 --> Model "site_model" initialized
INFO - 2018-03-16 18:54:37 --> Model "user_model" initialized
INFO - 2018-03-16 18:54:37 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:54:37 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:54:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:54:37 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:54:37 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:54:37 --> Final output sent to browser
DEBUG - 2018-03-16 18:54:37 --> Total execution time: 0.0600
INFO - 2018-03-16 18:56:00 --> Database Driver Class Initialized
INFO - 2018-03-16 18:56:00 --> Config Class Initialized
INFO - 2018-03-16 18:56:00 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:56:00 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:56:00 --> Utf8 Class Initialized
INFO - 2018-03-16 18:56:00 --> URI Class Initialized
DEBUG - 2018-03-16 18:56:00 --> No URI present. Default controller set.
INFO - 2018-03-16 18:56:00 --> Router Class Initialized
INFO - 2018-03-16 18:56:00 --> Output Class Initialized
INFO - 2018-03-16 18:56:00 --> Security Class Initialized
DEBUG - 2018-03-16 18:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:56:00 --> Input Class Initialized
INFO - 2018-03-16 18:56:00 --> Language Class Initialized
INFO - 2018-03-16 18:56:00 --> Loader Class Initialized
INFO - 2018-03-16 18:56:00 --> Helper loaded: url_helper
INFO - 2018-03-16 18:56:00 --> Helper loaded: site_helper
INFO - 2018-03-16 18:56:00 --> Database Driver Class Initialized
INFO - 2018-03-16 18:56:00 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:56:00 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:56:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:56:00 --> Controller Class Initialized
INFO - 2018-03-16 18:56:00 --> User Agent Class Initialized
INFO - 2018-03-16 18:56:00 --> Model "site_model" initialized
INFO - 2018-03-16 18:56:00 --> Model "user_model" initialized
INFO - 2018-03-16 18:56:00 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:56:00 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:56:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:56:00 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:56:00 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:56:00 --> Final output sent to browser
DEBUG - 2018-03-16 18:56:00 --> Total execution time: 0.0550
INFO - 2018-03-16 18:56:05 --> Database Driver Class Initialized
INFO - 2018-03-16 18:56:05 --> Config Class Initialized
INFO - 2018-03-16 18:56:05 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:56:05 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:56:05 --> Utf8 Class Initialized
INFO - 2018-03-16 18:56:05 --> URI Class Initialized
DEBUG - 2018-03-16 18:56:05 --> No URI present. Default controller set.
INFO - 2018-03-16 18:56:05 --> Router Class Initialized
INFO - 2018-03-16 18:56:05 --> Output Class Initialized
INFO - 2018-03-16 18:56:05 --> Security Class Initialized
DEBUG - 2018-03-16 18:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:56:05 --> Input Class Initialized
INFO - 2018-03-16 18:56:05 --> Language Class Initialized
INFO - 2018-03-16 18:56:05 --> Loader Class Initialized
INFO - 2018-03-16 18:56:05 --> Helper loaded: url_helper
INFO - 2018-03-16 18:56:05 --> Helper loaded: site_helper
INFO - 2018-03-16 18:56:05 --> Database Driver Class Initialized
INFO - 2018-03-16 18:56:05 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:56:05 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:56:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:56:05 --> Controller Class Initialized
INFO - 2018-03-16 18:56:05 --> User Agent Class Initialized
INFO - 2018-03-16 18:56:05 --> Model "site_model" initialized
INFO - 2018-03-16 18:56:05 --> Model "user_model" initialized
INFO - 2018-03-16 18:56:05 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:56:05 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:56:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:56:05 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:56:05 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:56:05 --> Final output sent to browser
DEBUG - 2018-03-16 18:56:05 --> Total execution time: 0.0525
INFO - 2018-03-16 18:58:14 --> Database Driver Class Initialized
INFO - 2018-03-16 18:58:14 --> Config Class Initialized
INFO - 2018-03-16 18:58:14 --> Hooks Class Initialized
DEBUG - 2018-03-16 18:58:14 --> UTF-8 Support Enabled
INFO - 2018-03-16 18:58:14 --> Utf8 Class Initialized
INFO - 2018-03-16 18:58:14 --> URI Class Initialized
DEBUG - 2018-03-16 18:58:14 --> No URI present. Default controller set.
INFO - 2018-03-16 18:58:14 --> Router Class Initialized
INFO - 2018-03-16 18:58:14 --> Output Class Initialized
INFO - 2018-03-16 18:58:14 --> Security Class Initialized
DEBUG - 2018-03-16 18:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 18:58:14 --> Input Class Initialized
INFO - 2018-03-16 18:58:14 --> Language Class Initialized
INFO - 2018-03-16 18:58:14 --> Loader Class Initialized
INFO - 2018-03-16 18:58:14 --> Helper loaded: url_helper
INFO - 2018-03-16 18:58:14 --> Helper loaded: site_helper
INFO - 2018-03-16 18:58:14 --> Database Driver Class Initialized
INFO - 2018-03-16 18:58:14 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 18:58:14 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 18:58:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 18:58:14 --> Controller Class Initialized
INFO - 2018-03-16 18:58:14 --> User Agent Class Initialized
INFO - 2018-03-16 18:58:14 --> Model "site_model" initialized
INFO - 2018-03-16 18:58:14 --> Model "user_model" initialized
INFO - 2018-03-16 18:58:14 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 18:58:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 18:58:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 18:58:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 18:58:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 18:58:14 --> Final output sent to browser
DEBUG - 2018-03-16 18:58:14 --> Total execution time: 0.0500
INFO - 2018-03-16 19:04:50 --> Database Driver Class Initialized
INFO - 2018-03-16 19:04:50 --> Config Class Initialized
INFO - 2018-03-16 19:04:50 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:04:50 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:04:50 --> Utf8 Class Initialized
INFO - 2018-03-16 19:04:50 --> URI Class Initialized
DEBUG - 2018-03-16 19:04:50 --> No URI present. Default controller set.
INFO - 2018-03-16 19:04:50 --> Router Class Initialized
INFO - 2018-03-16 19:04:50 --> Output Class Initialized
INFO - 2018-03-16 19:04:50 --> Security Class Initialized
DEBUG - 2018-03-16 19:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:04:50 --> Input Class Initialized
INFO - 2018-03-16 19:04:50 --> Language Class Initialized
INFO - 2018-03-16 19:04:50 --> Loader Class Initialized
INFO - 2018-03-16 19:04:50 --> Helper loaded: url_helper
INFO - 2018-03-16 19:04:50 --> Helper loaded: site_helper
INFO - 2018-03-16 19:04:50 --> Database Driver Class Initialized
INFO - 2018-03-16 19:04:50 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:04:50 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:04:50 --> Controller Class Initialized
INFO - 2018-03-16 19:04:50 --> User Agent Class Initialized
INFO - 2018-03-16 19:04:50 --> Model "site_model" initialized
INFO - 2018-03-16 19:04:50 --> Model "user_model" initialized
INFO - 2018-03-16 19:04:50 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:04:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:04:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:04:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:04:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:04:50 --> Final output sent to browser
DEBUG - 2018-03-16 19:04:50 --> Total execution time: 0.0625
INFO - 2018-03-16 19:04:52 --> Database Driver Class Initialized
INFO - 2018-03-16 19:04:52 --> Config Class Initialized
INFO - 2018-03-16 19:04:52 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:04:52 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:04:52 --> Utf8 Class Initialized
INFO - 2018-03-16 19:04:52 --> URI Class Initialized
INFO - 2018-03-16 19:04:52 --> Router Class Initialized
INFO - 2018-03-16 19:04:52 --> Output Class Initialized
INFO - 2018-03-16 19:04:52 --> Security Class Initialized
DEBUG - 2018-03-16 19:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:04:52 --> Input Class Initialized
INFO - 2018-03-16 19:04:52 --> Language Class Initialized
INFO - 2018-03-16 19:04:52 --> Loader Class Initialized
INFO - 2018-03-16 19:04:52 --> Helper loaded: url_helper
INFO - 2018-03-16 19:04:52 --> Helper loaded: site_helper
INFO - 2018-03-16 19:04:52 --> Database Driver Class Initialized
INFO - 2018-03-16 19:04:52 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:04:52 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:04:52 --> Controller Class Initialized
INFO - 2018-03-16 19:04:52 --> Model "user_model" initialized
INFO - 2018-03-16 19:04:52 --> Model "site_model" initialized
INFO - 2018-03-16 19:04:52 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:04:52 --> Final output sent to browser
DEBUG - 2018-03-16 19:04:52 --> Total execution time: 0.0975
INFO - 2018-03-16 19:05:04 --> Database Driver Class Initialized
INFO - 2018-03-16 19:05:04 --> Config Class Initialized
INFO - 2018-03-16 19:05:04 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:05:04 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:05:04 --> Utf8 Class Initialized
INFO - 2018-03-16 19:05:04 --> URI Class Initialized
DEBUG - 2018-03-16 19:05:04 --> No URI present. Default controller set.
INFO - 2018-03-16 19:05:04 --> Router Class Initialized
INFO - 2018-03-16 19:05:04 --> Output Class Initialized
INFO - 2018-03-16 19:05:04 --> Security Class Initialized
DEBUG - 2018-03-16 19:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:05:04 --> Input Class Initialized
INFO - 2018-03-16 19:05:04 --> Language Class Initialized
INFO - 2018-03-16 19:05:04 --> Loader Class Initialized
INFO - 2018-03-16 19:05:04 --> Helper loaded: url_helper
INFO - 2018-03-16 19:05:04 --> Helper loaded: site_helper
INFO - 2018-03-16 19:05:04 --> Database Driver Class Initialized
INFO - 2018-03-16 19:05:04 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:05:04 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:05:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:05:04 --> Controller Class Initialized
INFO - 2018-03-16 19:05:04 --> User Agent Class Initialized
INFO - 2018-03-16 19:05:04 --> Model "site_model" initialized
INFO - 2018-03-16 19:05:04 --> Model "user_model" initialized
INFO - 2018-03-16 19:05:04 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:05:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:05:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:05:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:05:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:05:04 --> Final output sent to browser
DEBUG - 2018-03-16 19:05:04 --> Total execution time: 0.0700
INFO - 2018-03-16 19:05:17 --> Database Driver Class Initialized
INFO - 2018-03-16 19:05:17 --> Config Class Initialized
INFO - 2018-03-16 19:05:17 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:05:17 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:05:17 --> Utf8 Class Initialized
INFO - 2018-03-16 19:05:17 --> URI Class Initialized
DEBUG - 2018-03-16 19:05:17 --> No URI present. Default controller set.
INFO - 2018-03-16 19:05:17 --> Router Class Initialized
INFO - 2018-03-16 19:05:17 --> Output Class Initialized
INFO - 2018-03-16 19:05:17 --> Security Class Initialized
DEBUG - 2018-03-16 19:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:05:17 --> Input Class Initialized
INFO - 2018-03-16 19:05:17 --> Language Class Initialized
INFO - 2018-03-16 19:05:17 --> Loader Class Initialized
INFO - 2018-03-16 19:05:17 --> Helper loaded: url_helper
INFO - 2018-03-16 19:05:17 --> Helper loaded: site_helper
INFO - 2018-03-16 19:05:17 --> Database Driver Class Initialized
INFO - 2018-03-16 19:05:17 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:05:17 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:05:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:05:17 --> Controller Class Initialized
INFO - 2018-03-16 19:05:17 --> User Agent Class Initialized
INFO - 2018-03-16 19:05:17 --> Model "site_model" initialized
INFO - 2018-03-16 19:05:17 --> Model "user_model" initialized
INFO - 2018-03-16 19:05:17 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:05:17 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:05:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:05:17 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:05:17 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:05:17 --> Final output sent to browser
DEBUG - 2018-03-16 19:05:17 --> Total execution time: 0.0400
INFO - 2018-03-16 19:05:19 --> Database Driver Class Initialized
INFO - 2018-03-16 19:05:19 --> Config Class Initialized
INFO - 2018-03-16 19:05:19 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:05:19 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:05:19 --> Utf8 Class Initialized
INFO - 2018-03-16 19:05:19 --> URI Class Initialized
DEBUG - 2018-03-16 19:05:19 --> No URI present. Default controller set.
INFO - 2018-03-16 19:05:19 --> Router Class Initialized
INFO - 2018-03-16 19:05:19 --> Output Class Initialized
INFO - 2018-03-16 19:05:19 --> Security Class Initialized
DEBUG - 2018-03-16 19:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:05:19 --> Input Class Initialized
INFO - 2018-03-16 19:05:19 --> Language Class Initialized
INFO - 2018-03-16 19:05:19 --> Loader Class Initialized
INFO - 2018-03-16 19:05:19 --> Helper loaded: url_helper
INFO - 2018-03-16 19:05:19 --> Helper loaded: site_helper
INFO - 2018-03-16 19:05:19 --> Database Driver Class Initialized
INFO - 2018-03-16 19:05:19 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:05:19 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:05:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:05:19 --> Controller Class Initialized
INFO - 2018-03-16 19:05:19 --> User Agent Class Initialized
INFO - 2018-03-16 19:05:19 --> Model "site_model" initialized
INFO - 2018-03-16 19:05:19 --> Model "user_model" initialized
INFO - 2018-03-16 19:05:19 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:05:19 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:05:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:05:19 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:05:19 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:05:19 --> Final output sent to browser
DEBUG - 2018-03-16 19:05:19 --> Total execution time: 0.0725
INFO - 2018-03-16 19:05:25 --> Database Driver Class Initialized
INFO - 2018-03-16 19:05:25 --> Config Class Initialized
INFO - 2018-03-16 19:05:25 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:05:25 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:05:25 --> Utf8 Class Initialized
INFO - 2018-03-16 19:05:25 --> URI Class Initialized
DEBUG - 2018-03-16 19:05:25 --> No URI present. Default controller set.
INFO - 2018-03-16 19:05:25 --> Router Class Initialized
INFO - 2018-03-16 19:05:25 --> Output Class Initialized
INFO - 2018-03-16 19:05:25 --> Security Class Initialized
DEBUG - 2018-03-16 19:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:05:25 --> Input Class Initialized
INFO - 2018-03-16 19:05:25 --> Language Class Initialized
INFO - 2018-03-16 19:05:25 --> Loader Class Initialized
INFO - 2018-03-16 19:05:25 --> Helper loaded: url_helper
INFO - 2018-03-16 19:05:25 --> Helper loaded: site_helper
INFO - 2018-03-16 19:05:25 --> Database Driver Class Initialized
INFO - 2018-03-16 19:05:25 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:05:25 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:05:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:05:25 --> Controller Class Initialized
INFO - 2018-03-16 19:05:25 --> User Agent Class Initialized
INFO - 2018-03-16 19:05:25 --> Model "site_model" initialized
INFO - 2018-03-16 19:05:25 --> Model "user_model" initialized
INFO - 2018-03-16 19:05:25 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:05:25 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:05:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:05:25 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:05:25 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:05:25 --> Final output sent to browser
DEBUG - 2018-03-16 19:05:25 --> Total execution time: 0.0500
INFO - 2018-03-16 19:05:28 --> Database Driver Class Initialized
INFO - 2018-03-16 19:05:28 --> Config Class Initialized
INFO - 2018-03-16 19:05:28 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:05:28 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:05:28 --> Utf8 Class Initialized
INFO - 2018-03-16 19:05:28 --> URI Class Initialized
DEBUG - 2018-03-16 19:05:28 --> No URI present. Default controller set.
INFO - 2018-03-16 19:05:28 --> Router Class Initialized
INFO - 2018-03-16 19:05:28 --> Output Class Initialized
INFO - 2018-03-16 19:05:28 --> Security Class Initialized
DEBUG - 2018-03-16 19:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:05:28 --> Input Class Initialized
INFO - 2018-03-16 19:05:28 --> Language Class Initialized
INFO - 2018-03-16 19:05:28 --> Loader Class Initialized
INFO - 2018-03-16 19:05:28 --> Helper loaded: url_helper
INFO - 2018-03-16 19:05:28 --> Helper loaded: site_helper
INFO - 2018-03-16 19:05:28 --> Database Driver Class Initialized
INFO - 2018-03-16 19:05:28 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:05:28 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:05:28 --> Controller Class Initialized
INFO - 2018-03-16 19:05:28 --> User Agent Class Initialized
INFO - 2018-03-16 19:05:28 --> Model "site_model" initialized
INFO - 2018-03-16 19:05:28 --> Model "user_model" initialized
INFO - 2018-03-16 19:05:28 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:05:28 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:05:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:05:28 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:05:28 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:05:28 --> Final output sent to browser
DEBUG - 2018-03-16 19:05:28 --> Total execution time: 0.0775
INFO - 2018-03-16 19:05:31 --> Database Driver Class Initialized
INFO - 2018-03-16 19:05:31 --> Config Class Initialized
INFO - 2018-03-16 19:05:31 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:05:31 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:05:31 --> Utf8 Class Initialized
INFO - 2018-03-16 19:05:31 --> URI Class Initialized
INFO - 2018-03-16 19:05:31 --> Router Class Initialized
INFO - 2018-03-16 19:05:31 --> Output Class Initialized
INFO - 2018-03-16 19:05:31 --> Security Class Initialized
DEBUG - 2018-03-16 19:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:05:31 --> Input Class Initialized
INFO - 2018-03-16 19:05:31 --> Language Class Initialized
INFO - 2018-03-16 19:05:31 --> Loader Class Initialized
INFO - 2018-03-16 19:05:31 --> Helper loaded: url_helper
INFO - 2018-03-16 19:05:31 --> Helper loaded: site_helper
INFO - 2018-03-16 19:05:31 --> Database Driver Class Initialized
INFO - 2018-03-16 19:05:31 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:05:31 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:05:31 --> Controller Class Initialized
INFO - 2018-03-16 19:05:31 --> Model "user_model" initialized
INFO - 2018-03-16 19:05:31 --> Model "site_model" initialized
INFO - 2018-03-16 19:05:31 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:05:31 --> Final output sent to browser
DEBUG - 2018-03-16 19:05:31 --> Total execution time: 0.0630
INFO - 2018-03-16 19:05:33 --> Database Driver Class Initialized
INFO - 2018-03-16 19:05:33 --> Config Class Initialized
INFO - 2018-03-16 19:05:33 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:05:33 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:05:33 --> Utf8 Class Initialized
INFO - 2018-03-16 19:05:33 --> URI Class Initialized
INFO - 2018-03-16 19:05:33 --> Router Class Initialized
INFO - 2018-03-16 19:05:33 --> Output Class Initialized
INFO - 2018-03-16 19:05:33 --> Security Class Initialized
DEBUG - 2018-03-16 19:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:05:33 --> Input Class Initialized
INFO - 2018-03-16 19:05:33 --> Language Class Initialized
INFO - 2018-03-16 19:05:33 --> Loader Class Initialized
INFO - 2018-03-16 19:05:33 --> Helper loaded: url_helper
INFO - 2018-03-16 19:05:33 --> Helper loaded: site_helper
INFO - 2018-03-16 19:05:33 --> Database Driver Class Initialized
INFO - 2018-03-16 19:05:33 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:05:33 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:05:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:05:33 --> Controller Class Initialized
INFO - 2018-03-16 19:05:33 --> Final output sent to browser
DEBUG - 2018-03-16 19:05:33 --> Total execution time: 0.1675
INFO - 2018-03-16 19:05:39 --> Database Driver Class Initialized
INFO - 2018-03-16 19:05:39 --> Config Class Initialized
INFO - 2018-03-16 19:05:39 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:05:39 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:05:39 --> Utf8 Class Initialized
INFO - 2018-03-16 19:05:39 --> URI Class Initialized
DEBUG - 2018-03-16 19:05:39 --> No URI present. Default controller set.
INFO - 2018-03-16 19:05:39 --> Router Class Initialized
INFO - 2018-03-16 19:05:39 --> Output Class Initialized
INFO - 2018-03-16 19:05:39 --> Security Class Initialized
DEBUG - 2018-03-16 19:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:05:39 --> Input Class Initialized
INFO - 2018-03-16 19:05:39 --> Language Class Initialized
INFO - 2018-03-16 19:05:39 --> Loader Class Initialized
INFO - 2018-03-16 19:05:39 --> Helper loaded: url_helper
INFO - 2018-03-16 19:05:39 --> Helper loaded: site_helper
INFO - 2018-03-16 19:05:39 --> Database Driver Class Initialized
INFO - 2018-03-16 19:05:39 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:05:39 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:05:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:05:39 --> Controller Class Initialized
INFO - 2018-03-16 19:05:39 --> User Agent Class Initialized
INFO - 2018-03-16 19:05:39 --> Model "site_model" initialized
INFO - 2018-03-16 19:05:39 --> Model "user_model" initialized
INFO - 2018-03-16 19:05:39 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:05:39 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:05:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:05:39 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:05:39 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:05:39 --> Final output sent to browser
DEBUG - 2018-03-16 19:05:39 --> Total execution time: 0.0740
INFO - 2018-03-16 19:05:43 --> Database Driver Class Initialized
INFO - 2018-03-16 19:05:43 --> Config Class Initialized
INFO - 2018-03-16 19:05:43 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:05:43 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:05:43 --> Utf8 Class Initialized
INFO - 2018-03-16 19:05:43 --> URI Class Initialized
DEBUG - 2018-03-16 19:05:43 --> No URI present. Default controller set.
INFO - 2018-03-16 19:05:43 --> Router Class Initialized
INFO - 2018-03-16 19:05:43 --> Output Class Initialized
INFO - 2018-03-16 19:05:43 --> Security Class Initialized
DEBUG - 2018-03-16 19:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:05:43 --> Input Class Initialized
INFO - 2018-03-16 19:05:43 --> Language Class Initialized
INFO - 2018-03-16 19:05:43 --> Loader Class Initialized
INFO - 2018-03-16 19:05:43 --> Helper loaded: url_helper
INFO - 2018-03-16 19:05:43 --> Helper loaded: site_helper
INFO - 2018-03-16 19:05:43 --> Database Driver Class Initialized
INFO - 2018-03-16 19:05:43 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:05:43 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:05:43 --> Controller Class Initialized
INFO - 2018-03-16 19:05:43 --> User Agent Class Initialized
INFO - 2018-03-16 19:05:43 --> Model "site_model" initialized
INFO - 2018-03-16 19:05:43 --> Model "user_model" initialized
INFO - 2018-03-16 19:05:43 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:05:43 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:05:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:05:43 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:05:43 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:05:43 --> Final output sent to browser
DEBUG - 2018-03-16 19:05:43 --> Total execution time: 0.1020
INFO - 2018-03-16 19:07:47 --> Database Driver Class Initialized
INFO - 2018-03-16 19:07:47 --> Config Class Initialized
INFO - 2018-03-16 19:07:47 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:07:47 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:07:47 --> Utf8 Class Initialized
INFO - 2018-03-16 19:07:47 --> URI Class Initialized
DEBUG - 2018-03-16 19:07:47 --> No URI present. Default controller set.
INFO - 2018-03-16 19:07:47 --> Router Class Initialized
INFO - 2018-03-16 19:07:47 --> Output Class Initialized
INFO - 2018-03-16 19:07:47 --> Security Class Initialized
DEBUG - 2018-03-16 19:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:07:47 --> Input Class Initialized
INFO - 2018-03-16 19:07:47 --> Language Class Initialized
INFO - 2018-03-16 19:07:47 --> Loader Class Initialized
INFO - 2018-03-16 19:07:47 --> Helper loaded: url_helper
INFO - 2018-03-16 19:07:47 --> Helper loaded: site_helper
INFO - 2018-03-16 19:07:47 --> Database Driver Class Initialized
INFO - 2018-03-16 19:07:47 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:07:47 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:07:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:07:47 --> Controller Class Initialized
INFO - 2018-03-16 19:07:47 --> User Agent Class Initialized
INFO - 2018-03-16 19:07:47 --> Model "site_model" initialized
INFO - 2018-03-16 19:07:47 --> Model "user_model" initialized
INFO - 2018-03-16 19:07:47 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:07:47 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:07:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:07:47 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:07:47 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:07:47 --> Final output sent to browser
DEBUG - 2018-03-16 19:07:47 --> Total execution time: 0.0500
INFO - 2018-03-16 19:08:06 --> Database Driver Class Initialized
INFO - 2018-03-16 19:08:06 --> Config Class Initialized
INFO - 2018-03-16 19:08:06 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:08:06 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:08:06 --> Utf8 Class Initialized
INFO - 2018-03-16 19:08:06 --> URI Class Initialized
DEBUG - 2018-03-16 19:08:06 --> No URI present. Default controller set.
INFO - 2018-03-16 19:08:06 --> Router Class Initialized
INFO - 2018-03-16 19:08:06 --> Output Class Initialized
INFO - 2018-03-16 19:08:06 --> Security Class Initialized
DEBUG - 2018-03-16 19:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:08:06 --> Input Class Initialized
INFO - 2018-03-16 19:08:06 --> Language Class Initialized
INFO - 2018-03-16 19:08:06 --> Loader Class Initialized
INFO - 2018-03-16 19:08:06 --> Helper loaded: url_helper
INFO - 2018-03-16 19:08:06 --> Helper loaded: site_helper
INFO - 2018-03-16 19:08:06 --> Database Driver Class Initialized
INFO - 2018-03-16 19:08:06 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:08:06 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:08:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:08:06 --> Controller Class Initialized
INFO - 2018-03-16 19:08:06 --> User Agent Class Initialized
INFO - 2018-03-16 19:08:06 --> Model "site_model" initialized
INFO - 2018-03-16 19:08:06 --> Model "user_model" initialized
INFO - 2018-03-16 19:08:06 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:08:06 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:08:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:08:06 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:08:06 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:08:06 --> Final output sent to browser
DEBUG - 2018-03-16 19:08:06 --> Total execution time: 0.0850
INFO - 2018-03-16 19:08:33 --> Database Driver Class Initialized
INFO - 2018-03-16 19:08:33 --> Config Class Initialized
INFO - 2018-03-16 19:08:33 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:08:33 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:08:33 --> Utf8 Class Initialized
INFO - 2018-03-16 19:08:33 --> URI Class Initialized
DEBUG - 2018-03-16 19:08:33 --> No URI present. Default controller set.
INFO - 2018-03-16 19:08:33 --> Router Class Initialized
INFO - 2018-03-16 19:08:33 --> Output Class Initialized
INFO - 2018-03-16 19:08:33 --> Security Class Initialized
DEBUG - 2018-03-16 19:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:08:33 --> Input Class Initialized
INFO - 2018-03-16 19:08:33 --> Language Class Initialized
INFO - 2018-03-16 19:08:33 --> Loader Class Initialized
INFO - 2018-03-16 19:08:33 --> Helper loaded: url_helper
INFO - 2018-03-16 19:08:33 --> Helper loaded: site_helper
INFO - 2018-03-16 19:08:33 --> Database Driver Class Initialized
INFO - 2018-03-16 19:08:33 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:08:33 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:08:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:08:33 --> Controller Class Initialized
INFO - 2018-03-16 19:08:33 --> User Agent Class Initialized
INFO - 2018-03-16 19:08:33 --> Model "site_model" initialized
INFO - 2018-03-16 19:08:33 --> Model "user_model" initialized
INFO - 2018-03-16 19:08:33 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:08:33 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:08:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:08:33 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:08:33 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:08:33 --> Final output sent to browser
DEBUG - 2018-03-16 19:08:33 --> Total execution time: 0.0800
INFO - 2018-03-16 19:08:37 --> Database Driver Class Initialized
INFO - 2018-03-16 19:08:38 --> Config Class Initialized
INFO - 2018-03-16 19:08:38 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:08:38 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:08:38 --> Utf8 Class Initialized
INFO - 2018-03-16 19:08:38 --> URI Class Initialized
DEBUG - 2018-03-16 19:08:38 --> No URI present. Default controller set.
INFO - 2018-03-16 19:08:38 --> Router Class Initialized
INFO - 2018-03-16 19:08:38 --> Output Class Initialized
INFO - 2018-03-16 19:08:38 --> Security Class Initialized
DEBUG - 2018-03-16 19:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:08:38 --> Input Class Initialized
INFO - 2018-03-16 19:08:38 --> Language Class Initialized
INFO - 2018-03-16 19:08:38 --> Loader Class Initialized
INFO - 2018-03-16 19:08:38 --> Helper loaded: url_helper
INFO - 2018-03-16 19:08:38 --> Helper loaded: site_helper
INFO - 2018-03-16 19:08:38 --> Database Driver Class Initialized
INFO - 2018-03-16 19:08:38 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:08:38 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:08:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:08:38 --> Controller Class Initialized
INFO - 2018-03-16 19:08:38 --> User Agent Class Initialized
INFO - 2018-03-16 19:08:38 --> Model "site_model" initialized
INFO - 2018-03-16 19:08:38 --> Model "user_model" initialized
INFO - 2018-03-16 19:08:38 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:08:38 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:08:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:08:38 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:08:38 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:08:38 --> Final output sent to browser
DEBUG - 2018-03-16 19:08:38 --> Total execution time: 0.0950
INFO - 2018-03-16 19:09:20 --> Database Driver Class Initialized
INFO - 2018-03-16 19:09:20 --> Config Class Initialized
INFO - 2018-03-16 19:09:20 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:09:20 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:09:20 --> Utf8 Class Initialized
INFO - 2018-03-16 19:09:20 --> URI Class Initialized
DEBUG - 2018-03-16 19:09:20 --> No URI present. Default controller set.
INFO - 2018-03-16 19:09:20 --> Router Class Initialized
INFO - 2018-03-16 19:09:20 --> Output Class Initialized
INFO - 2018-03-16 19:09:20 --> Security Class Initialized
DEBUG - 2018-03-16 19:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:09:20 --> Input Class Initialized
INFO - 2018-03-16 19:09:20 --> Language Class Initialized
INFO - 2018-03-16 19:09:20 --> Loader Class Initialized
INFO - 2018-03-16 19:09:20 --> Helper loaded: url_helper
INFO - 2018-03-16 19:09:20 --> Helper loaded: site_helper
INFO - 2018-03-16 19:09:20 --> Database Driver Class Initialized
INFO - 2018-03-16 19:09:20 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:09:20 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:09:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:09:20 --> Controller Class Initialized
INFO - 2018-03-16 19:09:20 --> User Agent Class Initialized
INFO - 2018-03-16 19:09:20 --> Model "site_model" initialized
INFO - 2018-03-16 19:09:20 --> Model "user_model" initialized
INFO - 2018-03-16 19:09:20 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:09:20 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:09:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:09:20 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:09:20 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:09:20 --> Final output sent to browser
DEBUG - 2018-03-16 19:09:20 --> Total execution time: 0.0725
INFO - 2018-03-16 19:09:40 --> Database Driver Class Initialized
INFO - 2018-03-16 19:09:40 --> Config Class Initialized
INFO - 2018-03-16 19:09:40 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:09:40 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:09:40 --> Utf8 Class Initialized
INFO - 2018-03-16 19:09:40 --> URI Class Initialized
DEBUG - 2018-03-16 19:09:40 --> No URI present. Default controller set.
INFO - 2018-03-16 19:09:40 --> Router Class Initialized
INFO - 2018-03-16 19:09:40 --> Output Class Initialized
INFO - 2018-03-16 19:09:40 --> Security Class Initialized
DEBUG - 2018-03-16 19:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:09:40 --> Input Class Initialized
INFO - 2018-03-16 19:09:40 --> Language Class Initialized
INFO - 2018-03-16 19:09:40 --> Loader Class Initialized
INFO - 2018-03-16 19:09:40 --> Helper loaded: url_helper
INFO - 2018-03-16 19:09:40 --> Helper loaded: site_helper
INFO - 2018-03-16 19:09:40 --> Database Driver Class Initialized
INFO - 2018-03-16 19:09:41 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:09:41 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:09:41 --> Controller Class Initialized
INFO - 2018-03-16 19:09:41 --> User Agent Class Initialized
INFO - 2018-03-16 19:09:41 --> Model "site_model" initialized
INFO - 2018-03-16 19:09:41 --> Model "user_model" initialized
INFO - 2018-03-16 19:09:41 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:09:41 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:09:41 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:09:41 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:09:41 --> Final output sent to browser
DEBUG - 2018-03-16 19:09:41 --> Total execution time: 0.0525
INFO - 2018-03-16 19:09:51 --> Database Driver Class Initialized
INFO - 2018-03-16 19:09:51 --> Config Class Initialized
INFO - 2018-03-16 19:09:51 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:09:51 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:09:51 --> Utf8 Class Initialized
INFO - 2018-03-16 19:09:51 --> URI Class Initialized
INFO - 2018-03-16 19:09:51 --> Router Class Initialized
INFO - 2018-03-16 19:09:51 --> Output Class Initialized
INFO - 2018-03-16 19:09:51 --> Security Class Initialized
DEBUG - 2018-03-16 19:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:09:51 --> Input Class Initialized
INFO - 2018-03-16 19:09:51 --> Language Class Initialized
INFO - 2018-03-16 19:09:51 --> Loader Class Initialized
INFO - 2018-03-16 19:09:51 --> Helper loaded: url_helper
INFO - 2018-03-16 19:09:51 --> Helper loaded: site_helper
INFO - 2018-03-16 19:09:51 --> Database Driver Class Initialized
INFO - 2018-03-16 19:09:51 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:09:51 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:09:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:09:51 --> Controller Class Initialized
INFO - 2018-03-16 19:09:51 --> Model "user_model" initialized
INFO - 2018-03-16 19:09:51 --> Model "site_model" initialized
INFO - 2018-03-16 19:09:51 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:09:51 --> Final output sent to browser
DEBUG - 2018-03-16 19:09:51 --> Total execution time: 0.0600
INFO - 2018-03-16 19:09:59 --> Database Driver Class Initialized
INFO - 2018-03-16 19:09:59 --> Config Class Initialized
INFO - 2018-03-16 19:09:59 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:09:59 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:09:59 --> Utf8 Class Initialized
INFO - 2018-03-16 19:09:59 --> URI Class Initialized
INFO - 2018-03-16 19:09:59 --> Router Class Initialized
INFO - 2018-03-16 19:09:59 --> Output Class Initialized
INFO - 2018-03-16 19:09:59 --> Security Class Initialized
DEBUG - 2018-03-16 19:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:09:59 --> Input Class Initialized
INFO - 2018-03-16 19:09:59 --> Language Class Initialized
INFO - 2018-03-16 19:09:59 --> Loader Class Initialized
INFO - 2018-03-16 19:09:59 --> Helper loaded: url_helper
INFO - 2018-03-16 19:09:59 --> Helper loaded: site_helper
INFO - 2018-03-16 19:09:59 --> Database Driver Class Initialized
INFO - 2018-03-16 19:09:59 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:09:59 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:09:59 --> Controller Class Initialized
INFO - 2018-03-16 19:09:59 --> Model "user_model" initialized
INFO - 2018-03-16 19:09:59 --> Model "site_model" initialized
INFO - 2018-03-16 19:09:59 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:09:59 --> Final output sent to browser
DEBUG - 2018-03-16 19:09:59 --> Total execution time: 0.0535
INFO - 2018-03-16 19:10:00 --> Database Driver Class Initialized
INFO - 2018-03-16 19:10:00 --> Config Class Initialized
INFO - 2018-03-16 19:10:00 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:10:00 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:10:00 --> Utf8 Class Initialized
INFO - 2018-03-16 19:10:00 --> URI Class Initialized
INFO - 2018-03-16 19:10:00 --> Router Class Initialized
INFO - 2018-03-16 19:10:00 --> Output Class Initialized
INFO - 2018-03-16 19:10:00 --> Security Class Initialized
DEBUG - 2018-03-16 19:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:10:00 --> Input Class Initialized
INFO - 2018-03-16 19:10:00 --> Language Class Initialized
INFO - 2018-03-16 19:10:00 --> Loader Class Initialized
INFO - 2018-03-16 19:10:00 --> Helper loaded: url_helper
INFO - 2018-03-16 19:10:00 --> Helper loaded: site_helper
INFO - 2018-03-16 19:10:00 --> Database Driver Class Initialized
INFO - 2018-03-16 19:10:00 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:10:00 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:10:00 --> Controller Class Initialized
INFO - 2018-03-16 19:10:00 --> Model "user_model" initialized
INFO - 2018-03-16 19:10:00 --> Model "site_model" initialized
INFO - 2018-03-16 19:10:00 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:10:00 --> Final output sent to browser
DEBUG - 2018-03-16 19:10:00 --> Total execution time: 0.1150
INFO - 2018-03-16 19:10:00 --> Database Driver Class Initialized
INFO - 2018-03-16 19:10:00 --> Config Class Initialized
INFO - 2018-03-16 19:10:00 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:10:00 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:10:00 --> Utf8 Class Initialized
INFO - 2018-03-16 19:10:00 --> URI Class Initialized
INFO - 2018-03-16 19:10:00 --> Router Class Initialized
INFO - 2018-03-16 19:10:00 --> Output Class Initialized
INFO - 2018-03-16 19:10:00 --> Security Class Initialized
DEBUG - 2018-03-16 19:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:10:00 --> Input Class Initialized
INFO - 2018-03-16 19:10:00 --> Language Class Initialized
INFO - 2018-03-16 19:10:00 --> Loader Class Initialized
INFO - 2018-03-16 19:10:00 --> Helper loaded: url_helper
INFO - 2018-03-16 19:10:00 --> Helper loaded: site_helper
INFO - 2018-03-16 19:10:00 --> Database Driver Class Initialized
INFO - 2018-03-16 19:10:00 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:10:00 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:10:00 --> Controller Class Initialized
INFO - 2018-03-16 19:10:00 --> Model "user_model" initialized
INFO - 2018-03-16 19:10:00 --> Model "site_model" initialized
INFO - 2018-03-16 19:10:00 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:10:00 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:10:00 --> Model "pm_model" initialized
INFO - 2018-03-16 19:10:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2018-03-16 19:10:01 --> Pagination Class Initialized
INFO - 2018-03-16 19:10:01 --> Model "premium_model" initialized
INFO - 2018-03-16 19:10:01 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/main_header.php
ERROR - 2018-03-16 19:10:01 --> Could not find the language line "coins_with_paypal"
ERROR - 2018-03-16 19:10:01 --> Could not find the language line "coins_with_stripe"
ERROR - 2018-03-16 19:10:01 --> Could not find the language line "not_enough_credits"
ERROR - 2018-03-16 19:10:01 --> Could not find the language line "take_it_btn"
ERROR - 2018-03-16 19:10:01 --> Could not find the language line "see_loves_success"
ERROR - 2018-03-16 19:10:01 --> Could not find the language line "invisible_success"
ERROR - 2018-03-16 19:10:01 --> Could not find the language line "featured_one_week_success"
ERROR - 2018-03-16 19:10:01 --> Could not find the language line "featured_one_month_success"
ERROR - 2018-03-16 19:10:01 --> Could not find the language line "send_reply_btn"
ERROR - 2018-03-16 19:10:01 --> Could not find the language line "write_something"
ERROR - 2018-03-16 19:10:01 --> Could not find the language line "conv_not_exist"
ERROR - 2018-03-16 19:10:01 --> Could not find the language line "write_something"
INFO - 2018-03-16 19:10:01 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/main_footer.php
INFO - 2018-03-16 19:10:01 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\site/home.php
INFO - 2018-03-16 19:10:01 --> Final output sent to browser
DEBUG - 2018-03-16 19:10:01 --> Total execution time: 0.7250
INFO - 2018-03-16 19:10:01 --> Database Driver Class Initialized
INFO - 2018-03-16 19:10:01 --> Config Class Initialized
INFO - 2018-03-16 19:10:01 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:10:01 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:10:01 --> Utf8 Class Initialized
INFO - 2018-03-16 19:10:01 --> URI Class Initialized
INFO - 2018-03-16 19:10:01 --> Router Class Initialized
INFO - 2018-03-16 19:10:01 --> Output Class Initialized
INFO - 2018-03-16 19:10:01 --> Security Class Initialized
DEBUG - 2018-03-16 19:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:10:01 --> Input Class Initialized
INFO - 2018-03-16 19:10:01 --> Language Class Initialized
ERROR - 2018-03-16 19:10:01 --> 404 Page Not Found: Chat/okcss.php
INFO - 2018-03-16 19:10:01 --> Database Driver Class Initialized
INFO - 2018-03-16 19:10:01 --> Config Class Initialized
INFO - 2018-03-16 19:10:01 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:10:01 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:10:01 --> Utf8 Class Initialized
INFO - 2018-03-16 19:10:01 --> URI Class Initialized
INFO - 2018-03-16 19:10:01 --> Router Class Initialized
INFO - 2018-03-16 19:10:01 --> Output Class Initialized
INFO - 2018-03-16 19:10:01 --> Security Class Initialized
DEBUG - 2018-03-16 19:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:10:01 --> Input Class Initialized
INFO - 2018-03-16 19:10:01 --> Language Class Initialized
ERROR - 2018-03-16 19:10:01 --> 404 Page Not Found: Chat/okjs.php
INFO - 2018-03-16 19:10:05 --> Database Driver Class Initialized
INFO - 2018-03-16 19:10:05 --> Config Class Initialized
INFO - 2018-03-16 19:10:05 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:10:05 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:10:05 --> Utf8 Class Initialized
INFO - 2018-03-16 19:10:05 --> URI Class Initialized
INFO - 2018-03-16 19:10:05 --> Router Class Initialized
INFO - 2018-03-16 19:10:05 --> Output Class Initialized
INFO - 2018-03-16 19:10:05 --> Security Class Initialized
DEBUG - 2018-03-16 19:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:10:05 --> Input Class Initialized
INFO - 2018-03-16 19:10:05 --> Language Class Initialized
INFO - 2018-03-16 19:10:05 --> Loader Class Initialized
INFO - 2018-03-16 19:10:05 --> Helper loaded: url_helper
INFO - 2018-03-16 19:10:05 --> Helper loaded: site_helper
INFO - 2018-03-16 19:10:05 --> Database Driver Class Initialized
INFO - 2018-03-16 19:10:05 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:10:05 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:10:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:10:05 --> Controller Class Initialized
INFO - 2018-03-16 19:10:06 --> Database Driver Class Initialized
INFO - 2018-03-16 19:10:06 --> Config Class Initialized
INFO - 2018-03-16 19:10:06 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:10:06 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:10:06 --> Utf8 Class Initialized
INFO - 2018-03-16 19:10:06 --> URI Class Initialized
DEBUG - 2018-03-16 19:10:06 --> No URI present. Default controller set.
INFO - 2018-03-16 19:10:06 --> Router Class Initialized
INFO - 2018-03-16 19:10:06 --> Output Class Initialized
INFO - 2018-03-16 19:10:06 --> Security Class Initialized
DEBUG - 2018-03-16 19:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:10:06 --> Input Class Initialized
INFO - 2018-03-16 19:10:06 --> Language Class Initialized
INFO - 2018-03-16 19:10:06 --> Loader Class Initialized
INFO - 2018-03-16 19:10:06 --> Helper loaded: url_helper
INFO - 2018-03-16 19:10:06 --> Helper loaded: site_helper
INFO - 2018-03-16 19:10:06 --> Database Driver Class Initialized
INFO - 2018-03-16 19:10:06 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:10:06 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:10:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:10:06 --> Controller Class Initialized
INFO - 2018-03-16 19:10:06 --> User Agent Class Initialized
INFO - 2018-03-16 19:10:06 --> Model "site_model" initialized
INFO - 2018-03-16 19:10:06 --> Model "user_model" initialized
INFO - 2018-03-16 19:10:06 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:10:06 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:10:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:10:06 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:10:06 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:10:06 --> Final output sent to browser
DEBUG - 2018-03-16 19:10:06 --> Total execution time: 0.0450
INFO - 2018-03-16 19:10:07 --> Database Driver Class Initialized
INFO - 2018-03-16 19:10:07 --> Config Class Initialized
INFO - 2018-03-16 19:10:07 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:10:07 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:10:07 --> Utf8 Class Initialized
INFO - 2018-03-16 19:10:07 --> URI Class Initialized
DEBUG - 2018-03-16 19:10:07 --> No URI present. Default controller set.
INFO - 2018-03-16 19:10:07 --> Router Class Initialized
INFO - 2018-03-16 19:10:07 --> Output Class Initialized
INFO - 2018-03-16 19:10:07 --> Security Class Initialized
DEBUG - 2018-03-16 19:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:10:07 --> Input Class Initialized
INFO - 2018-03-16 19:10:07 --> Language Class Initialized
INFO - 2018-03-16 19:10:07 --> Loader Class Initialized
INFO - 2018-03-16 19:10:07 --> Helper loaded: url_helper
INFO - 2018-03-16 19:10:07 --> Helper loaded: site_helper
INFO - 2018-03-16 19:10:07 --> Database Driver Class Initialized
INFO - 2018-03-16 19:10:07 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:10:07 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:10:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:10:07 --> Controller Class Initialized
INFO - 2018-03-16 19:10:07 --> User Agent Class Initialized
INFO - 2018-03-16 19:10:07 --> Model "site_model" initialized
INFO - 2018-03-16 19:10:07 --> Model "user_model" initialized
INFO - 2018-03-16 19:10:07 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:10:07 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:10:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:10:07 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:10:07 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:10:07 --> Final output sent to browser
DEBUG - 2018-03-16 19:10:07 --> Total execution time: 0.0925
INFO - 2018-03-16 19:10:12 --> Database Driver Class Initialized
INFO - 2018-03-16 19:10:12 --> Config Class Initialized
INFO - 2018-03-16 19:10:12 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:10:12 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:10:12 --> Utf8 Class Initialized
INFO - 2018-03-16 19:10:12 --> URI Class Initialized
DEBUG - 2018-03-16 19:10:12 --> No URI present. Default controller set.
INFO - 2018-03-16 19:10:12 --> Router Class Initialized
INFO - 2018-03-16 19:10:12 --> Output Class Initialized
INFO - 2018-03-16 19:10:12 --> Security Class Initialized
DEBUG - 2018-03-16 19:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:10:12 --> Input Class Initialized
INFO - 2018-03-16 19:10:12 --> Language Class Initialized
INFO - 2018-03-16 19:10:12 --> Loader Class Initialized
INFO - 2018-03-16 19:10:12 --> Helper loaded: url_helper
INFO - 2018-03-16 19:10:12 --> Helper loaded: site_helper
INFO - 2018-03-16 19:10:12 --> Database Driver Class Initialized
INFO - 2018-03-16 19:10:12 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:10:12 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:10:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:10:12 --> Controller Class Initialized
INFO - 2018-03-16 19:10:12 --> User Agent Class Initialized
INFO - 2018-03-16 19:10:12 --> Model "site_model" initialized
INFO - 2018-03-16 19:10:12 --> Model "user_model" initialized
INFO - 2018-03-16 19:10:12 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:10:12 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:10:12 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:10:12 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:10:12 --> Final output sent to browser
DEBUG - 2018-03-16 19:10:12 --> Total execution time: 0.0775
INFO - 2018-03-16 19:11:13 --> Database Driver Class Initialized
INFO - 2018-03-16 19:11:13 --> Config Class Initialized
INFO - 2018-03-16 19:11:13 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:11:13 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:11:13 --> Utf8 Class Initialized
INFO - 2018-03-16 19:11:13 --> URI Class Initialized
DEBUG - 2018-03-16 19:11:13 --> No URI present. Default controller set.
INFO - 2018-03-16 19:11:13 --> Router Class Initialized
INFO - 2018-03-16 19:11:13 --> Output Class Initialized
INFO - 2018-03-16 19:11:13 --> Security Class Initialized
DEBUG - 2018-03-16 19:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:11:13 --> Input Class Initialized
INFO - 2018-03-16 19:11:13 --> Language Class Initialized
INFO - 2018-03-16 19:11:13 --> Loader Class Initialized
INFO - 2018-03-16 19:11:13 --> Helper loaded: url_helper
INFO - 2018-03-16 19:11:13 --> Helper loaded: site_helper
INFO - 2018-03-16 19:11:13 --> Database Driver Class Initialized
INFO - 2018-03-16 19:11:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:11:13 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:11:13 --> Controller Class Initialized
INFO - 2018-03-16 19:11:13 --> User Agent Class Initialized
INFO - 2018-03-16 19:11:13 --> Model "site_model" initialized
INFO - 2018-03-16 19:11:13 --> Model "user_model" initialized
INFO - 2018-03-16 19:11:13 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:11:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:11:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:11:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:11:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:11:13 --> Final output sent to browser
DEBUG - 2018-03-16 19:11:13 --> Total execution time: 0.0750
INFO - 2018-03-16 19:11:17 --> Database Driver Class Initialized
INFO - 2018-03-16 19:11:17 --> Config Class Initialized
INFO - 2018-03-16 19:11:17 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:11:18 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:11:18 --> Utf8 Class Initialized
INFO - 2018-03-16 19:11:18 --> URI Class Initialized
INFO - 2018-03-16 19:11:18 --> Router Class Initialized
INFO - 2018-03-16 19:11:18 --> Output Class Initialized
INFO - 2018-03-16 19:11:18 --> Security Class Initialized
DEBUG - 2018-03-16 19:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:11:18 --> Input Class Initialized
INFO - 2018-03-16 19:11:18 --> Language Class Initialized
INFO - 2018-03-16 19:11:18 --> Loader Class Initialized
INFO - 2018-03-16 19:11:18 --> Helper loaded: url_helper
INFO - 2018-03-16 19:11:18 --> Helper loaded: site_helper
INFO - 2018-03-16 19:11:18 --> Database Driver Class Initialized
INFO - 2018-03-16 19:11:18 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:11:18 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:11:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:11:18 --> Controller Class Initialized
INFO - 2018-03-16 19:11:18 --> Model "user_model" initialized
INFO - 2018-03-16 19:11:18 --> Model "site_model" initialized
INFO - 2018-03-16 19:11:18 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:11:18 --> Final output sent to browser
DEBUG - 2018-03-16 19:11:18 --> Total execution time: 0.0650
INFO - 2018-03-16 19:11:39 --> Database Driver Class Initialized
INFO - 2018-03-16 19:11:39 --> Config Class Initialized
INFO - 2018-03-16 19:11:39 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:11:39 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:11:39 --> Utf8 Class Initialized
INFO - 2018-03-16 19:11:39 --> URI Class Initialized
DEBUG - 2018-03-16 19:11:39 --> No URI present. Default controller set.
INFO - 2018-03-16 19:11:39 --> Router Class Initialized
INFO - 2018-03-16 19:11:39 --> Output Class Initialized
INFO - 2018-03-16 19:11:39 --> Security Class Initialized
DEBUG - 2018-03-16 19:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:11:39 --> Input Class Initialized
INFO - 2018-03-16 19:11:39 --> Language Class Initialized
INFO - 2018-03-16 19:11:39 --> Loader Class Initialized
INFO - 2018-03-16 19:11:39 --> Helper loaded: url_helper
INFO - 2018-03-16 19:11:39 --> Helper loaded: site_helper
INFO - 2018-03-16 19:11:39 --> Database Driver Class Initialized
INFO - 2018-03-16 19:11:39 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:11:39 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:11:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:11:39 --> Controller Class Initialized
INFO - 2018-03-16 19:11:39 --> User Agent Class Initialized
INFO - 2018-03-16 19:11:39 --> Model "site_model" initialized
INFO - 2018-03-16 19:11:39 --> Model "user_model" initialized
INFO - 2018-03-16 19:11:39 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:11:39 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:11:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:11:39 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:11:39 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:11:39 --> Final output sent to browser
DEBUG - 2018-03-16 19:11:39 --> Total execution time: 0.0800
INFO - 2018-03-16 19:11:41 --> Database Driver Class Initialized
INFO - 2018-03-16 19:11:41 --> Config Class Initialized
INFO - 2018-03-16 19:11:41 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:11:41 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:11:41 --> Utf8 Class Initialized
INFO - 2018-03-16 19:11:41 --> URI Class Initialized
INFO - 2018-03-16 19:11:41 --> Router Class Initialized
INFO - 2018-03-16 19:11:41 --> Output Class Initialized
INFO - 2018-03-16 19:11:41 --> Security Class Initialized
DEBUG - 2018-03-16 19:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:11:41 --> Input Class Initialized
INFO - 2018-03-16 19:11:41 --> Language Class Initialized
INFO - 2018-03-16 19:11:41 --> Loader Class Initialized
INFO - 2018-03-16 19:11:41 --> Helper loaded: url_helper
INFO - 2018-03-16 19:11:41 --> Helper loaded: site_helper
INFO - 2018-03-16 19:11:41 --> Database Driver Class Initialized
INFO - 2018-03-16 19:11:41 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:11:41 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:11:41 --> Controller Class Initialized
INFO - 2018-03-16 19:11:41 --> Model "user_model" initialized
INFO - 2018-03-16 19:11:41 --> Model "site_model" initialized
INFO - 2018-03-16 19:11:41 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:11:41 --> Final output sent to browser
DEBUG - 2018-03-16 19:11:41 --> Total execution time: 0.0710
INFO - 2018-03-16 19:11:51 --> Database Driver Class Initialized
INFO - 2018-03-16 19:11:51 --> Config Class Initialized
INFO - 2018-03-16 19:11:51 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:11:51 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:11:51 --> Utf8 Class Initialized
INFO - 2018-03-16 19:11:51 --> URI Class Initialized
DEBUG - 2018-03-16 19:11:51 --> No URI present. Default controller set.
INFO - 2018-03-16 19:11:51 --> Router Class Initialized
INFO - 2018-03-16 19:11:51 --> Output Class Initialized
INFO - 2018-03-16 19:11:51 --> Security Class Initialized
DEBUG - 2018-03-16 19:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:11:51 --> Input Class Initialized
INFO - 2018-03-16 19:11:51 --> Language Class Initialized
INFO - 2018-03-16 19:11:51 --> Loader Class Initialized
INFO - 2018-03-16 19:11:51 --> Helper loaded: url_helper
INFO - 2018-03-16 19:11:51 --> Helper loaded: site_helper
INFO - 2018-03-16 19:11:51 --> Database Driver Class Initialized
INFO - 2018-03-16 19:11:51 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:11:51 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:11:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:11:51 --> Controller Class Initialized
INFO - 2018-03-16 19:11:51 --> User Agent Class Initialized
INFO - 2018-03-16 19:11:51 --> Model "site_model" initialized
INFO - 2018-03-16 19:11:51 --> Model "user_model" initialized
INFO - 2018-03-16 19:11:51 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:11:51 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:11:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:11:51 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:11:51 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:11:51 --> Final output sent to browser
DEBUG - 2018-03-16 19:11:51 --> Total execution time: 0.1175
INFO - 2018-03-16 19:11:53 --> Database Driver Class Initialized
INFO - 2018-03-16 19:11:53 --> Config Class Initialized
INFO - 2018-03-16 19:11:53 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:11:53 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:11:53 --> Utf8 Class Initialized
INFO - 2018-03-16 19:11:53 --> URI Class Initialized
INFO - 2018-03-16 19:11:53 --> Router Class Initialized
INFO - 2018-03-16 19:11:53 --> Output Class Initialized
INFO - 2018-03-16 19:11:53 --> Security Class Initialized
DEBUG - 2018-03-16 19:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:11:53 --> Input Class Initialized
INFO - 2018-03-16 19:11:53 --> Language Class Initialized
INFO - 2018-03-16 19:11:53 --> Loader Class Initialized
INFO - 2018-03-16 19:11:53 --> Helper loaded: url_helper
INFO - 2018-03-16 19:11:53 --> Helper loaded: site_helper
INFO - 2018-03-16 19:11:53 --> Database Driver Class Initialized
INFO - 2018-03-16 19:11:53 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:11:53 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:11:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:11:53 --> Controller Class Initialized
INFO - 2018-03-16 19:11:53 --> Model "user_model" initialized
INFO - 2018-03-16 19:11:53 --> Model "site_model" initialized
INFO - 2018-03-16 19:11:53 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:11:53 --> Final output sent to browser
DEBUG - 2018-03-16 19:11:53 --> Total execution time: 0.0775
INFO - 2018-03-16 19:12:04 --> Database Driver Class Initialized
INFO - 2018-03-16 19:12:04 --> Config Class Initialized
INFO - 2018-03-16 19:12:04 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:12:04 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:12:04 --> Utf8 Class Initialized
INFO - 2018-03-16 19:12:04 --> URI Class Initialized
DEBUG - 2018-03-16 19:12:04 --> No URI present. Default controller set.
INFO - 2018-03-16 19:12:04 --> Router Class Initialized
INFO - 2018-03-16 19:12:04 --> Output Class Initialized
INFO - 2018-03-16 19:12:04 --> Security Class Initialized
DEBUG - 2018-03-16 19:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:12:04 --> Input Class Initialized
INFO - 2018-03-16 19:12:04 --> Language Class Initialized
INFO - 2018-03-16 19:12:04 --> Loader Class Initialized
INFO - 2018-03-16 19:12:04 --> Helper loaded: url_helper
INFO - 2018-03-16 19:12:04 --> Helper loaded: site_helper
INFO - 2018-03-16 19:12:04 --> Database Driver Class Initialized
INFO - 2018-03-16 19:12:04 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:12:04 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:12:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:12:04 --> Controller Class Initialized
INFO - 2018-03-16 19:12:04 --> User Agent Class Initialized
INFO - 2018-03-16 19:12:04 --> Model "site_model" initialized
INFO - 2018-03-16 19:12:04 --> Model "user_model" initialized
INFO - 2018-03-16 19:12:04 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:12:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:12:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:12:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:12:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:12:04 --> Final output sent to browser
DEBUG - 2018-03-16 19:12:04 --> Total execution time: 0.0500
INFO - 2018-03-16 19:12:14 --> Database Driver Class Initialized
INFO - 2018-03-16 19:12:14 --> Config Class Initialized
INFO - 2018-03-16 19:12:14 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:12:14 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:12:14 --> Utf8 Class Initialized
INFO - 2018-03-16 19:12:14 --> URI Class Initialized
DEBUG - 2018-03-16 19:12:14 --> No URI present. Default controller set.
INFO - 2018-03-16 19:12:14 --> Router Class Initialized
INFO - 2018-03-16 19:12:14 --> Output Class Initialized
INFO - 2018-03-16 19:12:14 --> Security Class Initialized
DEBUG - 2018-03-16 19:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:12:14 --> Input Class Initialized
INFO - 2018-03-16 19:12:14 --> Language Class Initialized
INFO - 2018-03-16 19:12:14 --> Loader Class Initialized
INFO - 2018-03-16 19:12:14 --> Helper loaded: url_helper
INFO - 2018-03-16 19:12:14 --> Helper loaded: site_helper
INFO - 2018-03-16 19:12:14 --> Database Driver Class Initialized
INFO - 2018-03-16 19:12:14 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:12:14 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:12:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:12:14 --> Controller Class Initialized
INFO - 2018-03-16 19:12:14 --> User Agent Class Initialized
INFO - 2018-03-16 19:12:14 --> Model "site_model" initialized
INFO - 2018-03-16 19:12:14 --> Model "user_model" initialized
INFO - 2018-03-16 19:12:14 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:12:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:12:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:12:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:12:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:12:14 --> Final output sent to browser
DEBUG - 2018-03-16 19:12:14 --> Total execution time: 0.0625
INFO - 2018-03-16 19:12:17 --> Database Driver Class Initialized
INFO - 2018-03-16 19:12:17 --> Config Class Initialized
INFO - 2018-03-16 19:12:17 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:12:17 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:12:17 --> Utf8 Class Initialized
INFO - 2018-03-16 19:12:17 --> URI Class Initialized
INFO - 2018-03-16 19:12:17 --> Router Class Initialized
INFO - 2018-03-16 19:12:17 --> Output Class Initialized
INFO - 2018-03-16 19:12:17 --> Security Class Initialized
DEBUG - 2018-03-16 19:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:12:17 --> Input Class Initialized
INFO - 2018-03-16 19:12:17 --> Language Class Initialized
INFO - 2018-03-16 19:12:17 --> Loader Class Initialized
INFO - 2018-03-16 19:12:17 --> Helper loaded: url_helper
INFO - 2018-03-16 19:12:17 --> Helper loaded: site_helper
INFO - 2018-03-16 19:12:17 --> Database Driver Class Initialized
INFO - 2018-03-16 19:12:17 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:12:17 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:12:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:12:17 --> Controller Class Initialized
INFO - 2018-03-16 19:12:17 --> Model "user_model" initialized
INFO - 2018-03-16 19:12:17 --> Model "site_model" initialized
INFO - 2018-03-16 19:12:17 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:12:17 --> Final output sent to browser
DEBUG - 2018-03-16 19:12:17 --> Total execution time: 0.0600
INFO - 2018-03-16 19:12:24 --> Database Driver Class Initialized
INFO - 2018-03-16 19:12:24 --> Config Class Initialized
INFO - 2018-03-16 19:12:24 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:12:24 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:12:24 --> Utf8 Class Initialized
INFO - 2018-03-16 19:12:24 --> URI Class Initialized
DEBUG - 2018-03-16 19:12:24 --> No URI present. Default controller set.
INFO - 2018-03-16 19:12:24 --> Router Class Initialized
INFO - 2018-03-16 19:12:24 --> Output Class Initialized
INFO - 2018-03-16 19:12:24 --> Security Class Initialized
DEBUG - 2018-03-16 19:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:12:24 --> Input Class Initialized
INFO - 2018-03-16 19:12:24 --> Language Class Initialized
INFO - 2018-03-16 19:12:24 --> Loader Class Initialized
INFO - 2018-03-16 19:12:24 --> Helper loaded: url_helper
INFO - 2018-03-16 19:12:24 --> Helper loaded: site_helper
INFO - 2018-03-16 19:12:24 --> Database Driver Class Initialized
INFO - 2018-03-16 19:12:24 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:12:24 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:12:24 --> Controller Class Initialized
INFO - 2018-03-16 19:12:24 --> User Agent Class Initialized
INFO - 2018-03-16 19:12:24 --> Model "site_model" initialized
INFO - 2018-03-16 19:12:24 --> Model "user_model" initialized
INFO - 2018-03-16 19:12:24 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:12:24 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:12:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:12:24 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:12:24 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:12:24 --> Final output sent to browser
DEBUG - 2018-03-16 19:12:24 --> Total execution time: 0.0700
INFO - 2018-03-16 19:12:26 --> Database Driver Class Initialized
INFO - 2018-03-16 19:12:26 --> Config Class Initialized
INFO - 2018-03-16 19:12:26 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:12:26 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:12:26 --> Utf8 Class Initialized
INFO - 2018-03-16 19:12:26 --> URI Class Initialized
INFO - 2018-03-16 19:12:26 --> Router Class Initialized
INFO - 2018-03-16 19:12:26 --> Output Class Initialized
INFO - 2018-03-16 19:12:26 --> Security Class Initialized
DEBUG - 2018-03-16 19:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:12:26 --> Input Class Initialized
INFO - 2018-03-16 19:12:26 --> Language Class Initialized
INFO - 2018-03-16 19:12:26 --> Loader Class Initialized
INFO - 2018-03-16 19:12:26 --> Helper loaded: url_helper
INFO - 2018-03-16 19:12:26 --> Helper loaded: site_helper
INFO - 2018-03-16 19:12:26 --> Database Driver Class Initialized
INFO - 2018-03-16 19:12:26 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:12:26 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:12:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:12:26 --> Controller Class Initialized
INFO - 2018-03-16 19:12:26 --> Model "user_model" initialized
INFO - 2018-03-16 19:12:26 --> Model "site_model" initialized
INFO - 2018-03-16 19:12:26 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:12:26 --> Final output sent to browser
DEBUG - 2018-03-16 19:12:26 --> Total execution time: 0.0775
INFO - 2018-03-16 19:12:28 --> Database Driver Class Initialized
INFO - 2018-03-16 19:12:28 --> Config Class Initialized
INFO - 2018-03-16 19:12:28 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:12:28 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:12:28 --> Utf8 Class Initialized
INFO - 2018-03-16 19:12:28 --> URI Class Initialized
DEBUG - 2018-03-16 19:12:28 --> No URI present. Default controller set.
INFO - 2018-03-16 19:12:28 --> Router Class Initialized
INFO - 2018-03-16 19:12:28 --> Output Class Initialized
INFO - 2018-03-16 19:12:28 --> Security Class Initialized
DEBUG - 2018-03-16 19:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:12:28 --> Input Class Initialized
INFO - 2018-03-16 19:12:28 --> Language Class Initialized
INFO - 2018-03-16 19:12:28 --> Loader Class Initialized
INFO - 2018-03-16 19:12:28 --> Helper loaded: url_helper
INFO - 2018-03-16 19:12:28 --> Helper loaded: site_helper
INFO - 2018-03-16 19:12:28 --> Database Driver Class Initialized
INFO - 2018-03-16 19:12:28 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:12:28 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:12:28 --> Controller Class Initialized
INFO - 2018-03-16 19:12:28 --> User Agent Class Initialized
INFO - 2018-03-16 19:12:28 --> Model "site_model" initialized
INFO - 2018-03-16 19:12:28 --> Model "user_model" initialized
INFO - 2018-03-16 19:12:28 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:12:28 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:12:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:12:28 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:12:28 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:12:28 --> Final output sent to browser
DEBUG - 2018-03-16 19:12:28 --> Total execution time: 0.2515
INFO - 2018-03-16 19:12:32 --> Database Driver Class Initialized
INFO - 2018-03-16 19:12:32 --> Config Class Initialized
INFO - 2018-03-16 19:12:32 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:12:32 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:12:32 --> Utf8 Class Initialized
INFO - 2018-03-16 19:12:32 --> URI Class Initialized
DEBUG - 2018-03-16 19:12:32 --> No URI present. Default controller set.
INFO - 2018-03-16 19:12:32 --> Router Class Initialized
INFO - 2018-03-16 19:12:32 --> Output Class Initialized
INFO - 2018-03-16 19:12:32 --> Security Class Initialized
DEBUG - 2018-03-16 19:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:12:32 --> Input Class Initialized
INFO - 2018-03-16 19:12:32 --> Language Class Initialized
INFO - 2018-03-16 19:12:32 --> Loader Class Initialized
INFO - 2018-03-16 19:12:32 --> Helper loaded: url_helper
INFO - 2018-03-16 19:12:32 --> Helper loaded: site_helper
INFO - 2018-03-16 19:12:32 --> Database Driver Class Initialized
INFO - 2018-03-16 19:12:32 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:12:32 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:12:32 --> Controller Class Initialized
INFO - 2018-03-16 19:12:32 --> User Agent Class Initialized
INFO - 2018-03-16 19:12:32 --> Model "site_model" initialized
INFO - 2018-03-16 19:12:32 --> Model "user_model" initialized
INFO - 2018-03-16 19:12:32 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:12:32 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:12:32 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:12:32 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:12:32 --> Final output sent to browser
DEBUG - 2018-03-16 19:12:32 --> Total execution time: 0.0625
INFO - 2018-03-16 19:12:34 --> Database Driver Class Initialized
INFO - 2018-03-16 19:12:34 --> Config Class Initialized
INFO - 2018-03-16 19:12:34 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:12:34 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:12:34 --> Utf8 Class Initialized
INFO - 2018-03-16 19:12:34 --> URI Class Initialized
INFO - 2018-03-16 19:12:34 --> Router Class Initialized
INFO - 2018-03-16 19:12:34 --> Output Class Initialized
INFO - 2018-03-16 19:12:34 --> Security Class Initialized
DEBUG - 2018-03-16 19:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:12:34 --> Input Class Initialized
INFO - 2018-03-16 19:12:34 --> Language Class Initialized
INFO - 2018-03-16 19:12:34 --> Loader Class Initialized
INFO - 2018-03-16 19:12:34 --> Helper loaded: url_helper
INFO - 2018-03-16 19:12:34 --> Helper loaded: site_helper
INFO - 2018-03-16 19:12:34 --> Database Driver Class Initialized
INFO - 2018-03-16 19:12:34 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:12:34 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:12:34 --> Controller Class Initialized
INFO - 2018-03-16 19:12:34 --> Model "user_model" initialized
INFO - 2018-03-16 19:12:34 --> Model "site_model" initialized
INFO - 2018-03-16 19:12:34 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:12:34 --> Final output sent to browser
DEBUG - 2018-03-16 19:12:34 --> Total execution time: 0.0675
INFO - 2018-03-16 19:12:39 --> Database Driver Class Initialized
INFO - 2018-03-16 19:12:39 --> Config Class Initialized
INFO - 2018-03-16 19:12:39 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:12:39 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:12:39 --> Utf8 Class Initialized
INFO - 2018-03-16 19:12:39 --> URI Class Initialized
INFO - 2018-03-16 19:12:39 --> Router Class Initialized
INFO - 2018-03-16 19:12:39 --> Output Class Initialized
INFO - 2018-03-16 19:12:39 --> Security Class Initialized
DEBUG - 2018-03-16 19:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:12:39 --> Input Class Initialized
INFO - 2018-03-16 19:12:39 --> Language Class Initialized
INFO - 2018-03-16 19:12:39 --> Loader Class Initialized
INFO - 2018-03-16 19:12:39 --> Helper loaded: url_helper
INFO - 2018-03-16 19:12:39 --> Helper loaded: site_helper
INFO - 2018-03-16 19:12:39 --> Database Driver Class Initialized
INFO - 2018-03-16 19:12:39 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:12:39 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:12:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:12:39 --> Controller Class Initialized
INFO - 2018-03-16 19:12:39 --> Final output sent to browser
DEBUG - 2018-03-16 19:12:39 --> Total execution time: 0.0520
INFO - 2018-03-16 19:13:09 --> Database Driver Class Initialized
INFO - 2018-03-16 19:13:09 --> Config Class Initialized
INFO - 2018-03-16 19:13:09 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:13:09 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:13:09 --> Utf8 Class Initialized
INFO - 2018-03-16 19:13:09 --> URI Class Initialized
DEBUG - 2018-03-16 19:13:09 --> No URI present. Default controller set.
INFO - 2018-03-16 19:13:09 --> Router Class Initialized
INFO - 2018-03-16 19:13:09 --> Output Class Initialized
INFO - 2018-03-16 19:13:09 --> Security Class Initialized
DEBUG - 2018-03-16 19:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:13:09 --> Input Class Initialized
INFO - 2018-03-16 19:13:09 --> Language Class Initialized
INFO - 2018-03-16 19:13:09 --> Loader Class Initialized
INFO - 2018-03-16 19:13:09 --> Helper loaded: url_helper
INFO - 2018-03-16 19:13:09 --> Helper loaded: site_helper
INFO - 2018-03-16 19:13:09 --> Database Driver Class Initialized
INFO - 2018-03-16 19:13:09 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:13:09 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:13:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:13:09 --> Controller Class Initialized
INFO - 2018-03-16 19:13:09 --> User Agent Class Initialized
INFO - 2018-03-16 19:13:09 --> Model "site_model" initialized
INFO - 2018-03-16 19:13:09 --> Model "user_model" initialized
INFO - 2018-03-16 19:13:09 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:13:09 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:13:09 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:13:09 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:13:09 --> Final output sent to browser
DEBUG - 2018-03-16 19:13:09 --> Total execution time: 0.0725
INFO - 2018-03-16 19:13:12 --> Database Driver Class Initialized
INFO - 2018-03-16 19:13:12 --> Config Class Initialized
INFO - 2018-03-16 19:13:12 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:13:12 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:13:12 --> Utf8 Class Initialized
INFO - 2018-03-16 19:13:12 --> URI Class Initialized
INFO - 2018-03-16 19:13:12 --> Router Class Initialized
INFO - 2018-03-16 19:13:12 --> Output Class Initialized
INFO - 2018-03-16 19:13:12 --> Security Class Initialized
DEBUG - 2018-03-16 19:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:13:12 --> Input Class Initialized
INFO - 2018-03-16 19:13:12 --> Language Class Initialized
INFO - 2018-03-16 19:13:12 --> Loader Class Initialized
INFO - 2018-03-16 19:13:12 --> Helper loaded: url_helper
INFO - 2018-03-16 19:13:12 --> Helper loaded: site_helper
INFO - 2018-03-16 19:13:12 --> Database Driver Class Initialized
INFO - 2018-03-16 19:13:12 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:13:12 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:13:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:13:12 --> Controller Class Initialized
INFO - 2018-03-16 19:13:12 --> Final output sent to browser
DEBUG - 2018-03-16 19:13:12 --> Total execution time: 0.0675
INFO - 2018-03-16 19:14:26 --> Database Driver Class Initialized
INFO - 2018-03-16 19:14:26 --> Config Class Initialized
INFO - 2018-03-16 19:14:26 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:14:26 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:14:26 --> Utf8 Class Initialized
INFO - 2018-03-16 19:14:26 --> URI Class Initialized
DEBUG - 2018-03-16 19:14:26 --> No URI present. Default controller set.
INFO - 2018-03-16 19:14:26 --> Router Class Initialized
INFO - 2018-03-16 19:14:26 --> Output Class Initialized
INFO - 2018-03-16 19:14:26 --> Security Class Initialized
DEBUG - 2018-03-16 19:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:14:26 --> Input Class Initialized
INFO - 2018-03-16 19:14:26 --> Language Class Initialized
INFO - 2018-03-16 19:14:26 --> Loader Class Initialized
INFO - 2018-03-16 19:14:26 --> Helper loaded: url_helper
INFO - 2018-03-16 19:14:26 --> Helper loaded: site_helper
INFO - 2018-03-16 19:14:26 --> Database Driver Class Initialized
INFO - 2018-03-16 19:14:26 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:14:26 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:14:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:14:26 --> Controller Class Initialized
INFO - 2018-03-16 19:14:26 --> User Agent Class Initialized
INFO - 2018-03-16 19:14:26 --> Model "site_model" initialized
INFO - 2018-03-16 19:14:26 --> Model "user_model" initialized
INFO - 2018-03-16 19:14:26 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:14:26 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:14:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:14:26 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:14:26 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:14:26 --> Final output sent to browser
DEBUG - 2018-03-16 19:14:26 --> Total execution time: 0.0750
INFO - 2018-03-16 19:14:28 --> Database Driver Class Initialized
INFO - 2018-03-16 19:14:28 --> Config Class Initialized
INFO - 2018-03-16 19:14:28 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:14:28 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:14:28 --> Utf8 Class Initialized
INFO - 2018-03-16 19:14:28 --> URI Class Initialized
INFO - 2018-03-16 19:14:28 --> Router Class Initialized
INFO - 2018-03-16 19:14:28 --> Output Class Initialized
INFO - 2018-03-16 19:14:28 --> Security Class Initialized
DEBUG - 2018-03-16 19:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:14:28 --> Input Class Initialized
INFO - 2018-03-16 19:14:28 --> Language Class Initialized
INFO - 2018-03-16 19:14:28 --> Loader Class Initialized
INFO - 2018-03-16 19:14:28 --> Helper loaded: url_helper
INFO - 2018-03-16 19:14:28 --> Helper loaded: site_helper
INFO - 2018-03-16 19:14:28 --> Database Driver Class Initialized
INFO - 2018-03-16 19:14:28 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:14:28 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:14:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:14:28 --> Controller Class Initialized
INFO - 2018-03-16 19:14:28 --> Model "user_model" initialized
INFO - 2018-03-16 19:14:28 --> Model "site_model" initialized
INFO - 2018-03-16 19:14:28 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:14:28 --> Final output sent to browser
DEBUG - 2018-03-16 19:14:28 --> Total execution time: 0.0725
INFO - 2018-03-16 19:14:30 --> Database Driver Class Initialized
INFO - 2018-03-16 19:14:30 --> Config Class Initialized
INFO - 2018-03-16 19:14:30 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:14:30 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:14:30 --> Utf8 Class Initialized
INFO - 2018-03-16 19:14:30 --> URI Class Initialized
INFO - 2018-03-16 19:14:30 --> Router Class Initialized
INFO - 2018-03-16 19:14:30 --> Output Class Initialized
INFO - 2018-03-16 19:14:30 --> Security Class Initialized
DEBUG - 2018-03-16 19:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:14:30 --> Input Class Initialized
INFO - 2018-03-16 19:14:30 --> Language Class Initialized
INFO - 2018-03-16 19:14:30 --> Loader Class Initialized
INFO - 2018-03-16 19:14:30 --> Helper loaded: url_helper
INFO - 2018-03-16 19:14:30 --> Helper loaded: site_helper
INFO - 2018-03-16 19:14:30 --> Database Driver Class Initialized
INFO - 2018-03-16 19:14:30 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:14:30 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:14:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:14:30 --> Controller Class Initialized
INFO - 2018-03-16 19:14:30 --> Final output sent to browser
DEBUG - 2018-03-16 19:14:30 --> Total execution time: 0.0550
INFO - 2018-03-16 19:14:39 --> Database Driver Class Initialized
INFO - 2018-03-16 19:14:39 --> Config Class Initialized
INFO - 2018-03-16 19:14:39 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:14:39 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:14:39 --> Utf8 Class Initialized
INFO - 2018-03-16 19:14:39 --> URI Class Initialized
DEBUG - 2018-03-16 19:14:39 --> No URI present. Default controller set.
INFO - 2018-03-16 19:14:39 --> Router Class Initialized
INFO - 2018-03-16 19:14:39 --> Output Class Initialized
INFO - 2018-03-16 19:14:39 --> Security Class Initialized
DEBUG - 2018-03-16 19:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:14:39 --> Input Class Initialized
INFO - 2018-03-16 19:14:39 --> Language Class Initialized
INFO - 2018-03-16 19:14:39 --> Loader Class Initialized
INFO - 2018-03-16 19:14:39 --> Helper loaded: url_helper
INFO - 2018-03-16 19:14:39 --> Helper loaded: site_helper
INFO - 2018-03-16 19:14:39 --> Database Driver Class Initialized
INFO - 2018-03-16 19:14:39 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:14:40 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:14:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:14:40 --> Controller Class Initialized
INFO - 2018-03-16 19:14:40 --> User Agent Class Initialized
INFO - 2018-03-16 19:14:40 --> Model "site_model" initialized
INFO - 2018-03-16 19:14:40 --> Model "user_model" initialized
INFO - 2018-03-16 19:14:40 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:14:40 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:14:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:14:40 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:14:40 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:14:40 --> Final output sent to browser
DEBUG - 2018-03-16 19:14:40 --> Total execution time: 0.0650
INFO - 2018-03-16 19:14:47 --> Database Driver Class Initialized
INFO - 2018-03-16 19:14:47 --> Config Class Initialized
INFO - 2018-03-16 19:14:47 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:14:47 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:14:47 --> Utf8 Class Initialized
INFO - 2018-03-16 19:14:47 --> URI Class Initialized
DEBUG - 2018-03-16 19:14:47 --> No URI present. Default controller set.
INFO - 2018-03-16 19:14:47 --> Router Class Initialized
INFO - 2018-03-16 19:14:47 --> Output Class Initialized
INFO - 2018-03-16 19:14:47 --> Security Class Initialized
DEBUG - 2018-03-16 19:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:14:47 --> Input Class Initialized
INFO - 2018-03-16 19:14:47 --> Language Class Initialized
INFO - 2018-03-16 19:14:47 --> Loader Class Initialized
INFO - 2018-03-16 19:14:47 --> Helper loaded: url_helper
INFO - 2018-03-16 19:14:47 --> Helper loaded: site_helper
INFO - 2018-03-16 19:14:47 --> Database Driver Class Initialized
INFO - 2018-03-16 19:14:47 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:14:47 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:14:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:14:47 --> Controller Class Initialized
INFO - 2018-03-16 19:14:47 --> User Agent Class Initialized
INFO - 2018-03-16 19:14:47 --> Model "site_model" initialized
INFO - 2018-03-16 19:14:47 --> Model "user_model" initialized
INFO - 2018-03-16 19:14:47 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:14:47 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:14:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:14:47 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:14:47 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:14:47 --> Final output sent to browser
DEBUG - 2018-03-16 19:14:47 --> Total execution time: 0.0775
INFO - 2018-03-16 19:14:49 --> Database Driver Class Initialized
INFO - 2018-03-16 19:14:49 --> Config Class Initialized
INFO - 2018-03-16 19:14:49 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:14:49 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:14:49 --> Utf8 Class Initialized
INFO - 2018-03-16 19:14:49 --> URI Class Initialized
INFO - 2018-03-16 19:14:49 --> Router Class Initialized
INFO - 2018-03-16 19:14:49 --> Output Class Initialized
INFO - 2018-03-16 19:14:49 --> Security Class Initialized
DEBUG - 2018-03-16 19:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:14:49 --> Input Class Initialized
INFO - 2018-03-16 19:14:49 --> Language Class Initialized
INFO - 2018-03-16 19:14:49 --> Loader Class Initialized
INFO - 2018-03-16 19:14:49 --> Helper loaded: url_helper
INFO - 2018-03-16 19:14:49 --> Helper loaded: site_helper
INFO - 2018-03-16 19:14:49 --> Database Driver Class Initialized
INFO - 2018-03-16 19:14:49 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:14:49 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:14:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:14:49 --> Controller Class Initialized
INFO - 2018-03-16 19:14:49 --> Model "user_model" initialized
INFO - 2018-03-16 19:14:49 --> Model "site_model" initialized
INFO - 2018-03-16 19:14:49 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:14:49 --> Final output sent to browser
DEBUG - 2018-03-16 19:14:49 --> Total execution time: 0.0600
INFO - 2018-03-16 19:15:04 --> Database Driver Class Initialized
INFO - 2018-03-16 19:15:04 --> Config Class Initialized
INFO - 2018-03-16 19:15:04 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:15:04 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:15:04 --> Utf8 Class Initialized
INFO - 2018-03-16 19:15:04 --> URI Class Initialized
DEBUG - 2018-03-16 19:15:04 --> No URI present. Default controller set.
INFO - 2018-03-16 19:15:04 --> Router Class Initialized
INFO - 2018-03-16 19:15:04 --> Output Class Initialized
INFO - 2018-03-16 19:15:04 --> Security Class Initialized
DEBUG - 2018-03-16 19:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:15:04 --> Input Class Initialized
INFO - 2018-03-16 19:15:04 --> Language Class Initialized
INFO - 2018-03-16 19:15:04 --> Loader Class Initialized
INFO - 2018-03-16 19:15:04 --> Helper loaded: url_helper
INFO - 2018-03-16 19:15:04 --> Helper loaded: site_helper
INFO - 2018-03-16 19:15:04 --> Database Driver Class Initialized
INFO - 2018-03-16 19:15:04 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:15:04 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:15:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:15:04 --> Controller Class Initialized
INFO - 2018-03-16 19:15:04 --> User Agent Class Initialized
INFO - 2018-03-16 19:15:04 --> Model "site_model" initialized
INFO - 2018-03-16 19:15:04 --> Model "user_model" initialized
INFO - 2018-03-16 19:15:04 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:15:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:15:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:15:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:15:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:15:04 --> Final output sent to browser
DEBUG - 2018-03-16 19:15:04 --> Total execution time: 0.1075
INFO - 2018-03-16 19:15:14 --> Database Driver Class Initialized
INFO - 2018-03-16 19:15:14 --> Config Class Initialized
INFO - 2018-03-16 19:15:14 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:15:14 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:15:14 --> Utf8 Class Initialized
INFO - 2018-03-16 19:15:14 --> URI Class Initialized
DEBUG - 2018-03-16 19:15:14 --> No URI present. Default controller set.
INFO - 2018-03-16 19:15:14 --> Router Class Initialized
INFO - 2018-03-16 19:15:14 --> Output Class Initialized
INFO - 2018-03-16 19:15:14 --> Security Class Initialized
DEBUG - 2018-03-16 19:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:15:14 --> Input Class Initialized
INFO - 2018-03-16 19:15:14 --> Language Class Initialized
INFO - 2018-03-16 19:15:14 --> Loader Class Initialized
INFO - 2018-03-16 19:15:14 --> Helper loaded: url_helper
INFO - 2018-03-16 19:15:14 --> Helper loaded: site_helper
INFO - 2018-03-16 19:15:14 --> Database Driver Class Initialized
INFO - 2018-03-16 19:15:14 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:15:14 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:15:14 --> Controller Class Initialized
INFO - 2018-03-16 19:15:14 --> User Agent Class Initialized
INFO - 2018-03-16 19:15:14 --> Model "site_model" initialized
INFO - 2018-03-16 19:15:14 --> Model "user_model" initialized
INFO - 2018-03-16 19:15:14 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:15:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:15:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:15:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:15:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:15:14 --> Final output sent to browser
DEBUG - 2018-03-16 19:15:14 --> Total execution time: 0.0725
INFO - 2018-03-16 19:15:18 --> Database Driver Class Initialized
INFO - 2018-03-16 19:15:18 --> Config Class Initialized
INFO - 2018-03-16 19:15:18 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:15:18 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:15:18 --> Utf8 Class Initialized
INFO - 2018-03-16 19:15:18 --> URI Class Initialized
INFO - 2018-03-16 19:15:18 --> Router Class Initialized
INFO - 2018-03-16 19:15:18 --> Output Class Initialized
INFO - 2018-03-16 19:15:18 --> Security Class Initialized
DEBUG - 2018-03-16 19:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:15:18 --> Input Class Initialized
INFO - 2018-03-16 19:15:18 --> Language Class Initialized
INFO - 2018-03-16 19:15:18 --> Loader Class Initialized
INFO - 2018-03-16 19:15:18 --> Helper loaded: url_helper
INFO - 2018-03-16 19:15:18 --> Helper loaded: site_helper
INFO - 2018-03-16 19:15:18 --> Database Driver Class Initialized
INFO - 2018-03-16 19:15:18 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:15:18 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:15:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:15:18 --> Controller Class Initialized
INFO - 2018-03-16 19:15:18 --> Final output sent to browser
DEBUG - 2018-03-16 19:15:18 --> Total execution time: 0.0525
INFO - 2018-03-16 19:15:21 --> Database Driver Class Initialized
INFO - 2018-03-16 19:15:21 --> Config Class Initialized
INFO - 2018-03-16 19:15:21 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:15:21 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:15:21 --> Utf8 Class Initialized
INFO - 2018-03-16 19:15:21 --> URI Class Initialized
INFO - 2018-03-16 19:15:21 --> Router Class Initialized
INFO - 2018-03-16 19:15:21 --> Output Class Initialized
INFO - 2018-03-16 19:15:21 --> Security Class Initialized
DEBUG - 2018-03-16 19:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:15:21 --> Input Class Initialized
INFO - 2018-03-16 19:15:21 --> Language Class Initialized
INFO - 2018-03-16 19:15:21 --> Loader Class Initialized
INFO - 2018-03-16 19:15:21 --> Helper loaded: url_helper
INFO - 2018-03-16 19:15:21 --> Helper loaded: site_helper
INFO - 2018-03-16 19:15:21 --> Database Driver Class Initialized
INFO - 2018-03-16 19:15:21 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:15:21 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:15:21 --> Controller Class Initialized
INFO - 2018-03-16 19:15:21 --> Final output sent to browser
DEBUG - 2018-03-16 19:15:21 --> Total execution time: 0.0500
INFO - 2018-03-16 19:15:25 --> Database Driver Class Initialized
INFO - 2018-03-16 19:15:25 --> Config Class Initialized
INFO - 2018-03-16 19:15:25 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:15:25 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:15:25 --> Utf8 Class Initialized
INFO - 2018-03-16 19:15:25 --> URI Class Initialized
INFO - 2018-03-16 19:15:25 --> Router Class Initialized
INFO - 2018-03-16 19:15:25 --> Output Class Initialized
INFO - 2018-03-16 19:15:25 --> Security Class Initialized
DEBUG - 2018-03-16 19:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:15:25 --> Input Class Initialized
INFO - 2018-03-16 19:15:25 --> Language Class Initialized
INFO - 2018-03-16 19:15:25 --> Loader Class Initialized
INFO - 2018-03-16 19:15:25 --> Helper loaded: url_helper
INFO - 2018-03-16 19:15:25 --> Helper loaded: site_helper
INFO - 2018-03-16 19:15:25 --> Database Driver Class Initialized
INFO - 2018-03-16 19:15:25 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:15:25 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:15:25 --> Controller Class Initialized
INFO - 2018-03-16 19:15:25 --> Model "user_model" initialized
INFO - 2018-03-16 19:15:25 --> Final output sent to browser
DEBUG - 2018-03-16 19:15:25 --> Total execution time: 0.0750
INFO - 2018-03-16 19:15:32 --> Database Driver Class Initialized
INFO - 2018-03-16 19:15:32 --> Config Class Initialized
INFO - 2018-03-16 19:15:32 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:15:32 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:15:32 --> Utf8 Class Initialized
INFO - 2018-03-16 19:15:32 --> URI Class Initialized
DEBUG - 2018-03-16 19:15:32 --> No URI present. Default controller set.
INFO - 2018-03-16 19:15:32 --> Router Class Initialized
INFO - 2018-03-16 19:15:32 --> Output Class Initialized
INFO - 2018-03-16 19:15:32 --> Security Class Initialized
DEBUG - 2018-03-16 19:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:15:32 --> Input Class Initialized
INFO - 2018-03-16 19:15:32 --> Language Class Initialized
INFO - 2018-03-16 19:15:32 --> Loader Class Initialized
INFO - 2018-03-16 19:15:32 --> Helper loaded: url_helper
INFO - 2018-03-16 19:15:32 --> Helper loaded: site_helper
INFO - 2018-03-16 19:15:32 --> Database Driver Class Initialized
INFO - 2018-03-16 19:15:32 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:15:32 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:15:32 --> Controller Class Initialized
INFO - 2018-03-16 19:15:32 --> User Agent Class Initialized
INFO - 2018-03-16 19:15:32 --> Model "site_model" initialized
INFO - 2018-03-16 19:15:32 --> Model "user_model" initialized
INFO - 2018-03-16 19:15:32 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:15:32 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:15:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:15:32 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:15:32 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:15:32 --> Final output sent to browser
DEBUG - 2018-03-16 19:15:32 --> Total execution time: 0.0550
INFO - 2018-03-16 19:17:02 --> Database Driver Class Initialized
INFO - 2018-03-16 19:17:02 --> Config Class Initialized
INFO - 2018-03-16 19:17:02 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:17:02 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:17:02 --> Utf8 Class Initialized
INFO - 2018-03-16 19:17:02 --> URI Class Initialized
DEBUG - 2018-03-16 19:17:02 --> No URI present. Default controller set.
INFO - 2018-03-16 19:17:02 --> Router Class Initialized
INFO - 2018-03-16 19:17:02 --> Output Class Initialized
INFO - 2018-03-16 19:17:02 --> Security Class Initialized
DEBUG - 2018-03-16 19:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:17:02 --> Input Class Initialized
INFO - 2018-03-16 19:17:02 --> Language Class Initialized
INFO - 2018-03-16 19:17:02 --> Loader Class Initialized
INFO - 2018-03-16 19:17:02 --> Helper loaded: url_helper
INFO - 2018-03-16 19:17:02 --> Helper loaded: site_helper
INFO - 2018-03-16 19:17:02 --> Database Driver Class Initialized
INFO - 2018-03-16 19:17:02 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:17:02 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:17:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:17:02 --> Controller Class Initialized
INFO - 2018-03-16 19:17:02 --> User Agent Class Initialized
INFO - 2018-03-16 19:17:02 --> Model "site_model" initialized
INFO - 2018-03-16 19:17:02 --> Model "user_model" initialized
INFO - 2018-03-16 19:17:02 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:17:02 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:17:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:17:02 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:17:02 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:17:02 --> Final output sent to browser
DEBUG - 2018-03-16 19:17:02 --> Total execution time: 0.0825
INFO - 2018-03-16 19:17:19 --> Database Driver Class Initialized
INFO - 2018-03-16 19:17:19 --> Config Class Initialized
INFO - 2018-03-16 19:17:19 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:17:19 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:17:19 --> Utf8 Class Initialized
INFO - 2018-03-16 19:17:19 --> URI Class Initialized
DEBUG - 2018-03-16 19:17:19 --> No URI present. Default controller set.
INFO - 2018-03-16 19:17:19 --> Router Class Initialized
INFO - 2018-03-16 19:17:19 --> Output Class Initialized
INFO - 2018-03-16 19:17:19 --> Security Class Initialized
DEBUG - 2018-03-16 19:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:17:19 --> Input Class Initialized
INFO - 2018-03-16 19:17:19 --> Language Class Initialized
INFO - 2018-03-16 19:17:19 --> Loader Class Initialized
INFO - 2018-03-16 19:17:19 --> Helper loaded: url_helper
INFO - 2018-03-16 19:17:19 --> Helper loaded: site_helper
INFO - 2018-03-16 19:17:19 --> Database Driver Class Initialized
INFO - 2018-03-16 19:17:19 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:17:19 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:17:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:17:19 --> Controller Class Initialized
INFO - 2018-03-16 19:17:19 --> User Agent Class Initialized
INFO - 2018-03-16 19:17:19 --> Model "site_model" initialized
INFO - 2018-03-16 19:17:19 --> Model "user_model" initialized
INFO - 2018-03-16 19:17:19 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:17:19 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:17:19 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:17:19 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:17:19 --> Final output sent to browser
DEBUG - 2018-03-16 19:17:19 --> Total execution time: 0.0820
INFO - 2018-03-16 19:17:21 --> Database Driver Class Initialized
INFO - 2018-03-16 19:17:21 --> Config Class Initialized
INFO - 2018-03-16 19:17:21 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:17:21 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:17:21 --> Utf8 Class Initialized
INFO - 2018-03-16 19:17:21 --> URI Class Initialized
DEBUG - 2018-03-16 19:17:21 --> No URI present. Default controller set.
INFO - 2018-03-16 19:17:21 --> Router Class Initialized
INFO - 2018-03-16 19:17:21 --> Output Class Initialized
INFO - 2018-03-16 19:17:21 --> Security Class Initialized
DEBUG - 2018-03-16 19:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:17:21 --> Input Class Initialized
INFO - 2018-03-16 19:17:21 --> Language Class Initialized
INFO - 2018-03-16 19:17:21 --> Loader Class Initialized
INFO - 2018-03-16 19:17:21 --> Helper loaded: url_helper
INFO - 2018-03-16 19:17:21 --> Helper loaded: site_helper
INFO - 2018-03-16 19:17:21 --> Database Driver Class Initialized
INFO - 2018-03-16 19:17:21 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:17:21 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:17:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:17:21 --> Controller Class Initialized
INFO - 2018-03-16 19:17:21 --> User Agent Class Initialized
INFO - 2018-03-16 19:17:21 --> Model "site_model" initialized
INFO - 2018-03-16 19:17:21 --> Model "user_model" initialized
INFO - 2018-03-16 19:17:21 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:17:21 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:17:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:17:21 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:17:21 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:17:21 --> Final output sent to browser
DEBUG - 2018-03-16 19:17:21 --> Total execution time: 0.1255
INFO - 2018-03-16 19:17:23 --> Database Driver Class Initialized
INFO - 2018-03-16 19:17:23 --> Config Class Initialized
INFO - 2018-03-16 19:17:23 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:17:23 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:17:23 --> Utf8 Class Initialized
INFO - 2018-03-16 19:17:23 --> URI Class Initialized
DEBUG - 2018-03-16 19:17:23 --> No URI present. Default controller set.
INFO - 2018-03-16 19:17:23 --> Router Class Initialized
INFO - 2018-03-16 19:17:23 --> Output Class Initialized
INFO - 2018-03-16 19:17:23 --> Security Class Initialized
DEBUG - 2018-03-16 19:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:17:23 --> Input Class Initialized
INFO - 2018-03-16 19:17:23 --> Language Class Initialized
INFO - 2018-03-16 19:17:23 --> Loader Class Initialized
INFO - 2018-03-16 19:17:23 --> Helper loaded: url_helper
INFO - 2018-03-16 19:17:23 --> Helper loaded: site_helper
INFO - 2018-03-16 19:17:23 --> Database Driver Class Initialized
INFO - 2018-03-16 19:17:23 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:17:23 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:17:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:17:23 --> Controller Class Initialized
INFO - 2018-03-16 19:17:23 --> User Agent Class Initialized
INFO - 2018-03-16 19:17:23 --> Model "site_model" initialized
INFO - 2018-03-16 19:17:23 --> Model "user_model" initialized
INFO - 2018-03-16 19:17:23 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:17:23 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:17:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:17:23 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:17:23 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:17:23 --> Final output sent to browser
DEBUG - 2018-03-16 19:17:23 --> Total execution time: 0.0625
INFO - 2018-03-16 19:18:40 --> Database Driver Class Initialized
INFO - 2018-03-16 19:18:40 --> Config Class Initialized
INFO - 2018-03-16 19:18:40 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:18:40 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:18:40 --> Utf8 Class Initialized
INFO - 2018-03-16 19:18:40 --> URI Class Initialized
INFO - 2018-03-16 19:18:40 --> Router Class Initialized
INFO - 2018-03-16 19:18:40 --> Output Class Initialized
INFO - 2018-03-16 19:18:40 --> Security Class Initialized
DEBUG - 2018-03-16 19:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:18:40 --> Input Class Initialized
INFO - 2018-03-16 19:18:40 --> Language Class Initialized
INFO - 2018-03-16 19:18:40 --> Loader Class Initialized
INFO - 2018-03-16 19:18:40 --> Helper loaded: url_helper
INFO - 2018-03-16 19:18:40 --> Helper loaded: site_helper
INFO - 2018-03-16 19:18:40 --> Database Driver Class Initialized
INFO - 2018-03-16 19:18:40 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:18:40 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:18:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:18:40 --> Controller Class Initialized
INFO - 2018-03-16 19:18:40 --> Model "user_model" initialized
INFO - 2018-03-16 19:18:40 --> Model "site_model" initialized
INFO - 2018-03-16 19:18:40 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:18:40 --> Final output sent to browser
DEBUG - 2018-03-16 19:18:40 --> Total execution time: 0.0375
INFO - 2018-03-16 19:18:42 --> Database Driver Class Initialized
INFO - 2018-03-16 19:18:42 --> Config Class Initialized
INFO - 2018-03-16 19:18:42 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:18:42 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:18:42 --> Utf8 Class Initialized
INFO - 2018-03-16 19:18:42 --> URI Class Initialized
INFO - 2018-03-16 19:18:42 --> Router Class Initialized
INFO - 2018-03-16 19:18:42 --> Output Class Initialized
INFO - 2018-03-16 19:18:42 --> Security Class Initialized
DEBUG - 2018-03-16 19:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:18:42 --> Input Class Initialized
INFO - 2018-03-16 19:18:42 --> Language Class Initialized
INFO - 2018-03-16 19:18:42 --> Loader Class Initialized
INFO - 2018-03-16 19:18:42 --> Helper loaded: url_helper
INFO - 2018-03-16 19:18:42 --> Helper loaded: site_helper
INFO - 2018-03-16 19:18:42 --> Database Driver Class Initialized
INFO - 2018-03-16 19:18:42 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:18:42 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:18:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:18:42 --> Controller Class Initialized
INFO - 2018-03-16 19:18:42 --> Model "user_model" initialized
INFO - 2018-03-16 19:18:42 --> Model "site_model" initialized
INFO - 2018-03-16 19:18:42 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:18:42 --> Final output sent to browser
DEBUG - 2018-03-16 19:18:42 --> Total execution time: 0.0625
INFO - 2018-03-16 19:18:43 --> Database Driver Class Initialized
INFO - 2018-03-16 19:18:43 --> Config Class Initialized
INFO - 2018-03-16 19:18:43 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:18:43 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:18:43 --> Utf8 Class Initialized
INFO - 2018-03-16 19:18:43 --> URI Class Initialized
INFO - 2018-03-16 19:18:43 --> Router Class Initialized
INFO - 2018-03-16 19:18:43 --> Output Class Initialized
INFO - 2018-03-16 19:18:43 --> Security Class Initialized
DEBUG - 2018-03-16 19:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:18:43 --> Input Class Initialized
INFO - 2018-03-16 19:18:43 --> Language Class Initialized
INFO - 2018-03-16 19:18:43 --> Loader Class Initialized
INFO - 2018-03-16 19:18:43 --> Helper loaded: url_helper
INFO - 2018-03-16 19:18:43 --> Helper loaded: site_helper
INFO - 2018-03-16 19:18:43 --> Database Driver Class Initialized
INFO - 2018-03-16 19:18:43 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:18:43 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:18:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:18:43 --> Controller Class Initialized
INFO - 2018-03-16 19:18:43 --> Model "user_model" initialized
INFO - 2018-03-16 19:18:43 --> Model "site_model" initialized
INFO - 2018-03-16 19:18:43 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:18:43 --> Final output sent to browser
DEBUG - 2018-03-16 19:18:43 --> Total execution time: 0.0705
INFO - 2018-03-16 19:18:43 --> Database Driver Class Initialized
INFO - 2018-03-16 19:18:43 --> Config Class Initialized
INFO - 2018-03-16 19:18:43 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:18:43 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:18:43 --> Utf8 Class Initialized
INFO - 2018-03-16 19:18:43 --> URI Class Initialized
INFO - 2018-03-16 19:18:43 --> Router Class Initialized
INFO - 2018-03-16 19:18:43 --> Output Class Initialized
INFO - 2018-03-16 19:18:43 --> Security Class Initialized
DEBUG - 2018-03-16 19:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:18:43 --> Input Class Initialized
INFO - 2018-03-16 19:18:43 --> Language Class Initialized
INFO - 2018-03-16 19:18:43 --> Loader Class Initialized
INFO - 2018-03-16 19:18:43 --> Helper loaded: url_helper
INFO - 2018-03-16 19:18:43 --> Helper loaded: site_helper
INFO - 2018-03-16 19:18:43 --> Database Driver Class Initialized
INFO - 2018-03-16 19:18:43 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:18:43 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:18:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:18:43 --> Controller Class Initialized
INFO - 2018-03-16 19:18:43 --> Model "user_model" initialized
INFO - 2018-03-16 19:18:43 --> Model "site_model" initialized
INFO - 2018-03-16 19:18:43 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:18:43 --> Final output sent to browser
DEBUG - 2018-03-16 19:18:43 --> Total execution time: 0.0600
INFO - 2018-03-16 19:18:43 --> Database Driver Class Initialized
INFO - 2018-03-16 19:18:44 --> Config Class Initialized
INFO - 2018-03-16 19:18:44 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:18:44 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:18:44 --> Utf8 Class Initialized
INFO - 2018-03-16 19:18:44 --> URI Class Initialized
INFO - 2018-03-16 19:18:44 --> Router Class Initialized
INFO - 2018-03-16 19:18:44 --> Output Class Initialized
INFO - 2018-03-16 19:18:44 --> Security Class Initialized
DEBUG - 2018-03-16 19:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:18:44 --> Input Class Initialized
INFO - 2018-03-16 19:18:44 --> Language Class Initialized
INFO - 2018-03-16 19:18:44 --> Loader Class Initialized
INFO - 2018-03-16 19:18:44 --> Helper loaded: url_helper
INFO - 2018-03-16 19:18:44 --> Helper loaded: site_helper
INFO - 2018-03-16 19:18:44 --> Database Driver Class Initialized
INFO - 2018-03-16 19:18:44 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:18:44 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:18:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:18:44 --> Controller Class Initialized
INFO - 2018-03-16 19:18:44 --> Model "user_model" initialized
INFO - 2018-03-16 19:18:44 --> Model "site_model" initialized
INFO - 2018-03-16 19:18:44 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:18:44 --> Final output sent to browser
DEBUG - 2018-03-16 19:18:44 --> Total execution time: 0.0710
INFO - 2018-03-16 19:19:27 --> Database Driver Class Initialized
INFO - 2018-03-16 19:19:27 --> Config Class Initialized
INFO - 2018-03-16 19:19:27 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:19:27 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:19:27 --> Utf8 Class Initialized
INFO - 2018-03-16 19:19:27 --> URI Class Initialized
INFO - 2018-03-16 19:19:27 --> Router Class Initialized
INFO - 2018-03-16 19:19:27 --> Output Class Initialized
INFO - 2018-03-16 19:19:27 --> Security Class Initialized
DEBUG - 2018-03-16 19:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:19:27 --> Input Class Initialized
INFO - 2018-03-16 19:19:27 --> Language Class Initialized
INFO - 2018-03-16 19:19:27 --> Loader Class Initialized
INFO - 2018-03-16 19:19:27 --> Helper loaded: url_helper
INFO - 2018-03-16 19:19:27 --> Helper loaded: site_helper
INFO - 2018-03-16 19:19:27 --> Database Driver Class Initialized
INFO - 2018-03-16 19:19:27 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:19:27 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:19:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:19:27 --> Controller Class Initialized
INFO - 2018-03-16 19:19:27 --> Model "user_model" initialized
INFO - 2018-03-16 19:19:27 --> Model "site_model" initialized
INFO - 2018-03-16 19:19:27 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:19:27 --> Final output sent to browser
DEBUG - 2018-03-16 19:19:27 --> Total execution time: 0.0625
INFO - 2018-03-16 19:19:28 --> Database Driver Class Initialized
INFO - 2018-03-16 19:19:28 --> Config Class Initialized
INFO - 2018-03-16 19:19:28 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:19:28 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:19:28 --> Utf8 Class Initialized
INFO - 2018-03-16 19:19:28 --> URI Class Initialized
INFO - 2018-03-16 19:19:28 --> Router Class Initialized
INFO - 2018-03-16 19:19:28 --> Output Class Initialized
INFO - 2018-03-16 19:19:28 --> Security Class Initialized
DEBUG - 2018-03-16 19:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:19:28 --> Input Class Initialized
INFO - 2018-03-16 19:19:28 --> Language Class Initialized
INFO - 2018-03-16 19:19:28 --> Loader Class Initialized
INFO - 2018-03-16 19:19:28 --> Helper loaded: url_helper
INFO - 2018-03-16 19:19:28 --> Helper loaded: site_helper
INFO - 2018-03-16 19:19:28 --> Database Driver Class Initialized
INFO - 2018-03-16 19:19:28 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:19:28 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:19:28 --> Controller Class Initialized
INFO - 2018-03-16 19:19:28 --> Model "user_model" initialized
INFO - 2018-03-16 19:19:28 --> Model "site_model" initialized
INFO - 2018-03-16 19:19:28 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:19:28 --> Final output sent to browser
DEBUG - 2018-03-16 19:19:28 --> Total execution time: 0.0580
INFO - 2018-03-16 19:19:29 --> Database Driver Class Initialized
INFO - 2018-03-16 19:19:29 --> Config Class Initialized
INFO - 2018-03-16 19:19:29 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:19:29 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:19:29 --> Utf8 Class Initialized
INFO - 2018-03-16 19:19:29 --> URI Class Initialized
INFO - 2018-03-16 19:19:29 --> Router Class Initialized
INFO - 2018-03-16 19:19:29 --> Output Class Initialized
INFO - 2018-03-16 19:19:29 --> Security Class Initialized
DEBUG - 2018-03-16 19:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:19:29 --> Input Class Initialized
INFO - 2018-03-16 19:19:29 --> Language Class Initialized
INFO - 2018-03-16 19:19:29 --> Loader Class Initialized
INFO - 2018-03-16 19:19:29 --> Helper loaded: url_helper
INFO - 2018-03-16 19:19:29 --> Helper loaded: site_helper
INFO - 2018-03-16 19:19:29 --> Database Driver Class Initialized
INFO - 2018-03-16 19:19:29 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:19:29 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:19:29 --> Controller Class Initialized
INFO - 2018-03-16 19:19:29 --> Model "user_model" initialized
INFO - 2018-03-16 19:19:29 --> Model "site_model" initialized
INFO - 2018-03-16 19:19:29 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:19:29 --> Final output sent to browser
DEBUG - 2018-03-16 19:19:29 --> Total execution time: 0.0570
INFO - 2018-03-16 19:19:38 --> Database Driver Class Initialized
INFO - 2018-03-16 19:19:38 --> Config Class Initialized
INFO - 2018-03-16 19:19:38 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:19:38 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:19:38 --> Utf8 Class Initialized
INFO - 2018-03-16 19:19:38 --> URI Class Initialized
INFO - 2018-03-16 19:19:38 --> Router Class Initialized
INFO - 2018-03-16 19:19:38 --> Output Class Initialized
INFO - 2018-03-16 19:19:38 --> Security Class Initialized
DEBUG - 2018-03-16 19:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:19:38 --> Input Class Initialized
INFO - 2018-03-16 19:19:38 --> Language Class Initialized
INFO - 2018-03-16 19:19:38 --> Loader Class Initialized
INFO - 2018-03-16 19:19:38 --> Helper loaded: url_helper
INFO - 2018-03-16 19:19:38 --> Helper loaded: site_helper
INFO - 2018-03-16 19:19:38 --> Database Driver Class Initialized
INFO - 2018-03-16 19:19:38 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:19:38 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:19:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:19:38 --> Controller Class Initialized
INFO - 2018-03-16 19:19:38 --> Model "user_model" initialized
INFO - 2018-03-16 19:19:38 --> Model "site_model" initialized
INFO - 2018-03-16 19:19:38 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:19:38 --> Final output sent to browser
DEBUG - 2018-03-16 19:19:38 --> Total execution time: 0.0675
INFO - 2018-03-16 19:19:40 --> Database Driver Class Initialized
INFO - 2018-03-16 19:19:40 --> Config Class Initialized
INFO - 2018-03-16 19:19:40 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:19:40 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:19:40 --> Utf8 Class Initialized
INFO - 2018-03-16 19:19:40 --> URI Class Initialized
INFO - 2018-03-16 19:19:40 --> Router Class Initialized
INFO - 2018-03-16 19:19:40 --> Output Class Initialized
INFO - 2018-03-16 19:19:40 --> Security Class Initialized
DEBUG - 2018-03-16 19:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:19:40 --> Input Class Initialized
INFO - 2018-03-16 19:19:40 --> Language Class Initialized
INFO - 2018-03-16 19:19:40 --> Loader Class Initialized
INFO - 2018-03-16 19:19:40 --> Helper loaded: url_helper
INFO - 2018-03-16 19:19:40 --> Helper loaded: site_helper
INFO - 2018-03-16 19:19:40 --> Database Driver Class Initialized
INFO - 2018-03-16 19:19:40 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:19:40 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:19:40 --> Controller Class Initialized
INFO - 2018-03-16 19:19:40 --> Model "user_model" initialized
INFO - 2018-03-16 19:19:40 --> Model "site_model" initialized
INFO - 2018-03-16 19:19:40 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:19:40 --> Final output sent to browser
DEBUG - 2018-03-16 19:19:40 --> Total execution time: 0.1450
INFO - 2018-03-16 19:19:41 --> Database Driver Class Initialized
INFO - 2018-03-16 19:19:41 --> Config Class Initialized
INFO - 2018-03-16 19:19:41 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:19:41 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:19:41 --> Utf8 Class Initialized
INFO - 2018-03-16 19:19:41 --> URI Class Initialized
INFO - 2018-03-16 19:19:41 --> Router Class Initialized
INFO - 2018-03-16 19:19:41 --> Output Class Initialized
INFO - 2018-03-16 19:19:41 --> Security Class Initialized
DEBUG - 2018-03-16 19:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:19:41 --> Input Class Initialized
INFO - 2018-03-16 19:19:41 --> Language Class Initialized
INFO - 2018-03-16 19:19:41 --> Loader Class Initialized
INFO - 2018-03-16 19:19:41 --> Helper loaded: url_helper
INFO - 2018-03-16 19:19:41 --> Helper loaded: site_helper
INFO - 2018-03-16 19:19:41 --> Database Driver Class Initialized
INFO - 2018-03-16 19:19:41 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:19:41 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:19:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:19:41 --> Controller Class Initialized
INFO - 2018-03-16 19:19:41 --> Model "user_model" initialized
INFO - 2018-03-16 19:19:41 --> Model "site_model" initialized
INFO - 2018-03-16 19:19:41 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:19:41 --> Final output sent to browser
DEBUG - 2018-03-16 19:19:41 --> Total execution time: 0.1060
INFO - 2018-03-16 19:19:56 --> Database Driver Class Initialized
INFO - 2018-03-16 19:19:56 --> Config Class Initialized
INFO - 2018-03-16 19:19:56 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:19:56 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:19:56 --> Utf8 Class Initialized
INFO - 2018-03-16 19:19:56 --> URI Class Initialized
INFO - 2018-03-16 19:19:56 --> Router Class Initialized
INFO - 2018-03-16 19:19:56 --> Output Class Initialized
INFO - 2018-03-16 19:19:56 --> Security Class Initialized
DEBUG - 2018-03-16 19:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:19:56 --> Input Class Initialized
INFO - 2018-03-16 19:19:56 --> Language Class Initialized
INFO - 2018-03-16 19:19:56 --> Loader Class Initialized
INFO - 2018-03-16 19:19:56 --> Helper loaded: url_helper
INFO - 2018-03-16 19:19:56 --> Helper loaded: site_helper
INFO - 2018-03-16 19:19:56 --> Database Driver Class Initialized
INFO - 2018-03-16 19:19:56 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:19:56 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:19:56 --> Controller Class Initialized
INFO - 2018-03-16 19:19:56 --> Model "user_model" initialized
INFO - 2018-03-16 19:19:56 --> Model "site_model" initialized
INFO - 2018-03-16 19:19:56 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:19:56 --> Final output sent to browser
DEBUG - 2018-03-16 19:19:56 --> Total execution time: 0.0710
INFO - 2018-03-16 19:21:24 --> Database Driver Class Initialized
INFO - 2018-03-16 19:21:24 --> Config Class Initialized
INFO - 2018-03-16 19:21:24 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:21:24 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:21:24 --> Utf8 Class Initialized
INFO - 2018-03-16 19:21:24 --> URI Class Initialized
INFO - 2018-03-16 19:21:24 --> Router Class Initialized
INFO - 2018-03-16 19:21:24 --> Output Class Initialized
INFO - 2018-03-16 19:21:24 --> Security Class Initialized
DEBUG - 2018-03-16 19:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:21:24 --> Input Class Initialized
INFO - 2018-03-16 19:21:24 --> Language Class Initialized
INFO - 2018-03-16 19:21:24 --> Loader Class Initialized
INFO - 2018-03-16 19:21:24 --> Helper loaded: url_helper
INFO - 2018-03-16 19:21:24 --> Helper loaded: site_helper
INFO - 2018-03-16 19:21:24 --> Database Driver Class Initialized
INFO - 2018-03-16 19:21:24 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:21:24 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:21:24 --> Controller Class Initialized
INFO - 2018-03-16 19:21:24 --> Model "user_model" initialized
INFO - 2018-03-16 19:21:24 --> Model "site_model" initialized
INFO - 2018-03-16 19:21:24 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:21:24 --> Final output sent to browser
DEBUG - 2018-03-16 19:21:24 --> Total execution time: 0.0475
INFO - 2018-03-16 19:24:57 --> Database Driver Class Initialized
INFO - 2018-03-16 19:24:57 --> Config Class Initialized
INFO - 2018-03-16 19:24:57 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:24:57 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:24:57 --> Utf8 Class Initialized
INFO - 2018-03-16 19:24:57 --> URI Class Initialized
DEBUG - 2018-03-16 19:24:57 --> No URI present. Default controller set.
INFO - 2018-03-16 19:24:57 --> Router Class Initialized
INFO - 2018-03-16 19:24:57 --> Output Class Initialized
INFO - 2018-03-16 19:24:57 --> Security Class Initialized
DEBUG - 2018-03-16 19:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:24:57 --> Input Class Initialized
INFO - 2018-03-16 19:24:57 --> Language Class Initialized
INFO - 2018-03-16 19:24:57 --> Loader Class Initialized
INFO - 2018-03-16 19:24:57 --> Helper loaded: url_helper
INFO - 2018-03-16 19:24:57 --> Helper loaded: site_helper
INFO - 2018-03-16 19:24:57 --> Database Driver Class Initialized
INFO - 2018-03-16 19:24:57 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:24:57 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:24:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:24:57 --> Controller Class Initialized
INFO - 2018-03-16 19:24:57 --> User Agent Class Initialized
INFO - 2018-03-16 19:24:57 --> Model "site_model" initialized
INFO - 2018-03-16 19:24:57 --> Model "user_model" initialized
INFO - 2018-03-16 19:24:57 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 19:24:57 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 19:24:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 19:24:57 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 19:24:57 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 19:24:57 --> Final output sent to browser
DEBUG - 2018-03-16 19:24:57 --> Total execution time: 0.0750
INFO - 2018-03-16 19:25:00 --> Database Driver Class Initialized
INFO - 2018-03-16 19:25:00 --> Config Class Initialized
INFO - 2018-03-16 19:25:00 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:25:00 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:25:00 --> Utf8 Class Initialized
INFO - 2018-03-16 19:25:00 --> URI Class Initialized
INFO - 2018-03-16 19:25:00 --> Router Class Initialized
INFO - 2018-03-16 19:25:00 --> Output Class Initialized
INFO - 2018-03-16 19:25:00 --> Security Class Initialized
DEBUG - 2018-03-16 19:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:25:00 --> Input Class Initialized
INFO - 2018-03-16 19:25:00 --> Language Class Initialized
INFO - 2018-03-16 19:25:00 --> Loader Class Initialized
INFO - 2018-03-16 19:25:00 --> Helper loaded: url_helper
INFO - 2018-03-16 19:25:00 --> Helper loaded: site_helper
INFO - 2018-03-16 19:25:00 --> Database Driver Class Initialized
INFO - 2018-03-16 19:25:00 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:25:00 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:25:00 --> Controller Class Initialized
INFO - 2018-03-16 19:25:00 --> Model "user_model" initialized
INFO - 2018-03-16 19:25:00 --> Model "site_model" initialized
INFO - 2018-03-16 19:25:00 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:25:00 --> Final output sent to browser
DEBUG - 2018-03-16 19:25:00 --> Total execution time: 0.0775
INFO - 2018-03-16 19:35:11 --> Database Driver Class Initialized
INFO - 2018-03-16 19:35:11 --> Config Class Initialized
INFO - 2018-03-16 19:35:11 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:35:11 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:35:11 --> Utf8 Class Initialized
INFO - 2018-03-16 19:35:11 --> URI Class Initialized
INFO - 2018-03-16 19:35:11 --> Router Class Initialized
INFO - 2018-03-16 19:35:11 --> Output Class Initialized
INFO - 2018-03-16 19:35:11 --> Security Class Initialized
DEBUG - 2018-03-16 19:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:35:11 --> Input Class Initialized
INFO - 2018-03-16 19:35:11 --> Language Class Initialized
INFO - 2018-03-16 19:35:11 --> Loader Class Initialized
INFO - 2018-03-16 19:35:11 --> Helper loaded: url_helper
INFO - 2018-03-16 19:35:11 --> Helper loaded: site_helper
INFO - 2018-03-16 19:35:11 --> Database Driver Class Initialized
INFO - 2018-03-16 19:35:11 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:35:11 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:35:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:35:11 --> Controller Class Initialized
INFO - 2018-03-16 19:35:11 --> Model "user_model" initialized
INFO - 2018-03-16 19:35:11 --> Model "site_model" initialized
INFO - 2018-03-16 19:35:11 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:35:11 --> Final output sent to browser
DEBUG - 2018-03-16 19:35:11 --> Total execution time: 0.0675
INFO - 2018-03-16 19:35:12 --> Database Driver Class Initialized
INFO - 2018-03-16 19:35:12 --> Config Class Initialized
INFO - 2018-03-16 19:35:12 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:35:12 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:35:12 --> Utf8 Class Initialized
INFO - 2018-03-16 19:35:12 --> URI Class Initialized
INFO - 2018-03-16 19:35:12 --> Router Class Initialized
INFO - 2018-03-16 19:35:12 --> Output Class Initialized
INFO - 2018-03-16 19:35:12 --> Security Class Initialized
DEBUG - 2018-03-16 19:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:35:12 --> Input Class Initialized
INFO - 2018-03-16 19:35:12 --> Language Class Initialized
INFO - 2018-03-16 19:35:12 --> Loader Class Initialized
INFO - 2018-03-16 19:35:12 --> Helper loaded: url_helper
INFO - 2018-03-16 19:35:12 --> Helper loaded: site_helper
INFO - 2018-03-16 19:35:12 --> Database Driver Class Initialized
INFO - 2018-03-16 19:35:12 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:35:12 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:35:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:35:12 --> Controller Class Initialized
INFO - 2018-03-16 19:35:12 --> Model "user_model" initialized
INFO - 2018-03-16 19:35:12 --> Model "site_model" initialized
INFO - 2018-03-16 19:35:12 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:35:12 --> Final output sent to browser
DEBUG - 2018-03-16 19:35:12 --> Total execution time: 0.0575
INFO - 2018-03-16 19:35:13 --> Database Driver Class Initialized
INFO - 2018-03-16 19:35:13 --> Config Class Initialized
INFO - 2018-03-16 19:35:13 --> Hooks Class Initialized
DEBUG - 2018-03-16 19:35:13 --> UTF-8 Support Enabled
INFO - 2018-03-16 19:35:13 --> Utf8 Class Initialized
INFO - 2018-03-16 19:35:13 --> URI Class Initialized
INFO - 2018-03-16 19:35:13 --> Router Class Initialized
INFO - 2018-03-16 19:35:13 --> Output Class Initialized
INFO - 2018-03-16 19:35:13 --> Security Class Initialized
DEBUG - 2018-03-16 19:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 19:35:13 --> Input Class Initialized
INFO - 2018-03-16 19:35:13 --> Language Class Initialized
INFO - 2018-03-16 19:35:13 --> Loader Class Initialized
INFO - 2018-03-16 19:35:13 --> Helper loaded: url_helper
INFO - 2018-03-16 19:35:13 --> Helper loaded: site_helper
INFO - 2018-03-16 19:35:13 --> Database Driver Class Initialized
INFO - 2018-03-16 19:35:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 19:35:13 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 19:35:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 19:35:13 --> Controller Class Initialized
INFO - 2018-03-16 19:35:13 --> Model "user_model" initialized
INFO - 2018-03-16 19:35:13 --> Model "site_model" initialized
INFO - 2018-03-16 19:35:13 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 19:35:13 --> Final output sent to browser
DEBUG - 2018-03-16 19:35:13 --> Total execution time: 0.0650
INFO - 2018-03-16 20:07:39 --> Database Driver Class Initialized
INFO - 2018-03-16 20:07:39 --> Config Class Initialized
INFO - 2018-03-16 20:07:39 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:07:39 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:07:39 --> Utf8 Class Initialized
INFO - 2018-03-16 20:07:39 --> URI Class Initialized
DEBUG - 2018-03-16 20:07:39 --> No URI present. Default controller set.
INFO - 2018-03-16 20:07:39 --> Router Class Initialized
INFO - 2018-03-16 20:07:39 --> Output Class Initialized
INFO - 2018-03-16 20:07:39 --> Security Class Initialized
DEBUG - 2018-03-16 20:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:07:39 --> Input Class Initialized
INFO - 2018-03-16 20:07:39 --> Language Class Initialized
INFO - 2018-03-16 20:07:39 --> Loader Class Initialized
INFO - 2018-03-16 20:07:39 --> Helper loaded: url_helper
INFO - 2018-03-16 20:07:39 --> Helper loaded: site_helper
INFO - 2018-03-16 20:07:39 --> Database Driver Class Initialized
INFO - 2018-03-16 20:07:39 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:07:39 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:07:39 --> Controller Class Initialized
INFO - 2018-03-16 20:07:39 --> User Agent Class Initialized
INFO - 2018-03-16 20:07:39 --> Model "site_model" initialized
INFO - 2018-03-16 20:07:39 --> Model "user_model" initialized
INFO - 2018-03-16 20:07:39 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:07:40 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:07:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:07:40 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:07:40 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:07:40 --> Final output sent to browser
DEBUG - 2018-03-16 20:07:40 --> Total execution time: 0.8265
INFO - 2018-03-16 20:07:43 --> Database Driver Class Initialized
INFO - 2018-03-16 20:07:43 --> Config Class Initialized
INFO - 2018-03-16 20:07:43 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:07:43 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:07:43 --> Utf8 Class Initialized
INFO - 2018-03-16 20:07:43 --> URI Class Initialized
INFO - 2018-03-16 20:07:43 --> Router Class Initialized
INFO - 2018-03-16 20:07:43 --> Output Class Initialized
INFO - 2018-03-16 20:07:43 --> Security Class Initialized
DEBUG - 2018-03-16 20:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:07:43 --> Input Class Initialized
INFO - 2018-03-16 20:07:43 --> Language Class Initialized
INFO - 2018-03-16 20:07:43 --> Loader Class Initialized
INFO - 2018-03-16 20:07:43 --> Helper loaded: url_helper
INFO - 2018-03-16 20:07:43 --> Helper loaded: site_helper
INFO - 2018-03-16 20:07:43 --> Database Driver Class Initialized
INFO - 2018-03-16 20:07:43 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:07:43 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:07:43 --> Controller Class Initialized
INFO - 2018-03-16 20:07:43 --> Model "user_model" initialized
INFO - 2018-03-16 20:07:43 --> Model "site_model" initialized
INFO - 2018-03-16 20:07:43 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 20:07:43 --> Final output sent to browser
DEBUG - 2018-03-16 20:07:43 --> Total execution time: 0.0650
INFO - 2018-03-16 20:07:45 --> Database Driver Class Initialized
INFO - 2018-03-16 20:07:45 --> Config Class Initialized
INFO - 2018-03-16 20:07:45 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:07:45 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:07:45 --> Utf8 Class Initialized
INFO - 2018-03-16 20:07:45 --> URI Class Initialized
INFO - 2018-03-16 20:07:45 --> Router Class Initialized
INFO - 2018-03-16 20:07:45 --> Output Class Initialized
INFO - 2018-03-16 20:07:45 --> Security Class Initialized
DEBUG - 2018-03-16 20:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:07:45 --> Input Class Initialized
INFO - 2018-03-16 20:07:45 --> Language Class Initialized
INFO - 2018-03-16 20:07:45 --> Loader Class Initialized
INFO - 2018-03-16 20:07:45 --> Helper loaded: url_helper
INFO - 2018-03-16 20:07:45 --> Helper loaded: site_helper
INFO - 2018-03-16 20:07:45 --> Database Driver Class Initialized
INFO - 2018-03-16 20:07:45 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:07:45 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:07:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:07:45 --> Controller Class Initialized
INFO - 2018-03-16 20:07:45 --> Model "user_model" initialized
INFO - 2018-03-16 20:07:45 --> Model "site_model" initialized
INFO - 2018-03-16 20:07:45 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 20:07:45 --> Final output sent to browser
DEBUG - 2018-03-16 20:07:45 --> Total execution time: 0.0655
INFO - 2018-03-16 20:08:44 --> Database Driver Class Initialized
INFO - 2018-03-16 20:08:44 --> Config Class Initialized
INFO - 2018-03-16 20:08:44 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:08:44 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:08:44 --> Utf8 Class Initialized
INFO - 2018-03-16 20:08:44 --> URI Class Initialized
DEBUG - 2018-03-16 20:08:44 --> No URI present. Default controller set.
INFO - 2018-03-16 20:08:44 --> Router Class Initialized
INFO - 2018-03-16 20:08:44 --> Output Class Initialized
INFO - 2018-03-16 20:08:44 --> Security Class Initialized
DEBUG - 2018-03-16 20:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:08:44 --> Input Class Initialized
INFO - 2018-03-16 20:08:44 --> Language Class Initialized
INFO - 2018-03-16 20:08:44 --> Loader Class Initialized
INFO - 2018-03-16 20:08:44 --> Helper loaded: url_helper
INFO - 2018-03-16 20:08:44 --> Helper loaded: site_helper
INFO - 2018-03-16 20:08:44 --> Database Driver Class Initialized
INFO - 2018-03-16 20:08:44 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:08:44 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:08:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:08:44 --> Controller Class Initialized
INFO - 2018-03-16 20:08:44 --> User Agent Class Initialized
INFO - 2018-03-16 20:08:44 --> Model "site_model" initialized
INFO - 2018-03-16 20:08:44 --> Model "user_model" initialized
INFO - 2018-03-16 20:08:44 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:08:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:08:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:08:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:08:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:08:44 --> Final output sent to browser
DEBUG - 2018-03-16 20:08:44 --> Total execution time: 0.0825
INFO - 2018-03-16 20:08:46 --> Database Driver Class Initialized
INFO - 2018-03-16 20:08:46 --> Config Class Initialized
INFO - 2018-03-16 20:08:46 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:08:46 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:08:46 --> Utf8 Class Initialized
INFO - 2018-03-16 20:08:46 --> URI Class Initialized
INFO - 2018-03-16 20:08:46 --> Router Class Initialized
INFO - 2018-03-16 20:08:46 --> Output Class Initialized
INFO - 2018-03-16 20:08:46 --> Security Class Initialized
DEBUG - 2018-03-16 20:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:08:46 --> Input Class Initialized
INFO - 2018-03-16 20:08:46 --> Language Class Initialized
INFO - 2018-03-16 20:08:46 --> Loader Class Initialized
INFO - 2018-03-16 20:08:46 --> Helper loaded: url_helper
INFO - 2018-03-16 20:08:46 --> Helper loaded: site_helper
INFO - 2018-03-16 20:08:46 --> Database Driver Class Initialized
INFO - 2018-03-16 20:08:46 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:08:46 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:08:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:08:46 --> Controller Class Initialized
INFO - 2018-03-16 20:08:46 --> Model "user_model" initialized
INFO - 2018-03-16 20:08:46 --> Model "site_model" initialized
INFO - 2018-03-16 20:08:46 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 20:08:46 --> Final output sent to browser
DEBUG - 2018-03-16 20:08:46 --> Total execution time: 0.0775
INFO - 2018-03-16 20:52:03 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:03 --> Config Class Initialized
INFO - 2018-03-16 20:52:03 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:52:03 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:52:03 --> Utf8 Class Initialized
INFO - 2018-03-16 20:52:03 --> URI Class Initialized
DEBUG - 2018-03-16 20:52:03 --> No URI present. Default controller set.
INFO - 2018-03-16 20:52:03 --> Router Class Initialized
INFO - 2018-03-16 20:52:03 --> Output Class Initialized
INFO - 2018-03-16 20:52:03 --> Security Class Initialized
DEBUG - 2018-03-16 20:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:52:03 --> Input Class Initialized
INFO - 2018-03-16 20:52:03 --> Language Class Initialized
INFO - 2018-03-16 20:52:03 --> Loader Class Initialized
INFO - 2018-03-16 20:52:03 --> Helper loaded: url_helper
INFO - 2018-03-16 20:52:03 --> Helper loaded: site_helper
INFO - 2018-03-16 20:52:03 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:03 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:52:03 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:52:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:52:03 --> Controller Class Initialized
INFO - 2018-03-16 20:52:03 --> User Agent Class Initialized
INFO - 2018-03-16 20:52:03 --> Model "site_model" initialized
INFO - 2018-03-16 20:52:03 --> Model "user_model" initialized
INFO - 2018-03-16 20:52:03 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:52:03 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:52:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:52:03 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:52:03 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:52:03 --> Final output sent to browser
DEBUG - 2018-03-16 20:52:03 --> Total execution time: 0.0410
INFO - 2018-03-16 20:52:25 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:25 --> Config Class Initialized
INFO - 2018-03-16 20:52:25 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:52:25 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:52:25 --> Utf8 Class Initialized
INFO - 2018-03-16 20:52:25 --> URI Class Initialized
DEBUG - 2018-03-16 20:52:25 --> No URI present. Default controller set.
INFO - 2018-03-16 20:52:25 --> Router Class Initialized
INFO - 2018-03-16 20:52:25 --> Output Class Initialized
INFO - 2018-03-16 20:52:25 --> Security Class Initialized
DEBUG - 2018-03-16 20:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:52:25 --> Input Class Initialized
INFO - 2018-03-16 20:52:25 --> Language Class Initialized
INFO - 2018-03-16 20:52:25 --> Loader Class Initialized
INFO - 2018-03-16 20:52:25 --> Helper loaded: url_helper
INFO - 2018-03-16 20:52:25 --> Helper loaded: site_helper
INFO - 2018-03-16 20:52:25 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:25 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:52:25 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:52:25 --> Controller Class Initialized
INFO - 2018-03-16 20:52:25 --> User Agent Class Initialized
INFO - 2018-03-16 20:52:25 --> Model "site_model" initialized
INFO - 2018-03-16 20:52:25 --> Model "user_model" initialized
INFO - 2018-03-16 20:52:25 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:52:25 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:52:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:52:25 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:52:25 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:52:25 --> Final output sent to browser
DEBUG - 2018-03-16 20:52:25 --> Total execution time: 0.0640
INFO - 2018-03-16 20:52:28 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:28 --> Config Class Initialized
INFO - 2018-03-16 20:52:28 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:52:28 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:52:28 --> Utf8 Class Initialized
INFO - 2018-03-16 20:52:28 --> URI Class Initialized
DEBUG - 2018-03-16 20:52:28 --> No URI present. Default controller set.
INFO - 2018-03-16 20:52:28 --> Router Class Initialized
INFO - 2018-03-16 20:52:28 --> Output Class Initialized
INFO - 2018-03-16 20:52:28 --> Security Class Initialized
DEBUG - 2018-03-16 20:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:52:28 --> Input Class Initialized
INFO - 2018-03-16 20:52:28 --> Language Class Initialized
INFO - 2018-03-16 20:52:28 --> Loader Class Initialized
INFO - 2018-03-16 20:52:28 --> Helper loaded: url_helper
INFO - 2018-03-16 20:52:28 --> Helper loaded: site_helper
INFO - 2018-03-16 20:52:28 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:28 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:52:28 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:52:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:52:28 --> Controller Class Initialized
INFO - 2018-03-16 20:52:28 --> User Agent Class Initialized
INFO - 2018-03-16 20:52:28 --> Model "site_model" initialized
INFO - 2018-03-16 20:52:28 --> Model "user_model" initialized
INFO - 2018-03-16 20:52:28 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:52:28 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:52:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:52:28 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:52:28 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:52:28 --> Final output sent to browser
DEBUG - 2018-03-16 20:52:28 --> Total execution time: 0.0510
INFO - 2018-03-16 20:52:32 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:32 --> Config Class Initialized
INFO - 2018-03-16 20:52:32 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:52:32 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:52:32 --> Utf8 Class Initialized
INFO - 2018-03-16 20:52:32 --> URI Class Initialized
DEBUG - 2018-03-16 20:52:32 --> No URI present. Default controller set.
INFO - 2018-03-16 20:52:32 --> Router Class Initialized
INFO - 2018-03-16 20:52:32 --> Output Class Initialized
INFO - 2018-03-16 20:52:32 --> Security Class Initialized
DEBUG - 2018-03-16 20:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:52:32 --> Input Class Initialized
INFO - 2018-03-16 20:52:32 --> Language Class Initialized
INFO - 2018-03-16 20:52:32 --> Loader Class Initialized
INFO - 2018-03-16 20:52:32 --> Helper loaded: url_helper
INFO - 2018-03-16 20:52:32 --> Helper loaded: site_helper
INFO - 2018-03-16 20:52:32 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:32 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:52:32 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:52:32 --> Controller Class Initialized
INFO - 2018-03-16 20:52:32 --> User Agent Class Initialized
INFO - 2018-03-16 20:52:32 --> Model "site_model" initialized
INFO - 2018-03-16 20:52:32 --> Model "user_model" initialized
INFO - 2018-03-16 20:52:32 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:52:32 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:52:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:52:32 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:52:32 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:52:32 --> Final output sent to browser
DEBUG - 2018-03-16 20:52:32 --> Total execution time: 0.0610
INFO - 2018-03-16 20:52:35 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:35 --> Config Class Initialized
INFO - 2018-03-16 20:52:35 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:52:35 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:52:35 --> Utf8 Class Initialized
INFO - 2018-03-16 20:52:35 --> URI Class Initialized
DEBUG - 2018-03-16 20:52:35 --> No URI present. Default controller set.
INFO - 2018-03-16 20:52:35 --> Router Class Initialized
INFO - 2018-03-16 20:52:35 --> Output Class Initialized
INFO - 2018-03-16 20:52:35 --> Security Class Initialized
DEBUG - 2018-03-16 20:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:52:35 --> Input Class Initialized
INFO - 2018-03-16 20:52:35 --> Language Class Initialized
INFO - 2018-03-16 20:52:35 --> Loader Class Initialized
INFO - 2018-03-16 20:52:35 --> Helper loaded: url_helper
INFO - 2018-03-16 20:52:35 --> Helper loaded: site_helper
INFO - 2018-03-16 20:52:35 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:35 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:52:35 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:52:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:52:35 --> Controller Class Initialized
INFO - 2018-03-16 20:52:35 --> User Agent Class Initialized
INFO - 2018-03-16 20:52:35 --> Model "site_model" initialized
INFO - 2018-03-16 20:52:35 --> Model "user_model" initialized
INFO - 2018-03-16 20:52:35 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:52:35 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:52:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:52:35 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:52:35 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:52:35 --> Final output sent to browser
DEBUG - 2018-03-16 20:52:35 --> Total execution time: 0.0780
INFO - 2018-03-16 20:52:39 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:39 --> Config Class Initialized
INFO - 2018-03-16 20:52:39 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:52:39 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:52:39 --> Utf8 Class Initialized
INFO - 2018-03-16 20:52:39 --> URI Class Initialized
DEBUG - 2018-03-16 20:52:39 --> No URI present. Default controller set.
INFO - 2018-03-16 20:52:39 --> Router Class Initialized
INFO - 2018-03-16 20:52:39 --> Output Class Initialized
INFO - 2018-03-16 20:52:39 --> Security Class Initialized
DEBUG - 2018-03-16 20:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:52:39 --> Input Class Initialized
INFO - 2018-03-16 20:52:39 --> Language Class Initialized
INFO - 2018-03-16 20:52:39 --> Loader Class Initialized
INFO - 2018-03-16 20:52:39 --> Helper loaded: url_helper
INFO - 2018-03-16 20:52:39 --> Helper loaded: site_helper
INFO - 2018-03-16 20:52:39 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:39 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:52:39 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:52:39 --> Controller Class Initialized
INFO - 2018-03-16 20:52:39 --> User Agent Class Initialized
INFO - 2018-03-16 20:52:39 --> Model "site_model" initialized
INFO - 2018-03-16 20:52:39 --> Model "user_model" initialized
INFO - 2018-03-16 20:52:39 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:52:39 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:52:39 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:52:39 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:52:39 --> Final output sent to browser
DEBUG - 2018-03-16 20:52:39 --> Total execution time: 0.0880
INFO - 2018-03-16 20:52:42 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:42 --> Config Class Initialized
INFO - 2018-03-16 20:52:42 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:52:42 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:52:42 --> Utf8 Class Initialized
INFO - 2018-03-16 20:52:42 --> URI Class Initialized
DEBUG - 2018-03-16 20:52:42 --> No URI present. Default controller set.
INFO - 2018-03-16 20:52:42 --> Router Class Initialized
INFO - 2018-03-16 20:52:42 --> Output Class Initialized
INFO - 2018-03-16 20:52:42 --> Security Class Initialized
DEBUG - 2018-03-16 20:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:52:42 --> Input Class Initialized
INFO - 2018-03-16 20:52:42 --> Language Class Initialized
INFO - 2018-03-16 20:52:42 --> Loader Class Initialized
INFO - 2018-03-16 20:52:42 --> Helper loaded: url_helper
INFO - 2018-03-16 20:52:42 --> Helper loaded: site_helper
INFO - 2018-03-16 20:52:42 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:42 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:52:42 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:52:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:52:42 --> Controller Class Initialized
INFO - 2018-03-16 20:52:42 --> User Agent Class Initialized
INFO - 2018-03-16 20:52:42 --> Model "site_model" initialized
INFO - 2018-03-16 20:52:42 --> Model "user_model" initialized
INFO - 2018-03-16 20:52:42 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:52:42 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:52:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:52:42 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:52:42 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:52:42 --> Final output sent to browser
DEBUG - 2018-03-16 20:52:42 --> Total execution time: 0.0420
INFO - 2018-03-16 20:52:44 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:44 --> Config Class Initialized
INFO - 2018-03-16 20:52:44 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:52:44 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:52:44 --> Utf8 Class Initialized
INFO - 2018-03-16 20:52:44 --> URI Class Initialized
DEBUG - 2018-03-16 20:52:44 --> No URI present. Default controller set.
INFO - 2018-03-16 20:52:44 --> Router Class Initialized
INFO - 2018-03-16 20:52:44 --> Output Class Initialized
INFO - 2018-03-16 20:52:44 --> Security Class Initialized
DEBUG - 2018-03-16 20:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:52:44 --> Input Class Initialized
INFO - 2018-03-16 20:52:44 --> Language Class Initialized
INFO - 2018-03-16 20:52:44 --> Loader Class Initialized
INFO - 2018-03-16 20:52:44 --> Helper loaded: url_helper
INFO - 2018-03-16 20:52:44 --> Helper loaded: site_helper
INFO - 2018-03-16 20:52:44 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:44 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:52:44 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:52:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:52:44 --> Controller Class Initialized
INFO - 2018-03-16 20:52:44 --> User Agent Class Initialized
INFO - 2018-03-16 20:52:44 --> Model "site_model" initialized
INFO - 2018-03-16 20:52:44 --> Model "user_model" initialized
INFO - 2018-03-16 20:52:44 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:52:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:52:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:52:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:52:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:52:44 --> Final output sent to browser
DEBUG - 2018-03-16 20:52:44 --> Total execution time: 0.0440
INFO - 2018-03-16 20:52:47 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:47 --> Config Class Initialized
INFO - 2018-03-16 20:52:47 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:52:47 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:52:47 --> Utf8 Class Initialized
INFO - 2018-03-16 20:52:47 --> URI Class Initialized
DEBUG - 2018-03-16 20:52:47 --> No URI present. Default controller set.
INFO - 2018-03-16 20:52:47 --> Router Class Initialized
INFO - 2018-03-16 20:52:47 --> Output Class Initialized
INFO - 2018-03-16 20:52:47 --> Security Class Initialized
DEBUG - 2018-03-16 20:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:52:47 --> Input Class Initialized
INFO - 2018-03-16 20:52:47 --> Language Class Initialized
INFO - 2018-03-16 20:52:47 --> Loader Class Initialized
INFO - 2018-03-16 20:52:47 --> Helper loaded: url_helper
INFO - 2018-03-16 20:52:47 --> Helper loaded: site_helper
INFO - 2018-03-16 20:52:47 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:47 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:52:47 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:52:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:52:47 --> Controller Class Initialized
INFO - 2018-03-16 20:52:47 --> User Agent Class Initialized
INFO - 2018-03-16 20:52:47 --> Model "site_model" initialized
INFO - 2018-03-16 20:52:47 --> Model "user_model" initialized
INFO - 2018-03-16 20:52:47 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:52:47 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:52:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:52:47 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:52:47 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:52:47 --> Final output sent to browser
DEBUG - 2018-03-16 20:52:47 --> Total execution time: 0.0560
INFO - 2018-03-16 20:52:51 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:51 --> Config Class Initialized
INFO - 2018-03-16 20:52:51 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:52:51 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:52:51 --> Utf8 Class Initialized
INFO - 2018-03-16 20:52:51 --> URI Class Initialized
DEBUG - 2018-03-16 20:52:51 --> No URI present. Default controller set.
INFO - 2018-03-16 20:52:51 --> Router Class Initialized
INFO - 2018-03-16 20:52:51 --> Output Class Initialized
INFO - 2018-03-16 20:52:51 --> Security Class Initialized
DEBUG - 2018-03-16 20:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:52:51 --> Input Class Initialized
INFO - 2018-03-16 20:52:51 --> Language Class Initialized
INFO - 2018-03-16 20:52:51 --> Loader Class Initialized
INFO - 2018-03-16 20:52:51 --> Helper loaded: url_helper
INFO - 2018-03-16 20:52:51 --> Helper loaded: site_helper
INFO - 2018-03-16 20:52:51 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:51 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:52:51 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:52:51 --> Controller Class Initialized
INFO - 2018-03-16 20:52:51 --> User Agent Class Initialized
INFO - 2018-03-16 20:52:51 --> Model "site_model" initialized
INFO - 2018-03-16 20:52:51 --> Model "user_model" initialized
INFO - 2018-03-16 20:52:51 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:52:51 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:52:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:52:51 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:52:51 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:52:51 --> Final output sent to browser
DEBUG - 2018-03-16 20:52:51 --> Total execution time: 0.0490
INFO - 2018-03-16 20:52:54 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:55 --> Config Class Initialized
INFO - 2018-03-16 20:52:55 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:52:55 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:52:55 --> Utf8 Class Initialized
INFO - 2018-03-16 20:52:55 --> URI Class Initialized
DEBUG - 2018-03-16 20:52:55 --> No URI present. Default controller set.
INFO - 2018-03-16 20:52:55 --> Router Class Initialized
INFO - 2018-03-16 20:52:55 --> Output Class Initialized
INFO - 2018-03-16 20:52:55 --> Security Class Initialized
DEBUG - 2018-03-16 20:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:52:55 --> Input Class Initialized
INFO - 2018-03-16 20:52:55 --> Language Class Initialized
INFO - 2018-03-16 20:52:55 --> Loader Class Initialized
INFO - 2018-03-16 20:52:55 --> Helper loaded: url_helper
INFO - 2018-03-16 20:52:55 --> Helper loaded: site_helper
INFO - 2018-03-16 20:52:55 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:55 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:52:55 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:52:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:52:55 --> Controller Class Initialized
INFO - 2018-03-16 20:52:55 --> User Agent Class Initialized
INFO - 2018-03-16 20:52:55 --> Model "site_model" initialized
INFO - 2018-03-16 20:52:55 --> Model "user_model" initialized
INFO - 2018-03-16 20:52:55 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:52:55 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:52:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:52:55 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:52:55 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:52:55 --> Final output sent to browser
DEBUG - 2018-03-16 20:52:55 --> Total execution time: 0.0610
INFO - 2018-03-16 20:52:56 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:57 --> Config Class Initialized
INFO - 2018-03-16 20:52:57 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:52:57 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:52:57 --> Utf8 Class Initialized
INFO - 2018-03-16 20:52:57 --> URI Class Initialized
DEBUG - 2018-03-16 20:52:57 --> No URI present. Default controller set.
INFO - 2018-03-16 20:52:57 --> Router Class Initialized
INFO - 2018-03-16 20:52:57 --> Output Class Initialized
INFO - 2018-03-16 20:52:57 --> Security Class Initialized
DEBUG - 2018-03-16 20:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:52:57 --> Input Class Initialized
INFO - 2018-03-16 20:52:57 --> Language Class Initialized
INFO - 2018-03-16 20:52:57 --> Loader Class Initialized
INFO - 2018-03-16 20:52:57 --> Helper loaded: url_helper
INFO - 2018-03-16 20:52:57 --> Helper loaded: site_helper
INFO - 2018-03-16 20:52:57 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:57 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:52:57 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:52:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:52:57 --> Controller Class Initialized
INFO - 2018-03-16 20:52:57 --> User Agent Class Initialized
INFO - 2018-03-16 20:52:57 --> Model "site_model" initialized
INFO - 2018-03-16 20:52:57 --> Model "user_model" initialized
INFO - 2018-03-16 20:52:57 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:52:57 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:52:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:52:57 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:52:57 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:52:57 --> Final output sent to browser
DEBUG - 2018-03-16 20:52:57 --> Total execution time: 0.0610
INFO - 2018-03-16 20:52:58 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:58 --> Config Class Initialized
INFO - 2018-03-16 20:52:58 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:52:58 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:52:58 --> Utf8 Class Initialized
INFO - 2018-03-16 20:52:58 --> URI Class Initialized
DEBUG - 2018-03-16 20:52:58 --> No URI present. Default controller set.
INFO - 2018-03-16 20:52:58 --> Router Class Initialized
INFO - 2018-03-16 20:52:58 --> Output Class Initialized
INFO - 2018-03-16 20:52:58 --> Security Class Initialized
DEBUG - 2018-03-16 20:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:52:58 --> Input Class Initialized
INFO - 2018-03-16 20:52:58 --> Language Class Initialized
INFO - 2018-03-16 20:52:58 --> Loader Class Initialized
INFO - 2018-03-16 20:52:58 --> Helper loaded: url_helper
INFO - 2018-03-16 20:52:58 --> Helper loaded: site_helper
INFO - 2018-03-16 20:52:58 --> Database Driver Class Initialized
INFO - 2018-03-16 20:52:59 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:52:59 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:52:59 --> Controller Class Initialized
INFO - 2018-03-16 20:52:59 --> User Agent Class Initialized
INFO - 2018-03-16 20:52:59 --> Model "site_model" initialized
INFO - 2018-03-16 20:52:59 --> Model "user_model" initialized
INFO - 2018-03-16 20:52:59 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:52:59 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:52:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:52:59 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:52:59 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:52:59 --> Final output sent to browser
DEBUG - 2018-03-16 20:52:59 --> Total execution time: 0.0530
INFO - 2018-03-16 20:53:01 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:01 --> Config Class Initialized
INFO - 2018-03-16 20:53:01 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:53:01 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:53:01 --> Utf8 Class Initialized
INFO - 2018-03-16 20:53:01 --> URI Class Initialized
DEBUG - 2018-03-16 20:53:01 --> No URI present. Default controller set.
INFO - 2018-03-16 20:53:01 --> Router Class Initialized
INFO - 2018-03-16 20:53:01 --> Output Class Initialized
INFO - 2018-03-16 20:53:01 --> Security Class Initialized
DEBUG - 2018-03-16 20:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:53:01 --> Input Class Initialized
INFO - 2018-03-16 20:53:01 --> Language Class Initialized
INFO - 2018-03-16 20:53:01 --> Loader Class Initialized
INFO - 2018-03-16 20:53:01 --> Helper loaded: url_helper
INFO - 2018-03-16 20:53:01 --> Helper loaded: site_helper
INFO - 2018-03-16 20:53:01 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:01 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:53:01 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:53:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:53:01 --> Controller Class Initialized
INFO - 2018-03-16 20:53:01 --> User Agent Class Initialized
INFO - 2018-03-16 20:53:01 --> Model "site_model" initialized
INFO - 2018-03-16 20:53:01 --> Model "user_model" initialized
INFO - 2018-03-16 20:53:01 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:53:01 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:53:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:53:01 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:53:01 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:53:01 --> Final output sent to browser
DEBUG - 2018-03-16 20:53:01 --> Total execution time: 0.0550
INFO - 2018-03-16 20:53:12 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:12 --> Config Class Initialized
INFO - 2018-03-16 20:53:12 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:53:12 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:53:12 --> Utf8 Class Initialized
INFO - 2018-03-16 20:53:12 --> URI Class Initialized
DEBUG - 2018-03-16 20:53:12 --> No URI present. Default controller set.
INFO - 2018-03-16 20:53:12 --> Router Class Initialized
INFO - 2018-03-16 20:53:12 --> Output Class Initialized
INFO - 2018-03-16 20:53:12 --> Security Class Initialized
DEBUG - 2018-03-16 20:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:53:12 --> Input Class Initialized
INFO - 2018-03-16 20:53:12 --> Language Class Initialized
INFO - 2018-03-16 20:53:12 --> Loader Class Initialized
INFO - 2018-03-16 20:53:12 --> Helper loaded: url_helper
INFO - 2018-03-16 20:53:12 --> Helper loaded: site_helper
INFO - 2018-03-16 20:53:12 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:12 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:53:13 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:53:13 --> Controller Class Initialized
INFO - 2018-03-16 20:53:13 --> User Agent Class Initialized
INFO - 2018-03-16 20:53:13 --> Model "site_model" initialized
INFO - 2018-03-16 20:53:13 --> Model "user_model" initialized
INFO - 2018-03-16 20:53:13 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:53:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:53:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:53:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:53:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:53:13 --> Final output sent to browser
DEBUG - 2018-03-16 20:53:13 --> Total execution time: 0.0570
INFO - 2018-03-16 20:53:13 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:13 --> Config Class Initialized
INFO - 2018-03-16 20:53:13 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:53:13 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:53:13 --> Utf8 Class Initialized
INFO - 2018-03-16 20:53:13 --> URI Class Initialized
DEBUG - 2018-03-16 20:53:13 --> No URI present. Default controller set.
INFO - 2018-03-16 20:53:13 --> Router Class Initialized
INFO - 2018-03-16 20:53:13 --> Output Class Initialized
INFO - 2018-03-16 20:53:13 --> Security Class Initialized
DEBUG - 2018-03-16 20:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:53:13 --> Input Class Initialized
INFO - 2018-03-16 20:53:13 --> Language Class Initialized
INFO - 2018-03-16 20:53:13 --> Loader Class Initialized
INFO - 2018-03-16 20:53:13 --> Helper loaded: url_helper
INFO - 2018-03-16 20:53:13 --> Helper loaded: site_helper
INFO - 2018-03-16 20:53:13 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:53:13 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:53:13 --> Controller Class Initialized
INFO - 2018-03-16 20:53:13 --> User Agent Class Initialized
INFO - 2018-03-16 20:53:13 --> Model "site_model" initialized
INFO - 2018-03-16 20:53:13 --> Model "user_model" initialized
INFO - 2018-03-16 20:53:13 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:53:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:53:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:53:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:53:13 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:53:13 --> Final output sent to browser
DEBUG - 2018-03-16 20:53:13 --> Total execution time: 0.0500
INFO - 2018-03-16 20:53:14 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:14 --> Config Class Initialized
INFO - 2018-03-16 20:53:14 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:53:14 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:53:14 --> Utf8 Class Initialized
INFO - 2018-03-16 20:53:14 --> URI Class Initialized
DEBUG - 2018-03-16 20:53:14 --> No URI present. Default controller set.
INFO - 2018-03-16 20:53:14 --> Router Class Initialized
INFO - 2018-03-16 20:53:14 --> Output Class Initialized
INFO - 2018-03-16 20:53:14 --> Security Class Initialized
DEBUG - 2018-03-16 20:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:53:14 --> Input Class Initialized
INFO - 2018-03-16 20:53:14 --> Language Class Initialized
INFO - 2018-03-16 20:53:14 --> Loader Class Initialized
INFO - 2018-03-16 20:53:14 --> Helper loaded: url_helper
INFO - 2018-03-16 20:53:14 --> Helper loaded: site_helper
INFO - 2018-03-16 20:53:14 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:14 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:53:14 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:53:14 --> Controller Class Initialized
INFO - 2018-03-16 20:53:14 --> User Agent Class Initialized
INFO - 2018-03-16 20:53:14 --> Model "site_model" initialized
INFO - 2018-03-16 20:53:14 --> Model "user_model" initialized
INFO - 2018-03-16 20:53:14 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:53:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:53:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:53:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:53:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:53:14 --> Final output sent to browser
DEBUG - 2018-03-16 20:53:14 --> Total execution time: 0.0420
INFO - 2018-03-16 20:53:16 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:16 --> Config Class Initialized
INFO - 2018-03-16 20:53:16 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:53:16 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:53:16 --> Utf8 Class Initialized
INFO - 2018-03-16 20:53:16 --> URI Class Initialized
DEBUG - 2018-03-16 20:53:16 --> No URI present. Default controller set.
INFO - 2018-03-16 20:53:16 --> Router Class Initialized
INFO - 2018-03-16 20:53:16 --> Output Class Initialized
INFO - 2018-03-16 20:53:16 --> Security Class Initialized
DEBUG - 2018-03-16 20:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:53:16 --> Input Class Initialized
INFO - 2018-03-16 20:53:16 --> Language Class Initialized
INFO - 2018-03-16 20:53:16 --> Loader Class Initialized
INFO - 2018-03-16 20:53:16 --> Helper loaded: url_helper
INFO - 2018-03-16 20:53:16 --> Helper loaded: site_helper
INFO - 2018-03-16 20:53:16 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:16 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:53:16 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:53:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:53:16 --> Controller Class Initialized
INFO - 2018-03-16 20:53:16 --> User Agent Class Initialized
INFO - 2018-03-16 20:53:16 --> Model "site_model" initialized
INFO - 2018-03-16 20:53:16 --> Model "user_model" initialized
INFO - 2018-03-16 20:53:16 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:53:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:53:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:53:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:53:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:53:16 --> Final output sent to browser
DEBUG - 2018-03-16 20:53:16 --> Total execution time: 0.0560
INFO - 2018-03-16 20:53:38 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:38 --> Config Class Initialized
INFO - 2018-03-16 20:53:38 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:53:38 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:53:38 --> Utf8 Class Initialized
INFO - 2018-03-16 20:53:38 --> URI Class Initialized
DEBUG - 2018-03-16 20:53:38 --> No URI present. Default controller set.
INFO - 2018-03-16 20:53:38 --> Router Class Initialized
INFO - 2018-03-16 20:53:38 --> Output Class Initialized
INFO - 2018-03-16 20:53:38 --> Security Class Initialized
DEBUG - 2018-03-16 20:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:53:38 --> Input Class Initialized
INFO - 2018-03-16 20:53:38 --> Language Class Initialized
INFO - 2018-03-16 20:53:38 --> Loader Class Initialized
INFO - 2018-03-16 20:53:38 --> Helper loaded: url_helper
INFO - 2018-03-16 20:53:38 --> Helper loaded: site_helper
INFO - 2018-03-16 20:53:38 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:38 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:53:38 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:53:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:53:38 --> Controller Class Initialized
INFO - 2018-03-16 20:53:38 --> User Agent Class Initialized
INFO - 2018-03-16 20:53:38 --> Model "site_model" initialized
INFO - 2018-03-16 20:53:38 --> Model "user_model" initialized
INFO - 2018-03-16 20:53:38 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:53:38 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:53:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:53:38 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:53:38 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:53:38 --> Final output sent to browser
DEBUG - 2018-03-16 20:53:38 --> Total execution time: 0.0430
INFO - 2018-03-16 20:53:41 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:41 --> Config Class Initialized
INFO - 2018-03-16 20:53:41 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:53:41 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:53:41 --> Utf8 Class Initialized
INFO - 2018-03-16 20:53:41 --> URI Class Initialized
DEBUG - 2018-03-16 20:53:41 --> No URI present. Default controller set.
INFO - 2018-03-16 20:53:41 --> Router Class Initialized
INFO - 2018-03-16 20:53:41 --> Output Class Initialized
INFO - 2018-03-16 20:53:41 --> Security Class Initialized
DEBUG - 2018-03-16 20:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:53:41 --> Input Class Initialized
INFO - 2018-03-16 20:53:41 --> Language Class Initialized
INFO - 2018-03-16 20:53:41 --> Loader Class Initialized
INFO - 2018-03-16 20:53:41 --> Helper loaded: url_helper
INFO - 2018-03-16 20:53:41 --> Helper loaded: site_helper
INFO - 2018-03-16 20:53:41 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:41 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:53:41 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:53:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:53:41 --> Controller Class Initialized
INFO - 2018-03-16 20:53:41 --> User Agent Class Initialized
INFO - 2018-03-16 20:53:41 --> Model "site_model" initialized
INFO - 2018-03-16 20:53:41 --> Model "user_model" initialized
INFO - 2018-03-16 20:53:41 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:53:41 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:53:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:53:41 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:53:41 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:53:41 --> Final output sent to browser
DEBUG - 2018-03-16 20:53:41 --> Total execution time: 0.0520
INFO - 2018-03-16 20:53:49 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:49 --> Config Class Initialized
INFO - 2018-03-16 20:53:49 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:53:49 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:53:49 --> Utf8 Class Initialized
INFO - 2018-03-16 20:53:49 --> URI Class Initialized
DEBUG - 2018-03-16 20:53:49 --> No URI present. Default controller set.
INFO - 2018-03-16 20:53:49 --> Router Class Initialized
INFO - 2018-03-16 20:53:49 --> Output Class Initialized
INFO - 2018-03-16 20:53:49 --> Security Class Initialized
DEBUG - 2018-03-16 20:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:53:49 --> Input Class Initialized
INFO - 2018-03-16 20:53:49 --> Language Class Initialized
INFO - 2018-03-16 20:53:49 --> Loader Class Initialized
INFO - 2018-03-16 20:53:49 --> Helper loaded: url_helper
INFO - 2018-03-16 20:53:49 --> Helper loaded: site_helper
INFO - 2018-03-16 20:53:49 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:49 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:53:49 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:53:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:53:49 --> Controller Class Initialized
INFO - 2018-03-16 20:53:49 --> User Agent Class Initialized
INFO - 2018-03-16 20:53:49 --> Model "site_model" initialized
INFO - 2018-03-16 20:53:49 --> Model "user_model" initialized
INFO - 2018-03-16 20:53:49 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:53:49 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:53:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:53:49 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:53:49 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:53:49 --> Final output sent to browser
DEBUG - 2018-03-16 20:53:49 --> Total execution time: 0.0520
INFO - 2018-03-16 20:53:50 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:50 --> Config Class Initialized
INFO - 2018-03-16 20:53:50 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:53:50 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:53:50 --> Utf8 Class Initialized
INFO - 2018-03-16 20:53:50 --> URI Class Initialized
DEBUG - 2018-03-16 20:53:50 --> No URI present. Default controller set.
INFO - 2018-03-16 20:53:50 --> Router Class Initialized
INFO - 2018-03-16 20:53:50 --> Output Class Initialized
INFO - 2018-03-16 20:53:50 --> Security Class Initialized
DEBUG - 2018-03-16 20:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:53:50 --> Input Class Initialized
INFO - 2018-03-16 20:53:50 --> Language Class Initialized
INFO - 2018-03-16 20:53:50 --> Loader Class Initialized
INFO - 2018-03-16 20:53:50 --> Helper loaded: url_helper
INFO - 2018-03-16 20:53:50 --> Helper loaded: site_helper
INFO - 2018-03-16 20:53:50 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:50 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:53:50 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:53:50 --> Controller Class Initialized
INFO - 2018-03-16 20:53:50 --> User Agent Class Initialized
INFO - 2018-03-16 20:53:50 --> Model "site_model" initialized
INFO - 2018-03-16 20:53:50 --> Model "user_model" initialized
INFO - 2018-03-16 20:53:50 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:53:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:53:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:53:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:53:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:53:50 --> Final output sent to browser
DEBUG - 2018-03-16 20:53:50 --> Total execution time: 0.0530
INFO - 2018-03-16 20:53:51 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:51 --> Config Class Initialized
INFO - 2018-03-16 20:53:51 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:53:51 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:53:51 --> Utf8 Class Initialized
INFO - 2018-03-16 20:53:51 --> URI Class Initialized
DEBUG - 2018-03-16 20:53:51 --> No URI present. Default controller set.
INFO - 2018-03-16 20:53:51 --> Router Class Initialized
INFO - 2018-03-16 20:53:51 --> Output Class Initialized
INFO - 2018-03-16 20:53:51 --> Security Class Initialized
DEBUG - 2018-03-16 20:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:53:51 --> Input Class Initialized
INFO - 2018-03-16 20:53:51 --> Language Class Initialized
INFO - 2018-03-16 20:53:51 --> Loader Class Initialized
INFO - 2018-03-16 20:53:51 --> Helper loaded: url_helper
INFO - 2018-03-16 20:53:51 --> Helper loaded: site_helper
INFO - 2018-03-16 20:53:51 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:51 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:53:51 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:53:51 --> Controller Class Initialized
INFO - 2018-03-16 20:53:51 --> User Agent Class Initialized
INFO - 2018-03-16 20:53:51 --> Model "site_model" initialized
INFO - 2018-03-16 20:53:51 --> Model "user_model" initialized
INFO - 2018-03-16 20:53:51 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:53:51 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:53:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:53:51 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:53:51 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:53:51 --> Final output sent to browser
DEBUG - 2018-03-16 20:53:51 --> Total execution time: 0.0440
INFO - 2018-03-16 20:53:54 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:54 --> Config Class Initialized
INFO - 2018-03-16 20:53:54 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:53:54 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:53:54 --> Utf8 Class Initialized
INFO - 2018-03-16 20:53:54 --> URI Class Initialized
DEBUG - 2018-03-16 20:53:54 --> No URI present. Default controller set.
INFO - 2018-03-16 20:53:54 --> Router Class Initialized
INFO - 2018-03-16 20:53:54 --> Output Class Initialized
INFO - 2018-03-16 20:53:54 --> Security Class Initialized
DEBUG - 2018-03-16 20:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:53:54 --> Input Class Initialized
INFO - 2018-03-16 20:53:54 --> Language Class Initialized
INFO - 2018-03-16 20:53:54 --> Loader Class Initialized
INFO - 2018-03-16 20:53:54 --> Helper loaded: url_helper
INFO - 2018-03-16 20:53:54 --> Helper loaded: site_helper
INFO - 2018-03-16 20:53:54 --> Database Driver Class Initialized
INFO - 2018-03-16 20:53:54 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:53:54 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:53:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:53:54 --> Controller Class Initialized
INFO - 2018-03-16 20:53:54 --> User Agent Class Initialized
INFO - 2018-03-16 20:53:54 --> Model "site_model" initialized
INFO - 2018-03-16 20:53:54 --> Model "user_model" initialized
INFO - 2018-03-16 20:53:54 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:53:54 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:53:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:53:54 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:53:54 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:53:54 --> Final output sent to browser
DEBUG - 2018-03-16 20:53:54 --> Total execution time: 0.0510
INFO - 2018-03-16 20:54:03 --> Database Driver Class Initialized
INFO - 2018-03-16 20:54:03 --> Config Class Initialized
INFO - 2018-03-16 20:54:03 --> Hooks Class Initialized
DEBUG - 2018-03-16 20:54:03 --> UTF-8 Support Enabled
INFO - 2018-03-16 20:54:03 --> Utf8 Class Initialized
INFO - 2018-03-16 20:54:03 --> URI Class Initialized
DEBUG - 2018-03-16 20:54:03 --> No URI present. Default controller set.
INFO - 2018-03-16 20:54:03 --> Router Class Initialized
INFO - 2018-03-16 20:54:03 --> Output Class Initialized
INFO - 2018-03-16 20:54:03 --> Security Class Initialized
DEBUG - 2018-03-16 20:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 20:54:03 --> Input Class Initialized
INFO - 2018-03-16 20:54:03 --> Language Class Initialized
INFO - 2018-03-16 20:54:03 --> Loader Class Initialized
INFO - 2018-03-16 20:54:03 --> Helper loaded: url_helper
INFO - 2018-03-16 20:54:03 --> Helper loaded: site_helper
INFO - 2018-03-16 20:54:03 --> Database Driver Class Initialized
INFO - 2018-03-16 20:54:03 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 20:54:03 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 20:54:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 20:54:03 --> Controller Class Initialized
INFO - 2018-03-16 20:54:03 --> User Agent Class Initialized
INFO - 2018-03-16 20:54:03 --> Model "site_model" initialized
INFO - 2018-03-16 20:54:03 --> Model "user_model" initialized
INFO - 2018-03-16 20:54:03 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 20:54:03 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 20:54:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 20:54:03 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 20:54:03 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 20:54:03 --> Final output sent to browser
DEBUG - 2018-03-16 20:54:03 --> Total execution time: 0.0410
INFO - 2018-03-16 21:19:35 --> Database Driver Class Initialized
INFO - 2018-03-16 21:19:35 --> Config Class Initialized
INFO - 2018-03-16 21:19:35 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:19:35 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:19:35 --> Utf8 Class Initialized
INFO - 2018-03-16 21:19:35 --> URI Class Initialized
DEBUG - 2018-03-16 21:19:35 --> No URI present. Default controller set.
INFO - 2018-03-16 21:19:35 --> Router Class Initialized
INFO - 2018-03-16 21:19:35 --> Output Class Initialized
INFO - 2018-03-16 21:19:35 --> Security Class Initialized
DEBUG - 2018-03-16 21:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:19:35 --> Input Class Initialized
INFO - 2018-03-16 21:19:35 --> Language Class Initialized
INFO - 2018-03-16 21:19:35 --> Loader Class Initialized
INFO - 2018-03-16 21:19:35 --> Helper loaded: url_helper
INFO - 2018-03-16 21:19:35 --> Helper loaded: site_helper
INFO - 2018-03-16 21:19:35 --> Database Driver Class Initialized
INFO - 2018-03-16 21:19:35 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:19:35 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:19:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:19:35 --> Controller Class Initialized
INFO - 2018-03-16 21:19:35 --> User Agent Class Initialized
INFO - 2018-03-16 21:19:35 --> Model "site_model" initialized
INFO - 2018-03-16 21:19:35 --> Model "user_model" initialized
INFO - 2018-03-16 21:19:35 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:19:35 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:19:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 21:19:35 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:19:35 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:19:35 --> Final output sent to browser
DEBUG - 2018-03-16 21:19:35 --> Total execution time: 0.0860
INFO - 2018-03-16 21:19:35 --> Database Driver Class Initialized
INFO - 2018-03-16 21:19:35 --> Config Class Initialized
INFO - 2018-03-16 21:19:35 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:19:35 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:19:35 --> Utf8 Class Initialized
INFO - 2018-03-16 21:19:35 --> URI Class Initialized
DEBUG - 2018-03-16 21:19:35 --> No URI present. Default controller set.
INFO - 2018-03-16 21:19:35 --> Router Class Initialized
INFO - 2018-03-16 21:19:35 --> Output Class Initialized
INFO - 2018-03-16 21:19:35 --> Security Class Initialized
DEBUG - 2018-03-16 21:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:19:35 --> Input Class Initialized
INFO - 2018-03-16 21:19:35 --> Language Class Initialized
INFO - 2018-03-16 21:19:35 --> Loader Class Initialized
INFO - 2018-03-16 21:19:35 --> Helper loaded: url_helper
INFO - 2018-03-16 21:19:35 --> Helper loaded: site_helper
INFO - 2018-03-16 21:19:35 --> Database Driver Class Initialized
INFO - 2018-03-16 21:19:35 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:19:35 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:19:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:19:35 --> Controller Class Initialized
INFO - 2018-03-16 21:19:35 --> User Agent Class Initialized
INFO - 2018-03-16 21:19:35 --> Model "site_model" initialized
INFO - 2018-03-16 21:19:35 --> Model "user_model" initialized
INFO - 2018-03-16 21:19:35 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:19:35 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:19:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 21:19:35 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:19:35 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:19:35 --> Final output sent to browser
DEBUG - 2018-03-16 21:19:35 --> Total execution time: 0.0810
INFO - 2018-03-16 21:19:36 --> Database Driver Class Initialized
INFO - 2018-03-16 21:19:36 --> Config Class Initialized
INFO - 2018-03-16 21:19:36 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:19:36 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:19:36 --> Utf8 Class Initialized
INFO - 2018-03-16 21:19:36 --> URI Class Initialized
DEBUG - 2018-03-16 21:19:36 --> No URI present. Default controller set.
INFO - 2018-03-16 21:19:36 --> Router Class Initialized
INFO - 2018-03-16 21:19:36 --> Output Class Initialized
INFO - 2018-03-16 21:19:36 --> Security Class Initialized
DEBUG - 2018-03-16 21:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:19:36 --> Input Class Initialized
INFO - 2018-03-16 21:19:36 --> Language Class Initialized
INFO - 2018-03-16 21:19:36 --> Loader Class Initialized
INFO - 2018-03-16 21:19:36 --> Helper loaded: url_helper
INFO - 2018-03-16 21:19:36 --> Helper loaded: site_helper
INFO - 2018-03-16 21:19:36 --> Database Driver Class Initialized
INFO - 2018-03-16 21:19:36 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:19:36 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:19:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:19:36 --> Controller Class Initialized
INFO - 2018-03-16 21:19:36 --> User Agent Class Initialized
INFO - 2018-03-16 21:19:36 --> Model "site_model" initialized
INFO - 2018-03-16 21:19:36 --> Model "user_model" initialized
INFO - 2018-03-16 21:19:36 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:19:36 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:19:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 21:19:36 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:19:36 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:19:36 --> Final output sent to browser
DEBUG - 2018-03-16 21:19:36 --> Total execution time: 0.0430
INFO - 2018-03-16 21:21:13 --> Database Driver Class Initialized
INFO - 2018-03-16 21:21:13 --> Config Class Initialized
INFO - 2018-03-16 21:21:13 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:21:13 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:21:13 --> Utf8 Class Initialized
INFO - 2018-03-16 21:21:13 --> URI Class Initialized
DEBUG - 2018-03-16 21:21:13 --> No URI present. Default controller set.
INFO - 2018-03-16 21:21:13 --> Router Class Initialized
INFO - 2018-03-16 21:21:13 --> Output Class Initialized
INFO - 2018-03-16 21:21:13 --> Security Class Initialized
DEBUG - 2018-03-16 21:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:21:13 --> Input Class Initialized
INFO - 2018-03-16 21:21:13 --> Language Class Initialized
INFO - 2018-03-16 21:21:13 --> Loader Class Initialized
INFO - 2018-03-16 21:21:13 --> Helper loaded: url_helper
INFO - 2018-03-16 21:21:13 --> Helper loaded: site_helper
INFO - 2018-03-16 21:21:13 --> Database Driver Class Initialized
INFO - 2018-03-16 21:21:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:21:13 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:21:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:21:13 --> Controller Class Initialized
INFO - 2018-03-16 21:21:13 --> User Agent Class Initialized
INFO - 2018-03-16 21:21:13 --> Model "site_model" initialized
INFO - 2018-03-16 21:21:13 --> Model "user_model" initialized
INFO - 2018-03-16 21:21:13 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:21:13 --> Severity: error --> Exception: syntax error, unexpected ';' D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 1
INFO - 2018-03-16 21:21:14 --> Database Driver Class Initialized
INFO - 2018-03-16 21:21:14 --> Config Class Initialized
INFO - 2018-03-16 21:21:14 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:21:14 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:21:14 --> Utf8 Class Initialized
INFO - 2018-03-16 21:21:14 --> URI Class Initialized
DEBUG - 2018-03-16 21:21:14 --> No URI present. Default controller set.
INFO - 2018-03-16 21:21:14 --> Router Class Initialized
INFO - 2018-03-16 21:21:14 --> Output Class Initialized
INFO - 2018-03-16 21:21:14 --> Security Class Initialized
DEBUG - 2018-03-16 21:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:21:14 --> Input Class Initialized
INFO - 2018-03-16 21:21:14 --> Language Class Initialized
INFO - 2018-03-16 21:21:14 --> Loader Class Initialized
INFO - 2018-03-16 21:21:14 --> Helper loaded: url_helper
INFO - 2018-03-16 21:21:14 --> Helper loaded: site_helper
INFO - 2018-03-16 21:21:14 --> Database Driver Class Initialized
INFO - 2018-03-16 21:21:14 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:21:14 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:21:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:21:14 --> Controller Class Initialized
INFO - 2018-03-16 21:21:14 --> User Agent Class Initialized
INFO - 2018-03-16 21:21:14 --> Model "site_model" initialized
INFO - 2018-03-16 21:21:14 --> Model "user_model" initialized
INFO - 2018-03-16 21:21:14 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:21:14 --> Severity: error --> Exception: syntax error, unexpected ';' D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 1
INFO - 2018-03-16 21:23:28 --> Database Driver Class Initialized
INFO - 2018-03-16 21:23:28 --> Config Class Initialized
INFO - 2018-03-16 21:23:28 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:23:28 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:23:28 --> Utf8 Class Initialized
INFO - 2018-03-16 21:23:28 --> URI Class Initialized
DEBUG - 2018-03-16 21:23:28 --> No URI present. Default controller set.
INFO - 2018-03-16 21:23:28 --> Router Class Initialized
INFO - 2018-03-16 21:23:28 --> Output Class Initialized
INFO - 2018-03-16 21:23:28 --> Security Class Initialized
DEBUG - 2018-03-16 21:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:23:28 --> Input Class Initialized
INFO - 2018-03-16 21:23:28 --> Language Class Initialized
INFO - 2018-03-16 21:23:28 --> Loader Class Initialized
INFO - 2018-03-16 21:23:28 --> Helper loaded: url_helper
INFO - 2018-03-16 21:23:28 --> Helper loaded: site_helper
INFO - 2018-03-16 21:23:28 --> Database Driver Class Initialized
INFO - 2018-03-16 21:23:28 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:23:28 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:23:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:23:28 --> Controller Class Initialized
INFO - 2018-03-16 21:23:28 --> User Agent Class Initialized
INFO - 2018-03-16 21:23:28 --> Model "site_model" initialized
INFO - 2018-03-16 21:23:28 --> Model "user_model" initialized
INFO - 2018-03-16 21:23:28 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:23:28 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 18
INFO - 2018-03-16 21:23:40 --> Database Driver Class Initialized
INFO - 2018-03-16 21:23:40 --> Config Class Initialized
INFO - 2018-03-16 21:23:40 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:23:40 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:23:40 --> Utf8 Class Initialized
INFO - 2018-03-16 21:23:40 --> URI Class Initialized
DEBUG - 2018-03-16 21:23:40 --> No URI present. Default controller set.
INFO - 2018-03-16 21:23:40 --> Router Class Initialized
INFO - 2018-03-16 21:23:40 --> Output Class Initialized
INFO - 2018-03-16 21:23:40 --> Security Class Initialized
DEBUG - 2018-03-16 21:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:23:40 --> Input Class Initialized
INFO - 2018-03-16 21:23:40 --> Language Class Initialized
INFO - 2018-03-16 21:23:40 --> Loader Class Initialized
INFO - 2018-03-16 21:23:40 --> Helper loaded: url_helper
INFO - 2018-03-16 21:23:40 --> Helper loaded: site_helper
INFO - 2018-03-16 21:23:40 --> Database Driver Class Initialized
INFO - 2018-03-16 21:23:40 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:23:40 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:23:40 --> Controller Class Initialized
INFO - 2018-03-16 21:23:40 --> User Agent Class Initialized
INFO - 2018-03-16 21:23:40 --> Model "site_model" initialized
INFO - 2018-03-16 21:23:40 --> Model "user_model" initialized
INFO - 2018-03-16 21:23:40 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:23:40 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 2
INFO - 2018-03-16 21:23:47 --> Database Driver Class Initialized
INFO - 2018-03-16 21:23:47 --> Config Class Initialized
INFO - 2018-03-16 21:23:47 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:23:47 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:23:47 --> Utf8 Class Initialized
INFO - 2018-03-16 21:23:47 --> URI Class Initialized
DEBUG - 2018-03-16 21:23:47 --> No URI present. Default controller set.
INFO - 2018-03-16 21:23:47 --> Router Class Initialized
INFO - 2018-03-16 21:23:47 --> Output Class Initialized
INFO - 2018-03-16 21:23:47 --> Security Class Initialized
DEBUG - 2018-03-16 21:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:23:47 --> Input Class Initialized
INFO - 2018-03-16 21:23:47 --> Language Class Initialized
INFO - 2018-03-16 21:23:47 --> Loader Class Initialized
INFO - 2018-03-16 21:23:47 --> Helper loaded: url_helper
INFO - 2018-03-16 21:23:47 --> Helper loaded: site_helper
INFO - 2018-03-16 21:23:47 --> Database Driver Class Initialized
INFO - 2018-03-16 21:23:47 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:23:47 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:23:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:23:47 --> Controller Class Initialized
INFO - 2018-03-16 21:23:47 --> User Agent Class Initialized
INFO - 2018-03-16 21:23:47 --> Model "site_model" initialized
INFO - 2018-03-16 21:23:47 --> Model "user_model" initialized
INFO - 2018-03-16 21:23:47 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:23:47 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 3
INFO - 2018-03-16 21:24:18 --> Database Driver Class Initialized
INFO - 2018-03-16 21:24:18 --> Config Class Initialized
INFO - 2018-03-16 21:24:18 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:24:18 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:24:18 --> Utf8 Class Initialized
INFO - 2018-03-16 21:24:18 --> URI Class Initialized
DEBUG - 2018-03-16 21:24:18 --> No URI present. Default controller set.
INFO - 2018-03-16 21:24:18 --> Router Class Initialized
INFO - 2018-03-16 21:24:18 --> Output Class Initialized
INFO - 2018-03-16 21:24:18 --> Security Class Initialized
DEBUG - 2018-03-16 21:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:24:18 --> Input Class Initialized
INFO - 2018-03-16 21:24:18 --> Language Class Initialized
INFO - 2018-03-16 21:24:18 --> Loader Class Initialized
INFO - 2018-03-16 21:24:18 --> Helper loaded: url_helper
INFO - 2018-03-16 21:24:18 --> Helper loaded: site_helper
INFO - 2018-03-16 21:24:18 --> Database Driver Class Initialized
INFO - 2018-03-16 21:24:18 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:24:18 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:24:18 --> Controller Class Initialized
INFO - 2018-03-16 21:24:18 --> User Agent Class Initialized
INFO - 2018-03-16 21:24:18 --> Model "site_model" initialized
INFO - 2018-03-16 21:24:18 --> Model "user_model" initialized
INFO - 2018-03-16 21:24:18 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:24:18 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 3
INFO - 2018-03-16 21:24:19 --> Database Driver Class Initialized
INFO - 2018-03-16 21:24:19 --> Config Class Initialized
INFO - 2018-03-16 21:24:19 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:24:19 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:24:19 --> Utf8 Class Initialized
INFO - 2018-03-16 21:24:19 --> URI Class Initialized
DEBUG - 2018-03-16 21:24:19 --> No URI present. Default controller set.
INFO - 2018-03-16 21:24:19 --> Router Class Initialized
INFO - 2018-03-16 21:24:19 --> Output Class Initialized
INFO - 2018-03-16 21:24:19 --> Security Class Initialized
DEBUG - 2018-03-16 21:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:24:19 --> Input Class Initialized
INFO - 2018-03-16 21:24:19 --> Language Class Initialized
INFO - 2018-03-16 21:24:19 --> Loader Class Initialized
INFO - 2018-03-16 21:24:19 --> Helper loaded: url_helper
INFO - 2018-03-16 21:24:19 --> Helper loaded: site_helper
INFO - 2018-03-16 21:24:19 --> Database Driver Class Initialized
INFO - 2018-03-16 21:24:19 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:24:19 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:24:19 --> Controller Class Initialized
INFO - 2018-03-16 21:24:19 --> User Agent Class Initialized
INFO - 2018-03-16 21:24:19 --> Model "site_model" initialized
INFO - 2018-03-16 21:24:19 --> Model "user_model" initialized
INFO - 2018-03-16 21:24:19 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:24:19 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 3
INFO - 2018-03-16 21:24:47 --> Database Driver Class Initialized
INFO - 2018-03-16 21:24:47 --> Config Class Initialized
INFO - 2018-03-16 21:24:47 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:24:47 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:24:47 --> Utf8 Class Initialized
INFO - 2018-03-16 21:24:47 --> URI Class Initialized
DEBUG - 2018-03-16 21:24:47 --> No URI present. Default controller set.
INFO - 2018-03-16 21:24:47 --> Router Class Initialized
INFO - 2018-03-16 21:24:47 --> Output Class Initialized
INFO - 2018-03-16 21:24:47 --> Security Class Initialized
DEBUG - 2018-03-16 21:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:24:47 --> Input Class Initialized
INFO - 2018-03-16 21:24:47 --> Language Class Initialized
INFO - 2018-03-16 21:24:47 --> Loader Class Initialized
INFO - 2018-03-16 21:24:47 --> Helper loaded: url_helper
INFO - 2018-03-16 21:24:47 --> Helper loaded: site_helper
INFO - 2018-03-16 21:24:47 --> Database Driver Class Initialized
INFO - 2018-03-16 21:24:47 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:24:47 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:24:47 --> Controller Class Initialized
INFO - 2018-03-16 21:24:47 --> User Agent Class Initialized
INFO - 2018-03-16 21:24:47 --> Model "site_model" initialized
INFO - 2018-03-16 21:24:47 --> Model "user_model" initialized
INFO - 2018-03-16 21:24:47 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:24:47 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 18
INFO - 2018-03-16 21:24:57 --> Database Driver Class Initialized
INFO - 2018-03-16 21:24:57 --> Config Class Initialized
INFO - 2018-03-16 21:24:57 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:24:57 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:24:57 --> Utf8 Class Initialized
INFO - 2018-03-16 21:24:57 --> URI Class Initialized
DEBUG - 2018-03-16 21:24:57 --> No URI present. Default controller set.
INFO - 2018-03-16 21:24:57 --> Router Class Initialized
INFO - 2018-03-16 21:24:57 --> Output Class Initialized
INFO - 2018-03-16 21:24:57 --> Security Class Initialized
DEBUG - 2018-03-16 21:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:24:57 --> Input Class Initialized
INFO - 2018-03-16 21:24:57 --> Language Class Initialized
INFO - 2018-03-16 21:24:57 --> Loader Class Initialized
INFO - 2018-03-16 21:24:57 --> Helper loaded: url_helper
INFO - 2018-03-16 21:24:57 --> Helper loaded: site_helper
INFO - 2018-03-16 21:24:57 --> Database Driver Class Initialized
INFO - 2018-03-16 21:24:57 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:24:57 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:24:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:24:57 --> Controller Class Initialized
INFO - 2018-03-16 21:24:57 --> User Agent Class Initialized
INFO - 2018-03-16 21:24:57 --> Model "site_model" initialized
INFO - 2018-03-16 21:24:57 --> Model "user_model" initialized
INFO - 2018-03-16 21:24:57 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:24:57 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 1
INFO - 2018-03-16 21:25:01 --> Database Driver Class Initialized
INFO - 2018-03-16 21:25:01 --> Config Class Initialized
INFO - 2018-03-16 21:25:01 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:25:01 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:25:01 --> Utf8 Class Initialized
INFO - 2018-03-16 21:25:01 --> URI Class Initialized
DEBUG - 2018-03-16 21:25:01 --> No URI present. Default controller set.
INFO - 2018-03-16 21:25:01 --> Router Class Initialized
INFO - 2018-03-16 21:25:01 --> Output Class Initialized
INFO - 2018-03-16 21:25:01 --> Security Class Initialized
DEBUG - 2018-03-16 21:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:25:01 --> Input Class Initialized
INFO - 2018-03-16 21:25:01 --> Language Class Initialized
INFO - 2018-03-16 21:25:01 --> Loader Class Initialized
INFO - 2018-03-16 21:25:01 --> Helper loaded: url_helper
INFO - 2018-03-16 21:25:01 --> Helper loaded: site_helper
INFO - 2018-03-16 21:25:01 --> Database Driver Class Initialized
INFO - 2018-03-16 21:25:01 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:25:01 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:25:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:25:01 --> Controller Class Initialized
INFO - 2018-03-16 21:25:01 --> User Agent Class Initialized
INFO - 2018-03-16 21:25:01 --> Model "site_model" initialized
INFO - 2018-03-16 21:25:01 --> Model "user_model" initialized
INFO - 2018-03-16 21:25:01 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:25:01 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 1
INFO - 2018-03-16 21:29:13 --> Database Driver Class Initialized
INFO - 2018-03-16 21:29:13 --> Config Class Initialized
INFO - 2018-03-16 21:29:13 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:29:13 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:29:13 --> Utf8 Class Initialized
INFO - 2018-03-16 21:29:13 --> URI Class Initialized
DEBUG - 2018-03-16 21:29:13 --> No URI present. Default controller set.
INFO - 2018-03-16 21:29:13 --> Router Class Initialized
INFO - 2018-03-16 21:29:13 --> Output Class Initialized
INFO - 2018-03-16 21:29:13 --> Security Class Initialized
DEBUG - 2018-03-16 21:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:29:13 --> Input Class Initialized
INFO - 2018-03-16 21:29:13 --> Language Class Initialized
INFO - 2018-03-16 21:29:13 --> Loader Class Initialized
INFO - 2018-03-16 21:29:13 --> Helper loaded: url_helper
INFO - 2018-03-16 21:29:13 --> Helper loaded: site_helper
INFO - 2018-03-16 21:29:13 --> Database Driver Class Initialized
INFO - 2018-03-16 21:29:13 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:29:13 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:29:13 --> Controller Class Initialized
INFO - 2018-03-16 21:29:13 --> User Agent Class Initialized
INFO - 2018-03-16 21:29:13 --> Model "site_model" initialized
INFO - 2018-03-16 21:29:13 --> Model "user_model" initialized
INFO - 2018-03-16 21:29:13 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:29:13 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 2
INFO - 2018-03-16 21:33:32 --> Database Driver Class Initialized
INFO - 2018-03-16 21:33:32 --> Config Class Initialized
INFO - 2018-03-16 21:33:32 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:33:32 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:33:32 --> Utf8 Class Initialized
INFO - 2018-03-16 21:33:32 --> URI Class Initialized
DEBUG - 2018-03-16 21:33:32 --> No URI present. Default controller set.
INFO - 2018-03-16 21:33:32 --> Router Class Initialized
INFO - 2018-03-16 21:33:32 --> Output Class Initialized
INFO - 2018-03-16 21:33:32 --> Security Class Initialized
DEBUG - 2018-03-16 21:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:33:32 --> Input Class Initialized
INFO - 2018-03-16 21:33:32 --> Language Class Initialized
INFO - 2018-03-16 21:33:32 --> Loader Class Initialized
INFO - 2018-03-16 21:33:32 --> Helper loaded: url_helper
INFO - 2018-03-16 21:33:32 --> Helper loaded: site_helper
INFO - 2018-03-16 21:33:32 --> Database Driver Class Initialized
INFO - 2018-03-16 21:33:32 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:33:32 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:33:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:33:32 --> Controller Class Initialized
INFO - 2018-03-16 21:33:32 --> User Agent Class Initialized
INFO - 2018-03-16 21:33:32 --> Model "site_model" initialized
INFO - 2018-03-16 21:33:32 --> Model "user_model" initialized
INFO - 2018-03-16 21:33:32 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:33:32 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 19
INFO - 2018-03-16 21:33:35 --> Database Driver Class Initialized
INFO - 2018-03-16 21:33:35 --> Config Class Initialized
INFO - 2018-03-16 21:33:35 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:33:35 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:33:35 --> Utf8 Class Initialized
INFO - 2018-03-16 21:33:35 --> URI Class Initialized
DEBUG - 2018-03-16 21:33:35 --> No URI present. Default controller set.
INFO - 2018-03-16 21:33:35 --> Router Class Initialized
INFO - 2018-03-16 21:33:35 --> Output Class Initialized
INFO - 2018-03-16 21:33:35 --> Security Class Initialized
DEBUG - 2018-03-16 21:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:33:35 --> Input Class Initialized
INFO - 2018-03-16 21:33:35 --> Language Class Initialized
INFO - 2018-03-16 21:33:35 --> Loader Class Initialized
INFO - 2018-03-16 21:33:35 --> Helper loaded: url_helper
INFO - 2018-03-16 21:33:35 --> Helper loaded: site_helper
INFO - 2018-03-16 21:33:35 --> Database Driver Class Initialized
INFO - 2018-03-16 21:33:35 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:33:35 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:33:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:33:35 --> Controller Class Initialized
INFO - 2018-03-16 21:33:35 --> User Agent Class Initialized
INFO - 2018-03-16 21:33:35 --> Model "site_model" initialized
INFO - 2018-03-16 21:33:35 --> Model "user_model" initialized
INFO - 2018-03-16 21:33:35 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:33:35 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 19
INFO - 2018-03-16 21:33:50 --> Database Driver Class Initialized
INFO - 2018-03-16 21:33:50 --> Config Class Initialized
INFO - 2018-03-16 21:33:50 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:33:50 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:33:50 --> Utf8 Class Initialized
INFO - 2018-03-16 21:33:50 --> URI Class Initialized
DEBUG - 2018-03-16 21:33:50 --> No URI present. Default controller set.
INFO - 2018-03-16 21:33:50 --> Router Class Initialized
INFO - 2018-03-16 21:33:50 --> Output Class Initialized
INFO - 2018-03-16 21:33:50 --> Security Class Initialized
DEBUG - 2018-03-16 21:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:33:50 --> Input Class Initialized
INFO - 2018-03-16 21:33:50 --> Language Class Initialized
INFO - 2018-03-16 21:33:50 --> Loader Class Initialized
INFO - 2018-03-16 21:33:50 --> Helper loaded: url_helper
INFO - 2018-03-16 21:33:50 --> Helper loaded: site_helper
INFO - 2018-03-16 21:33:50 --> Database Driver Class Initialized
INFO - 2018-03-16 21:33:50 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:33:50 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:33:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:33:50 --> Controller Class Initialized
INFO - 2018-03-16 21:33:50 --> User Agent Class Initialized
INFO - 2018-03-16 21:33:50 --> Model "site_model" initialized
INFO - 2018-03-16 21:33:50 --> Model "user_model" initialized
INFO - 2018-03-16 21:33:50 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:33:50 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 19
INFO - 2018-03-16 21:35:06 --> Database Driver Class Initialized
INFO - 2018-03-16 21:35:06 --> Config Class Initialized
INFO - 2018-03-16 21:35:06 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:35:06 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:35:06 --> Utf8 Class Initialized
INFO - 2018-03-16 21:35:06 --> URI Class Initialized
DEBUG - 2018-03-16 21:35:06 --> No URI present. Default controller set.
INFO - 2018-03-16 21:35:06 --> Router Class Initialized
INFO - 2018-03-16 21:35:06 --> Output Class Initialized
INFO - 2018-03-16 21:35:06 --> Security Class Initialized
DEBUG - 2018-03-16 21:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:35:06 --> Input Class Initialized
INFO - 2018-03-16 21:35:06 --> Language Class Initialized
INFO - 2018-03-16 21:35:06 --> Loader Class Initialized
INFO - 2018-03-16 21:35:06 --> Helper loaded: url_helper
INFO - 2018-03-16 21:35:06 --> Helper loaded: site_helper
INFO - 2018-03-16 21:35:06 --> Database Driver Class Initialized
INFO - 2018-03-16 21:35:06 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:35:06 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:35:06 --> Controller Class Initialized
INFO - 2018-03-16 21:35:06 --> User Agent Class Initialized
INFO - 2018-03-16 21:35:06 --> Model "site_model" initialized
INFO - 2018-03-16 21:35:06 --> Model "user_model" initialized
INFO - 2018-03-16 21:35:06 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:35:06 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 2
INFO - 2018-03-16 21:35:56 --> Database Driver Class Initialized
INFO - 2018-03-16 21:35:56 --> Config Class Initialized
INFO - 2018-03-16 21:35:56 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:35:56 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:35:56 --> Utf8 Class Initialized
INFO - 2018-03-16 21:35:56 --> URI Class Initialized
DEBUG - 2018-03-16 21:35:56 --> No URI present. Default controller set.
INFO - 2018-03-16 21:35:56 --> Router Class Initialized
INFO - 2018-03-16 21:35:56 --> Output Class Initialized
INFO - 2018-03-16 21:35:56 --> Security Class Initialized
DEBUG - 2018-03-16 21:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:35:56 --> Input Class Initialized
INFO - 2018-03-16 21:35:56 --> Language Class Initialized
INFO - 2018-03-16 21:35:56 --> Loader Class Initialized
INFO - 2018-03-16 21:35:56 --> Helper loaded: url_helper
INFO - 2018-03-16 21:35:56 --> Helper loaded: site_helper
INFO - 2018-03-16 21:35:56 --> Database Driver Class Initialized
INFO - 2018-03-16 21:35:56 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:35:56 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:35:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:35:56 --> Controller Class Initialized
INFO - 2018-03-16 21:35:56 --> User Agent Class Initialized
INFO - 2018-03-16 21:35:56 --> Model "site_model" initialized
INFO - 2018-03-16 21:35:56 --> Model "user_model" initialized
INFO - 2018-03-16 21:35:56 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:35:56 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 19
INFO - 2018-03-16 21:36:09 --> Database Driver Class Initialized
INFO - 2018-03-16 21:36:09 --> Config Class Initialized
INFO - 2018-03-16 21:36:09 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:36:09 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:36:09 --> Utf8 Class Initialized
INFO - 2018-03-16 21:36:09 --> URI Class Initialized
DEBUG - 2018-03-16 21:36:09 --> No URI present. Default controller set.
INFO - 2018-03-16 21:36:09 --> Router Class Initialized
INFO - 2018-03-16 21:36:09 --> Output Class Initialized
INFO - 2018-03-16 21:36:09 --> Security Class Initialized
DEBUG - 2018-03-16 21:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:36:09 --> Input Class Initialized
INFO - 2018-03-16 21:36:09 --> Language Class Initialized
INFO - 2018-03-16 21:36:09 --> Loader Class Initialized
INFO - 2018-03-16 21:36:09 --> Helper loaded: url_helper
INFO - 2018-03-16 21:36:09 --> Helper loaded: site_helper
INFO - 2018-03-16 21:36:09 --> Database Driver Class Initialized
INFO - 2018-03-16 21:36:09 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:36:09 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:36:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:36:09 --> Controller Class Initialized
INFO - 2018-03-16 21:36:09 --> User Agent Class Initialized
INFO - 2018-03-16 21:36:09 --> Model "site_model" initialized
INFO - 2018-03-16 21:36:09 --> Model "user_model" initialized
INFO - 2018-03-16 21:36:09 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:36:09 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 19
INFO - 2018-03-16 21:36:32 --> Database Driver Class Initialized
INFO - 2018-03-16 21:36:32 --> Config Class Initialized
INFO - 2018-03-16 21:36:32 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:36:32 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:36:32 --> Utf8 Class Initialized
INFO - 2018-03-16 21:36:32 --> URI Class Initialized
DEBUG - 2018-03-16 21:36:32 --> No URI present. Default controller set.
INFO - 2018-03-16 21:36:32 --> Router Class Initialized
INFO - 2018-03-16 21:36:32 --> Output Class Initialized
INFO - 2018-03-16 21:36:32 --> Security Class Initialized
DEBUG - 2018-03-16 21:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:36:32 --> Input Class Initialized
INFO - 2018-03-16 21:36:32 --> Language Class Initialized
INFO - 2018-03-16 21:36:32 --> Loader Class Initialized
INFO - 2018-03-16 21:36:32 --> Helper loaded: url_helper
INFO - 2018-03-16 21:36:32 --> Helper loaded: site_helper
INFO - 2018-03-16 21:36:32 --> Database Driver Class Initialized
INFO - 2018-03-16 21:36:32 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:36:32 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:36:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:36:32 --> Controller Class Initialized
INFO - 2018-03-16 21:36:32 --> User Agent Class Initialized
INFO - 2018-03-16 21:36:32 --> Model "site_model" initialized
INFO - 2018-03-16 21:36:32 --> Model "user_model" initialized
INFO - 2018-03-16 21:36:32 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:36:32 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 19
INFO - 2018-03-16 21:36:33 --> Database Driver Class Initialized
INFO - 2018-03-16 21:36:33 --> Config Class Initialized
INFO - 2018-03-16 21:36:33 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:36:33 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:36:33 --> Utf8 Class Initialized
INFO - 2018-03-16 21:36:33 --> URI Class Initialized
DEBUG - 2018-03-16 21:36:33 --> No URI present. Default controller set.
INFO - 2018-03-16 21:36:33 --> Router Class Initialized
INFO - 2018-03-16 21:36:33 --> Output Class Initialized
INFO - 2018-03-16 21:36:33 --> Security Class Initialized
DEBUG - 2018-03-16 21:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:36:33 --> Input Class Initialized
INFO - 2018-03-16 21:36:33 --> Language Class Initialized
INFO - 2018-03-16 21:36:33 --> Loader Class Initialized
INFO - 2018-03-16 21:36:33 --> Helper loaded: url_helper
INFO - 2018-03-16 21:36:33 --> Helper loaded: site_helper
INFO - 2018-03-16 21:36:33 --> Database Driver Class Initialized
INFO - 2018-03-16 21:36:33 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:36:33 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:36:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:36:33 --> Controller Class Initialized
INFO - 2018-03-16 21:36:33 --> User Agent Class Initialized
INFO - 2018-03-16 21:36:33 --> Model "site_model" initialized
INFO - 2018-03-16 21:36:33 --> Model "user_model" initialized
INFO - 2018-03-16 21:36:33 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:36:33 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 19
INFO - 2018-03-16 21:37:56 --> Database Driver Class Initialized
INFO - 2018-03-16 21:37:56 --> Config Class Initialized
INFO - 2018-03-16 21:37:56 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:37:56 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:37:56 --> Utf8 Class Initialized
INFO - 2018-03-16 21:37:56 --> URI Class Initialized
DEBUG - 2018-03-16 21:37:56 --> No URI present. Default controller set.
INFO - 2018-03-16 21:37:56 --> Router Class Initialized
INFO - 2018-03-16 21:37:56 --> Output Class Initialized
INFO - 2018-03-16 21:37:56 --> Security Class Initialized
DEBUG - 2018-03-16 21:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:37:56 --> Input Class Initialized
INFO - 2018-03-16 21:37:56 --> Language Class Initialized
INFO - 2018-03-16 21:37:56 --> Loader Class Initialized
INFO - 2018-03-16 21:37:56 --> Helper loaded: url_helper
INFO - 2018-03-16 21:37:56 --> Helper loaded: site_helper
INFO - 2018-03-16 21:37:56 --> Database Driver Class Initialized
INFO - 2018-03-16 21:37:56 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:37:56 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:37:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:37:56 --> Controller Class Initialized
INFO - 2018-03-16 21:37:56 --> User Agent Class Initialized
INFO - 2018-03-16 21:37:56 --> Model "site_model" initialized
INFO - 2018-03-16 21:37:56 --> Model "user_model" initialized
INFO - 2018-03-16 21:37:56 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:37:56 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 19
INFO - 2018-03-16 21:41:37 --> Database Driver Class Initialized
INFO - 2018-03-16 21:41:37 --> Config Class Initialized
INFO - 2018-03-16 21:41:37 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:41:37 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:41:37 --> Utf8 Class Initialized
INFO - 2018-03-16 21:41:37 --> URI Class Initialized
DEBUG - 2018-03-16 21:41:37 --> No URI present. Default controller set.
INFO - 2018-03-16 21:41:37 --> Router Class Initialized
INFO - 2018-03-16 21:41:37 --> Output Class Initialized
INFO - 2018-03-16 21:41:37 --> Security Class Initialized
DEBUG - 2018-03-16 21:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:41:37 --> Input Class Initialized
INFO - 2018-03-16 21:41:37 --> Language Class Initialized
INFO - 2018-03-16 21:41:37 --> Loader Class Initialized
INFO - 2018-03-16 21:41:37 --> Helper loaded: url_helper
INFO - 2018-03-16 21:41:37 --> Helper loaded: site_helper
INFO - 2018-03-16 21:41:37 --> Database Driver Class Initialized
INFO - 2018-03-16 21:41:37 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:41:37 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:41:37 --> Controller Class Initialized
INFO - 2018-03-16 21:41:37 --> User Agent Class Initialized
INFO - 2018-03-16 21:41:37 --> Model "site_model" initialized
INFO - 2018-03-16 21:41:37 --> Model "user_model" initialized
INFO - 2018-03-16 21:41:37 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:41:37 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 2
INFO - 2018-03-16 21:41:42 --> Database Driver Class Initialized
INFO - 2018-03-16 21:41:42 --> Config Class Initialized
INFO - 2018-03-16 21:41:42 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:41:42 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:41:42 --> Utf8 Class Initialized
INFO - 2018-03-16 21:41:42 --> URI Class Initialized
DEBUG - 2018-03-16 21:41:42 --> No URI present. Default controller set.
INFO - 2018-03-16 21:41:42 --> Router Class Initialized
INFO - 2018-03-16 21:41:42 --> Output Class Initialized
INFO - 2018-03-16 21:41:42 --> Security Class Initialized
DEBUG - 2018-03-16 21:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:41:42 --> Input Class Initialized
INFO - 2018-03-16 21:41:42 --> Language Class Initialized
INFO - 2018-03-16 21:41:42 --> Loader Class Initialized
INFO - 2018-03-16 21:41:42 --> Helper loaded: url_helper
INFO - 2018-03-16 21:41:42 --> Helper loaded: site_helper
INFO - 2018-03-16 21:41:42 --> Database Driver Class Initialized
INFO - 2018-03-16 21:41:42 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:41:42 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:41:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:41:42 --> Controller Class Initialized
INFO - 2018-03-16 21:41:42 --> User Agent Class Initialized
INFO - 2018-03-16 21:41:42 --> Model "site_model" initialized
INFO - 2018-03-16 21:41:42 --> Model "user_model" initialized
INFO - 2018-03-16 21:41:42 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:41:42 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 19
INFO - 2018-03-16 21:41:55 --> Database Driver Class Initialized
INFO - 2018-03-16 21:41:55 --> Config Class Initialized
INFO - 2018-03-16 21:41:55 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:41:55 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:41:55 --> Utf8 Class Initialized
INFO - 2018-03-16 21:41:55 --> URI Class Initialized
DEBUG - 2018-03-16 21:41:55 --> No URI present. Default controller set.
INFO - 2018-03-16 21:41:55 --> Router Class Initialized
INFO - 2018-03-16 21:41:55 --> Output Class Initialized
INFO - 2018-03-16 21:41:55 --> Security Class Initialized
DEBUG - 2018-03-16 21:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:41:55 --> Input Class Initialized
INFO - 2018-03-16 21:41:55 --> Language Class Initialized
INFO - 2018-03-16 21:41:55 --> Loader Class Initialized
INFO - 2018-03-16 21:41:55 --> Helper loaded: url_helper
INFO - 2018-03-16 21:41:55 --> Helper loaded: site_helper
INFO - 2018-03-16 21:41:55 --> Database Driver Class Initialized
INFO - 2018-03-16 21:41:55 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:41:55 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:41:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:41:55 --> Controller Class Initialized
INFO - 2018-03-16 21:41:55 --> User Agent Class Initialized
INFO - 2018-03-16 21:41:55 --> Model "site_model" initialized
INFO - 2018-03-16 21:41:55 --> Model "user_model" initialized
INFO - 2018-03-16 21:41:55 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:41:55 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 19
INFO - 2018-03-16 21:42:06 --> Database Driver Class Initialized
INFO - 2018-03-16 21:42:06 --> Config Class Initialized
INFO - 2018-03-16 21:42:06 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:42:06 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:42:06 --> Utf8 Class Initialized
INFO - 2018-03-16 21:42:06 --> URI Class Initialized
DEBUG - 2018-03-16 21:42:06 --> No URI present. Default controller set.
INFO - 2018-03-16 21:42:06 --> Router Class Initialized
INFO - 2018-03-16 21:42:06 --> Output Class Initialized
INFO - 2018-03-16 21:42:06 --> Security Class Initialized
DEBUG - 2018-03-16 21:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:42:06 --> Input Class Initialized
INFO - 2018-03-16 21:42:06 --> Language Class Initialized
INFO - 2018-03-16 21:42:06 --> Loader Class Initialized
INFO - 2018-03-16 21:42:06 --> Helper loaded: url_helper
INFO - 2018-03-16 21:42:06 --> Helper loaded: site_helper
INFO - 2018-03-16 21:42:06 --> Database Driver Class Initialized
INFO - 2018-03-16 21:42:06 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:42:06 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:42:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:42:06 --> Controller Class Initialized
INFO - 2018-03-16 21:42:06 --> User Agent Class Initialized
INFO - 2018-03-16 21:42:06 --> Model "site_model" initialized
INFO - 2018-03-16 21:42:06 --> Model "user_model" initialized
INFO - 2018-03-16 21:42:06 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:42:06 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 19
INFO - 2018-03-16 21:46:57 --> Database Driver Class Initialized
INFO - 2018-03-16 21:46:57 --> Config Class Initialized
INFO - 2018-03-16 21:46:57 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:46:57 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:46:57 --> Utf8 Class Initialized
INFO - 2018-03-16 21:46:57 --> URI Class Initialized
DEBUG - 2018-03-16 21:46:57 --> No URI present. Default controller set.
INFO - 2018-03-16 21:46:57 --> Router Class Initialized
INFO - 2018-03-16 21:46:57 --> Output Class Initialized
INFO - 2018-03-16 21:46:57 --> Security Class Initialized
DEBUG - 2018-03-16 21:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:46:57 --> Input Class Initialized
INFO - 2018-03-16 21:46:57 --> Language Class Initialized
INFO - 2018-03-16 21:46:57 --> Loader Class Initialized
INFO - 2018-03-16 21:46:57 --> Helper loaded: url_helper
INFO - 2018-03-16 21:46:57 --> Helper loaded: site_helper
INFO - 2018-03-16 21:46:57 --> Database Driver Class Initialized
INFO - 2018-03-16 21:46:57 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:46:57 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:46:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:46:57 --> Controller Class Initialized
INFO - 2018-03-16 21:46:57 --> User Agent Class Initialized
INFO - 2018-03-16 21:46:57 --> Model "site_model" initialized
INFO - 2018-03-16 21:46:57 --> Model "user_model" initialized
INFO - 2018-03-16 21:46:57 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:46:57 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 20
INFO - 2018-03-16 21:48:52 --> Database Driver Class Initialized
INFO - 2018-03-16 21:48:52 --> Config Class Initialized
INFO - 2018-03-16 21:48:52 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:48:52 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:48:52 --> Utf8 Class Initialized
INFO - 2018-03-16 21:48:52 --> URI Class Initialized
DEBUG - 2018-03-16 21:48:52 --> No URI present. Default controller set.
INFO - 2018-03-16 21:48:52 --> Router Class Initialized
INFO - 2018-03-16 21:48:52 --> Output Class Initialized
INFO - 2018-03-16 21:48:52 --> Security Class Initialized
DEBUG - 2018-03-16 21:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:48:52 --> Input Class Initialized
INFO - 2018-03-16 21:48:52 --> Language Class Initialized
INFO - 2018-03-16 21:48:52 --> Loader Class Initialized
INFO - 2018-03-16 21:48:52 --> Helper loaded: url_helper
INFO - 2018-03-16 21:48:52 --> Helper loaded: site_helper
INFO - 2018-03-16 21:48:52 --> Database Driver Class Initialized
INFO - 2018-03-16 21:48:52 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:48:52 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:48:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:48:52 --> Controller Class Initialized
INFO - 2018-03-16 21:48:52 --> User Agent Class Initialized
INFO - 2018-03-16 21:48:52 --> Model "site_model" initialized
INFO - 2018-03-16 21:48:52 --> Model "user_model" initialized
INFO - 2018-03-16 21:48:52 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:48:52 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 3
INFO - 2018-03-16 21:49:05 --> Database Driver Class Initialized
INFO - 2018-03-16 21:49:05 --> Config Class Initialized
INFO - 2018-03-16 21:49:05 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:49:05 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:49:05 --> Utf8 Class Initialized
INFO - 2018-03-16 21:49:05 --> URI Class Initialized
DEBUG - 2018-03-16 21:49:05 --> No URI present. Default controller set.
INFO - 2018-03-16 21:49:05 --> Router Class Initialized
INFO - 2018-03-16 21:49:05 --> Output Class Initialized
INFO - 2018-03-16 21:49:05 --> Security Class Initialized
DEBUG - 2018-03-16 21:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:49:05 --> Input Class Initialized
INFO - 2018-03-16 21:49:05 --> Language Class Initialized
INFO - 2018-03-16 21:49:05 --> Loader Class Initialized
INFO - 2018-03-16 21:49:05 --> Helper loaded: url_helper
INFO - 2018-03-16 21:49:05 --> Helper loaded: site_helper
INFO - 2018-03-16 21:49:05 --> Database Driver Class Initialized
INFO - 2018-03-16 21:49:05 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:49:05 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:49:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:49:05 --> Controller Class Initialized
INFO - 2018-03-16 21:49:05 --> User Agent Class Initialized
INFO - 2018-03-16 21:49:05 --> Model "site_model" initialized
INFO - 2018-03-16 21:49:05 --> Model "user_model" initialized
INFO - 2018-03-16 21:49:05 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:49:05 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:49:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 21:49:05 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:49:05 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:49:05 --> Final output sent to browser
DEBUG - 2018-03-16 21:49:05 --> Total execution time: 0.0560
INFO - 2018-03-16 21:49:44 --> Database Driver Class Initialized
INFO - 2018-03-16 21:49:44 --> Config Class Initialized
INFO - 2018-03-16 21:49:44 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:49:44 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:49:44 --> Utf8 Class Initialized
INFO - 2018-03-16 21:49:44 --> URI Class Initialized
DEBUG - 2018-03-16 21:49:44 --> No URI present. Default controller set.
INFO - 2018-03-16 21:49:44 --> Router Class Initialized
INFO - 2018-03-16 21:49:44 --> Output Class Initialized
INFO - 2018-03-16 21:49:44 --> Security Class Initialized
DEBUG - 2018-03-16 21:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:49:44 --> Input Class Initialized
INFO - 2018-03-16 21:49:44 --> Language Class Initialized
INFO - 2018-03-16 21:49:44 --> Loader Class Initialized
INFO - 2018-03-16 21:49:44 --> Helper loaded: url_helper
INFO - 2018-03-16 21:49:44 --> Helper loaded: site_helper
INFO - 2018-03-16 21:49:44 --> Database Driver Class Initialized
INFO - 2018-03-16 21:49:44 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:49:44 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:49:44 --> Controller Class Initialized
INFO - 2018-03-16 21:49:44 --> User Agent Class Initialized
INFO - 2018-03-16 21:49:44 --> Model "site_model" initialized
INFO - 2018-03-16 21:49:44 --> Model "user_model" initialized
INFO - 2018-03-16 21:49:44 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:49:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:49:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 21:49:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:49:44 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:49:44 --> Final output sent to browser
DEBUG - 2018-03-16 21:49:44 --> Total execution time: 0.0500
INFO - 2018-03-16 21:49:44 --> Database Driver Class Initialized
INFO - 2018-03-16 21:49:44 --> Database Driver Class Initialized
INFO - 2018-03-16 21:49:44 --> Config Class Initialized
INFO - 2018-03-16 21:49:44 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:49:44 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:49:44 --> Utf8 Class Initialized
INFO - 2018-03-16 21:49:44 --> Config Class Initialized
INFO - 2018-03-16 21:49:44 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:49:44 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:49:44 --> Utf8 Class Initialized
INFO - 2018-03-16 21:49:45 --> Database Driver Class Initialized
INFO - 2018-03-16 21:49:45 --> Config Class Initialized
INFO - 2018-03-16 21:49:45 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:49:45 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:49:45 --> Utf8 Class Initialized
INFO - 2018-03-16 21:49:45 --> URI Class Initialized
DEBUG - 2018-03-16 21:49:45 --> No URI present. Default controller set.
INFO - 2018-03-16 21:49:45 --> Router Class Initialized
INFO - 2018-03-16 21:49:45 --> Output Class Initialized
INFO - 2018-03-16 21:49:45 --> Security Class Initialized
DEBUG - 2018-03-16 21:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:49:45 --> Input Class Initialized
INFO - 2018-03-16 21:49:45 --> Language Class Initialized
INFO - 2018-03-16 21:49:45 --> Loader Class Initialized
INFO - 2018-03-16 21:49:45 --> Helper loaded: url_helper
INFO - 2018-03-16 21:49:45 --> Helper loaded: site_helper
INFO - 2018-03-16 21:49:45 --> Database Driver Class Initialized
INFO - 2018-03-16 21:49:45 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:49:45 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:49:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:49:45 --> Controller Class Initialized
INFO - 2018-03-16 21:49:45 --> User Agent Class Initialized
INFO - 2018-03-16 21:49:45 --> Model "site_model" initialized
INFO - 2018-03-16 21:49:45 --> Model "user_model" initialized
INFO - 2018-03-16 21:49:45 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:49:45 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:49:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 21:49:45 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:49:45 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:49:45 --> Final output sent to browser
DEBUG - 2018-03-16 21:49:45 --> Total execution time: 0.0530
INFO - 2018-03-16 21:49:45 --> Database Driver Class Initialized
INFO - 2018-03-16 21:49:45 --> Database Driver Class Initialized
INFO - 2018-03-16 21:49:45 --> Config Class Initialized
INFO - 2018-03-16 21:49:45 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:49:45 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:49:45 --> Utf8 Class Initialized
INFO - 2018-03-16 21:49:45 --> Config Class Initialized
INFO - 2018-03-16 21:49:45 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:49:45 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:49:45 --> Utf8 Class Initialized
INFO - 2018-03-16 21:49:52 --> Database Driver Class Initialized
INFO - 2018-03-16 21:49:52 --> Database Driver Class Initialized
INFO - 2018-03-16 21:49:52 --> Config Class Initialized
INFO - 2018-03-16 21:49:52 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:49:52 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:49:52 --> Utf8 Class Initialized
INFO - 2018-03-16 21:49:52 --> Config Class Initialized
INFO - 2018-03-16 21:49:52 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:49:52 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:49:52 --> Utf8 Class Initialized
INFO - 2018-03-16 21:50:01 --> Database Driver Class Initialized
INFO - 2018-03-16 21:50:01 --> Config Class Initialized
INFO - 2018-03-16 21:50:01 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:50:01 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:50:01 --> Utf8 Class Initialized
INFO - 2018-03-16 21:50:01 --> URI Class Initialized
DEBUG - 2018-03-16 21:50:01 --> No URI present. Default controller set.
INFO - 2018-03-16 21:50:01 --> Router Class Initialized
INFO - 2018-03-16 21:50:01 --> Output Class Initialized
INFO - 2018-03-16 21:50:01 --> Security Class Initialized
DEBUG - 2018-03-16 21:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:50:01 --> Input Class Initialized
INFO - 2018-03-16 21:50:01 --> Language Class Initialized
INFO - 2018-03-16 21:50:01 --> Loader Class Initialized
INFO - 2018-03-16 21:50:01 --> Helper loaded: url_helper
INFO - 2018-03-16 21:50:01 --> Helper loaded: site_helper
INFO - 2018-03-16 21:50:01 --> Database Driver Class Initialized
INFO - 2018-03-16 21:50:01 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:50:01 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:50:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:50:01 --> Controller Class Initialized
INFO - 2018-03-16 21:50:01 --> User Agent Class Initialized
INFO - 2018-03-16 21:50:01 --> Model "site_model" initialized
INFO - 2018-03-16 21:50:01 --> Model "user_model" initialized
INFO - 2018-03-16 21:50:01 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:50:01 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:50:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 21:50:01 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:50:01 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:50:01 --> Final output sent to browser
DEBUG - 2018-03-16 21:50:01 --> Total execution time: 0.0520
INFO - 2018-03-16 21:50:01 --> Database Driver Class Initialized
INFO - 2018-03-16 21:50:01 --> Database Driver Class Initialized
INFO - 2018-03-16 21:50:01 --> Config Class Initialized
INFO - 2018-03-16 21:50:01 --> Hooks Class Initialized
INFO - 2018-03-16 21:50:01 --> Config Class Initialized
INFO - 2018-03-16 21:50:01 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:50:01 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:50:01 --> Utf8 Class Initialized
DEBUG - 2018-03-16 21:50:01 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:50:01 --> Utf8 Class Initialized
INFO - 2018-03-16 21:50:12 --> Database Driver Class Initialized
INFO - 2018-03-16 21:50:12 --> Config Class Initialized
INFO - 2018-03-16 21:50:12 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:50:12 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:50:12 --> Utf8 Class Initialized
INFO - 2018-03-16 21:50:12 --> URI Class Initialized
DEBUG - 2018-03-16 21:50:12 --> No URI present. Default controller set.
INFO - 2018-03-16 21:50:12 --> Router Class Initialized
INFO - 2018-03-16 21:50:12 --> Output Class Initialized
INFO - 2018-03-16 21:50:12 --> Security Class Initialized
DEBUG - 2018-03-16 21:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:50:12 --> Input Class Initialized
INFO - 2018-03-16 21:50:12 --> Language Class Initialized
INFO - 2018-03-16 21:50:12 --> Loader Class Initialized
INFO - 2018-03-16 21:50:12 --> Helper loaded: url_helper
INFO - 2018-03-16 21:50:12 --> Helper loaded: site_helper
INFO - 2018-03-16 21:50:12 --> Database Driver Class Initialized
INFO - 2018-03-16 21:50:12 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:50:12 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:50:12 --> Controller Class Initialized
INFO - 2018-03-16 21:50:12 --> User Agent Class Initialized
INFO - 2018-03-16 21:50:12 --> Model "site_model" initialized
INFO - 2018-03-16 21:50:12 --> Model "user_model" initialized
INFO - 2018-03-16 21:50:12 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:50:12 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:50:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 21:50:12 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:50:12 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:50:12 --> Final output sent to browser
DEBUG - 2018-03-16 21:50:12 --> Total execution time: 0.0410
INFO - 2018-03-16 21:51:01 --> Database Driver Class Initialized
INFO - 2018-03-16 21:51:01 --> Config Class Initialized
INFO - 2018-03-16 21:51:01 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:51:01 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:51:01 --> Utf8 Class Initialized
INFO - 2018-03-16 21:51:01 --> URI Class Initialized
DEBUG - 2018-03-16 21:51:01 --> No URI present. Default controller set.
INFO - 2018-03-16 21:51:01 --> Router Class Initialized
INFO - 2018-03-16 21:51:01 --> Output Class Initialized
INFO - 2018-03-16 21:51:01 --> Security Class Initialized
DEBUG - 2018-03-16 21:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:51:01 --> Input Class Initialized
INFO - 2018-03-16 21:51:01 --> Language Class Initialized
INFO - 2018-03-16 21:51:01 --> Loader Class Initialized
INFO - 2018-03-16 21:51:01 --> Helper loaded: url_helper
INFO - 2018-03-16 21:51:01 --> Helper loaded: site_helper
INFO - 2018-03-16 21:51:01 --> Database Driver Class Initialized
INFO - 2018-03-16 21:51:01 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:51:01 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:51:01 --> Controller Class Initialized
INFO - 2018-03-16 21:51:01 --> User Agent Class Initialized
INFO - 2018-03-16 21:51:01 --> Model "site_model" initialized
INFO - 2018-03-16 21:51:01 --> Model "user_model" initialized
INFO - 2018-03-16 21:51:01 --> Language file loaded: language/english/site_lang.php
ERROR - 2018-03-16 21:51:01 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\myteenmatch\application\views\templates\headers\welcome_header.php 21
INFO - 2018-03-16 21:51:14 --> Database Driver Class Initialized
INFO - 2018-03-16 21:51:14 --> Config Class Initialized
INFO - 2018-03-16 21:51:14 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:51:14 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:51:14 --> Utf8 Class Initialized
INFO - 2018-03-16 21:51:14 --> URI Class Initialized
DEBUG - 2018-03-16 21:51:14 --> No URI present. Default controller set.
INFO - 2018-03-16 21:51:14 --> Router Class Initialized
INFO - 2018-03-16 21:51:14 --> Output Class Initialized
INFO - 2018-03-16 21:51:14 --> Security Class Initialized
DEBUG - 2018-03-16 21:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:51:14 --> Input Class Initialized
INFO - 2018-03-16 21:51:14 --> Language Class Initialized
INFO - 2018-03-16 21:51:14 --> Loader Class Initialized
INFO - 2018-03-16 21:51:14 --> Helper loaded: url_helper
INFO - 2018-03-16 21:51:14 --> Helper loaded: site_helper
INFO - 2018-03-16 21:51:14 --> Database Driver Class Initialized
INFO - 2018-03-16 21:51:14 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:51:14 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:51:14 --> Controller Class Initialized
INFO - 2018-03-16 21:51:14 --> User Agent Class Initialized
INFO - 2018-03-16 21:51:14 --> Model "site_model" initialized
INFO - 2018-03-16 21:51:14 --> Model "user_model" initialized
INFO - 2018-03-16 21:51:14 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:51:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:51:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 21:51:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:51:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:51:14 --> Final output sent to browser
DEBUG - 2018-03-16 21:51:14 --> Total execution time: 0.0420
INFO - 2018-03-16 21:51:16 --> Database Driver Class Initialized
INFO - 2018-03-16 21:51:16 --> Config Class Initialized
INFO - 2018-03-16 21:51:16 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:51:16 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:51:16 --> Utf8 Class Initialized
INFO - 2018-03-16 21:51:16 --> URI Class Initialized
DEBUG - 2018-03-16 21:51:16 --> No URI present. Default controller set.
INFO - 2018-03-16 21:51:16 --> Router Class Initialized
INFO - 2018-03-16 21:51:16 --> Output Class Initialized
INFO - 2018-03-16 21:51:16 --> Security Class Initialized
DEBUG - 2018-03-16 21:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:51:16 --> Input Class Initialized
INFO - 2018-03-16 21:51:16 --> Language Class Initialized
INFO - 2018-03-16 21:51:16 --> Loader Class Initialized
INFO - 2018-03-16 21:51:16 --> Helper loaded: url_helper
INFO - 2018-03-16 21:51:16 --> Helper loaded: site_helper
INFO - 2018-03-16 21:51:16 --> Database Driver Class Initialized
INFO - 2018-03-16 21:51:16 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:51:16 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:51:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:51:16 --> Controller Class Initialized
INFO - 2018-03-16 21:51:16 --> User Agent Class Initialized
INFO - 2018-03-16 21:51:16 --> Model "site_model" initialized
INFO - 2018-03-16 21:51:16 --> Model "user_model" initialized
INFO - 2018-03-16 21:51:16 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:51:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 21:51:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:51:16 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:51:16 --> Final output sent to browser
DEBUG - 2018-03-16 21:51:16 --> Total execution time: 0.0560
INFO - 2018-03-16 21:51:17 --> Database Driver Class Initialized
INFO - 2018-03-16 21:51:18 --> Config Class Initialized
INFO - 2018-03-16 21:51:18 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:51:18 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:51:18 --> Utf8 Class Initialized
INFO - 2018-03-16 21:51:18 --> URI Class Initialized
INFO - 2018-03-16 21:51:18 --> Router Class Initialized
INFO - 2018-03-16 21:51:18 --> Output Class Initialized
INFO - 2018-03-16 21:51:18 --> Security Class Initialized
DEBUG - 2018-03-16 21:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:51:18 --> Input Class Initialized
INFO - 2018-03-16 21:51:18 --> Language Class Initialized
INFO - 2018-03-16 21:51:18 --> Loader Class Initialized
INFO - 2018-03-16 21:51:18 --> Helper loaded: url_helper
INFO - 2018-03-16 21:51:18 --> Helper loaded: site_helper
INFO - 2018-03-16 21:51:18 --> Database Driver Class Initialized
INFO - 2018-03-16 21:51:18 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:51:18 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:51:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:51:18 --> Controller Class Initialized
INFO - 2018-03-16 21:51:18 --> Model "user_model" initialized
INFO - 2018-03-16 21:51:18 --> Model "site_model" initialized
INFO - 2018-03-16 21:51:18 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 21:51:18 --> Final output sent to browser
DEBUG - 2018-03-16 21:51:18 --> Total execution time: 0.0410
INFO - 2018-03-16 21:52:10 --> Database Driver Class Initialized
INFO - 2018-03-16 21:52:10 --> Config Class Initialized
INFO - 2018-03-16 21:52:10 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:52:10 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:52:10 --> Utf8 Class Initialized
INFO - 2018-03-16 21:52:10 --> URI Class Initialized
DEBUG - 2018-03-16 21:52:10 --> No URI present. Default controller set.
INFO - 2018-03-16 21:52:10 --> Router Class Initialized
INFO - 2018-03-16 21:52:10 --> Output Class Initialized
INFO - 2018-03-16 21:52:10 --> Security Class Initialized
DEBUG - 2018-03-16 21:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:52:10 --> Input Class Initialized
INFO - 2018-03-16 21:52:10 --> Language Class Initialized
INFO - 2018-03-16 21:52:10 --> Loader Class Initialized
INFO - 2018-03-16 21:52:10 --> Helper loaded: url_helper
INFO - 2018-03-16 21:52:10 --> Helper loaded: site_helper
INFO - 2018-03-16 21:52:10 --> Database Driver Class Initialized
INFO - 2018-03-16 21:52:10 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:52:10 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:52:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:52:10 --> Controller Class Initialized
INFO - 2018-03-16 21:52:10 --> User Agent Class Initialized
INFO - 2018-03-16 21:52:10 --> Model "site_model" initialized
INFO - 2018-03-16 21:52:10 --> Model "user_model" initialized
INFO - 2018-03-16 21:52:10 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:52:10 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:52:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 21:52:10 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:52:10 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:52:10 --> Final output sent to browser
DEBUG - 2018-03-16 21:52:10 --> Total execution time: 0.0480
INFO - 2018-03-16 21:52:11 --> Database Driver Class Initialized
INFO - 2018-03-16 21:52:11 --> Config Class Initialized
INFO - 2018-03-16 21:52:11 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:52:11 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:52:11 --> Utf8 Class Initialized
INFO - 2018-03-16 21:52:11 --> URI Class Initialized
DEBUG - 2018-03-16 21:52:11 --> No URI present. Default controller set.
INFO - 2018-03-16 21:52:11 --> Router Class Initialized
INFO - 2018-03-16 21:52:11 --> Output Class Initialized
INFO - 2018-03-16 21:52:11 --> Security Class Initialized
DEBUG - 2018-03-16 21:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:52:11 --> Input Class Initialized
INFO - 2018-03-16 21:52:11 --> Language Class Initialized
INFO - 2018-03-16 21:52:11 --> Loader Class Initialized
INFO - 2018-03-16 21:52:11 --> Helper loaded: url_helper
INFO - 2018-03-16 21:52:11 --> Helper loaded: site_helper
INFO - 2018-03-16 21:52:11 --> Database Driver Class Initialized
INFO - 2018-03-16 21:52:11 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:52:11 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:52:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:52:11 --> Controller Class Initialized
INFO - 2018-03-16 21:52:11 --> User Agent Class Initialized
INFO - 2018-03-16 21:52:11 --> Model "site_model" initialized
INFO - 2018-03-16 21:52:11 --> Model "user_model" initialized
INFO - 2018-03-16 21:52:11 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:52:11 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:52:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 21:52:11 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:52:11 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:52:11 --> Final output sent to browser
DEBUG - 2018-03-16 21:52:11 --> Total execution time: 0.0510
INFO - 2018-03-16 21:52:32 --> Database Driver Class Initialized
INFO - 2018-03-16 21:52:32 --> Config Class Initialized
INFO - 2018-03-16 21:52:32 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:52:32 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:52:32 --> Utf8 Class Initialized
INFO - 2018-03-16 21:52:32 --> URI Class Initialized
DEBUG - 2018-03-16 21:52:32 --> No URI present. Default controller set.
INFO - 2018-03-16 21:52:32 --> Router Class Initialized
INFO - 2018-03-16 21:52:32 --> Output Class Initialized
INFO - 2018-03-16 21:52:32 --> Security Class Initialized
DEBUG - 2018-03-16 21:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:52:32 --> Input Class Initialized
INFO - 2018-03-16 21:52:32 --> Language Class Initialized
INFO - 2018-03-16 21:52:32 --> Loader Class Initialized
INFO - 2018-03-16 21:52:32 --> Helper loaded: url_helper
INFO - 2018-03-16 21:52:32 --> Helper loaded: site_helper
INFO - 2018-03-16 21:52:32 --> Database Driver Class Initialized
INFO - 2018-03-16 21:52:32 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:52:32 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:52:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:52:32 --> Controller Class Initialized
INFO - 2018-03-16 21:52:32 --> User Agent Class Initialized
INFO - 2018-03-16 21:52:32 --> Model "site_model" initialized
INFO - 2018-03-16 21:52:32 --> Model "user_model" initialized
INFO - 2018-03-16 21:52:32 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:52:32 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:52:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 21:52:32 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:52:32 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:52:32 --> Final output sent to browser
DEBUG - 2018-03-16 21:52:32 --> Total execution time: 0.0550
INFO - 2018-03-16 21:52:36 --> Database Driver Class Initialized
INFO - 2018-03-16 21:52:36 --> Config Class Initialized
INFO - 2018-03-16 21:52:36 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:52:36 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:52:36 --> Utf8 Class Initialized
INFO - 2018-03-16 21:52:36 --> URI Class Initialized
DEBUG - 2018-03-16 21:52:36 --> No URI present. Default controller set.
INFO - 2018-03-16 21:52:36 --> Router Class Initialized
INFO - 2018-03-16 21:52:36 --> Output Class Initialized
INFO - 2018-03-16 21:52:36 --> Security Class Initialized
DEBUG - 2018-03-16 21:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:52:36 --> Input Class Initialized
INFO - 2018-03-16 21:52:36 --> Language Class Initialized
INFO - 2018-03-16 21:52:36 --> Loader Class Initialized
INFO - 2018-03-16 21:52:36 --> Helper loaded: url_helper
INFO - 2018-03-16 21:52:36 --> Helper loaded: site_helper
INFO - 2018-03-16 21:52:36 --> Database Driver Class Initialized
INFO - 2018-03-16 21:52:36 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:52:36 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:52:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:52:36 --> Controller Class Initialized
INFO - 2018-03-16 21:52:36 --> User Agent Class Initialized
INFO - 2018-03-16 21:52:36 --> Model "site_model" initialized
INFO - 2018-03-16 21:52:36 --> Model "user_model" initialized
INFO - 2018-03-16 21:52:36 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:52:36 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:52:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 21:52:36 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:52:36 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:52:36 --> Final output sent to browser
DEBUG - 2018-03-16 21:52:36 --> Total execution time: 0.0630
INFO - 2018-03-16 21:52:40 --> Database Driver Class Initialized
INFO - 2018-03-16 21:52:40 --> Config Class Initialized
INFO - 2018-03-16 21:52:40 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:52:40 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:52:40 --> Utf8 Class Initialized
INFO - 2018-03-16 21:52:40 --> URI Class Initialized
DEBUG - 2018-03-16 21:52:40 --> No URI present. Default controller set.
INFO - 2018-03-16 21:52:40 --> Router Class Initialized
INFO - 2018-03-16 21:52:40 --> Output Class Initialized
INFO - 2018-03-16 21:52:40 --> Security Class Initialized
DEBUG - 2018-03-16 21:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:52:40 --> Input Class Initialized
INFO - 2018-03-16 21:52:40 --> Language Class Initialized
INFO - 2018-03-16 21:52:40 --> Loader Class Initialized
INFO - 2018-03-16 21:52:40 --> Helper loaded: url_helper
INFO - 2018-03-16 21:52:40 --> Helper loaded: site_helper
INFO - 2018-03-16 21:52:40 --> Database Driver Class Initialized
INFO - 2018-03-16 21:52:40 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:52:40 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:52:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:52:40 --> Controller Class Initialized
INFO - 2018-03-16 21:52:40 --> User Agent Class Initialized
INFO - 2018-03-16 21:52:40 --> Model "site_model" initialized
INFO - 2018-03-16 21:52:40 --> Model "user_model" initialized
INFO - 2018-03-16 21:52:40 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:52:40 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:52:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 21:52:40 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:52:40 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:52:40 --> Final output sent to browser
DEBUG - 2018-03-16 21:52:40 --> Total execution time: 0.0570
INFO - 2018-03-16 21:53:07 --> Database Driver Class Initialized
INFO - 2018-03-16 21:53:07 --> Config Class Initialized
INFO - 2018-03-16 21:53:07 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:53:07 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:53:07 --> Utf8 Class Initialized
INFO - 2018-03-16 21:53:07 --> URI Class Initialized
DEBUG - 2018-03-16 21:53:07 --> No URI present. Default controller set.
INFO - 2018-03-16 21:53:07 --> Router Class Initialized
INFO - 2018-03-16 21:53:07 --> Output Class Initialized
INFO - 2018-03-16 21:53:07 --> Security Class Initialized
DEBUG - 2018-03-16 21:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:53:07 --> Input Class Initialized
INFO - 2018-03-16 21:53:07 --> Language Class Initialized
INFO - 2018-03-16 21:53:07 --> Loader Class Initialized
INFO - 2018-03-16 21:53:07 --> Helper loaded: url_helper
INFO - 2018-03-16 21:53:07 --> Helper loaded: site_helper
INFO - 2018-03-16 21:53:07 --> Database Driver Class Initialized
INFO - 2018-03-16 21:53:07 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:53:07 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:53:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:53:07 --> Controller Class Initialized
INFO - 2018-03-16 21:53:07 --> User Agent Class Initialized
INFO - 2018-03-16 21:53:07 --> Model "site_model" initialized
INFO - 2018-03-16 21:53:07 --> Model "user_model" initialized
INFO - 2018-03-16 21:53:07 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:53:07 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:53:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 21:53:07 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:53:07 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:53:07 --> Final output sent to browser
DEBUG - 2018-03-16 21:53:07 --> Total execution time: 0.0450
INFO - 2018-03-16 21:54:22 --> Database Driver Class Initialized
INFO - 2018-03-16 21:54:22 --> Config Class Initialized
INFO - 2018-03-16 21:54:22 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:54:22 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:54:22 --> Utf8 Class Initialized
INFO - 2018-03-16 21:54:22 --> URI Class Initialized
DEBUG - 2018-03-16 21:54:22 --> No URI present. Default controller set.
INFO - 2018-03-16 21:54:22 --> Router Class Initialized
INFO - 2018-03-16 21:54:22 --> Output Class Initialized
INFO - 2018-03-16 21:54:22 --> Security Class Initialized
DEBUG - 2018-03-16 21:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:54:22 --> Input Class Initialized
INFO - 2018-03-16 21:54:22 --> Language Class Initialized
INFO - 2018-03-16 21:54:22 --> Loader Class Initialized
INFO - 2018-03-16 21:54:22 --> Helper loaded: url_helper
INFO - 2018-03-16 21:54:22 --> Helper loaded: site_helper
INFO - 2018-03-16 21:54:22 --> Database Driver Class Initialized
INFO - 2018-03-16 21:54:22 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:54:22 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:54:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:54:22 --> Controller Class Initialized
INFO - 2018-03-16 21:54:22 --> User Agent Class Initialized
INFO - 2018-03-16 21:54:22 --> Model "site_model" initialized
INFO - 2018-03-16 21:54:22 --> Model "user_model" initialized
INFO - 2018-03-16 21:54:22 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:54:22 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:54:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 21:54:22 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:54:22 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:54:22 --> Final output sent to browser
DEBUG - 2018-03-16 21:54:22 --> Total execution time: 0.0440
INFO - 2018-03-16 21:55:04 --> Database Driver Class Initialized
INFO - 2018-03-16 21:55:04 --> Config Class Initialized
INFO - 2018-03-16 21:55:04 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:55:04 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:55:04 --> Utf8 Class Initialized
INFO - 2018-03-16 21:55:04 --> URI Class Initialized
DEBUG - 2018-03-16 21:55:04 --> No URI present. Default controller set.
INFO - 2018-03-16 21:55:04 --> Router Class Initialized
INFO - 2018-03-16 21:55:04 --> Output Class Initialized
INFO - 2018-03-16 21:55:04 --> Security Class Initialized
DEBUG - 2018-03-16 21:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:55:04 --> Input Class Initialized
INFO - 2018-03-16 21:55:04 --> Language Class Initialized
INFO - 2018-03-16 21:55:04 --> Loader Class Initialized
INFO - 2018-03-16 21:55:04 --> Helper loaded: url_helper
INFO - 2018-03-16 21:55:04 --> Helper loaded: site_helper
INFO - 2018-03-16 21:55:04 --> Database Driver Class Initialized
INFO - 2018-03-16 21:55:04 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:55:04 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:55:04 --> Controller Class Initialized
INFO - 2018-03-16 21:55:04 --> User Agent Class Initialized
INFO - 2018-03-16 21:55:04 --> Model "site_model" initialized
INFO - 2018-03-16 21:55:04 --> Model "user_model" initialized
INFO - 2018-03-16 21:55:04 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:55:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:55:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 36
INFO - 2018-03-16 21:55:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:55:04 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:55:04 --> Final output sent to browser
DEBUG - 2018-03-16 21:55:04 --> Total execution time: 0.0530
INFO - 2018-03-16 21:55:37 --> Database Driver Class Initialized
INFO - 2018-03-16 21:55:37 --> Config Class Initialized
INFO - 2018-03-16 21:55:37 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:55:37 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:55:37 --> Utf8 Class Initialized
INFO - 2018-03-16 21:55:37 --> URI Class Initialized
DEBUG - 2018-03-16 21:55:37 --> No URI present. Default controller set.
INFO - 2018-03-16 21:55:37 --> Router Class Initialized
INFO - 2018-03-16 21:55:37 --> Output Class Initialized
INFO - 2018-03-16 21:55:37 --> Security Class Initialized
DEBUG - 2018-03-16 21:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:55:37 --> Input Class Initialized
INFO - 2018-03-16 21:55:37 --> Language Class Initialized
INFO - 2018-03-16 21:55:37 --> Loader Class Initialized
INFO - 2018-03-16 21:55:37 --> Helper loaded: url_helper
INFO - 2018-03-16 21:55:37 --> Helper loaded: site_helper
INFO - 2018-03-16 21:55:37 --> Database Driver Class Initialized
INFO - 2018-03-16 21:55:37 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:55:37 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:55:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:55:37 --> Controller Class Initialized
INFO - 2018-03-16 21:55:37 --> User Agent Class Initialized
INFO - 2018-03-16 21:55:37 --> Model "site_model" initialized
INFO - 2018-03-16 21:55:37 --> Model "user_model" initialized
INFO - 2018-03-16 21:55:37 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:55:37 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
ERROR - 2018-03-16 21:55:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\myteenmatch\application\views\templates\footers\welcome_footer.php 37
INFO - 2018-03-16 21:55:37 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:55:37 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:55:37 --> Final output sent to browser
DEBUG - 2018-03-16 21:55:37 --> Total execution time: 0.0430
INFO - 2018-03-16 21:56:20 --> Database Driver Class Initialized
INFO - 2018-03-16 21:56:20 --> Config Class Initialized
INFO - 2018-03-16 21:56:20 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:56:20 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:56:20 --> Utf8 Class Initialized
INFO - 2018-03-16 21:56:20 --> URI Class Initialized
DEBUG - 2018-03-16 21:56:20 --> No URI present. Default controller set.
INFO - 2018-03-16 21:56:20 --> Router Class Initialized
INFO - 2018-03-16 21:56:20 --> Output Class Initialized
INFO - 2018-03-16 21:56:20 --> Security Class Initialized
DEBUG - 2018-03-16 21:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:56:20 --> Input Class Initialized
INFO - 2018-03-16 21:56:20 --> Language Class Initialized
INFO - 2018-03-16 21:56:20 --> Loader Class Initialized
INFO - 2018-03-16 21:56:20 --> Helper loaded: url_helper
INFO - 2018-03-16 21:56:20 --> Helper loaded: site_helper
INFO - 2018-03-16 21:56:20 --> Database Driver Class Initialized
INFO - 2018-03-16 21:56:20 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:56:20 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:56:20 --> Controller Class Initialized
INFO - 2018-03-16 21:56:20 --> User Agent Class Initialized
INFO - 2018-03-16 21:56:20 --> Model "site_model" initialized
INFO - 2018-03-16 21:56:20 --> Model "user_model" initialized
INFO - 2018-03-16 21:56:20 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:56:20 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 21:56:20 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:56:20 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:56:20 --> Final output sent to browser
DEBUG - 2018-03-16 21:56:20 --> Total execution time: 0.0500
INFO - 2018-03-16 21:58:07 --> Database Driver Class Initialized
INFO - 2018-03-16 21:58:07 --> Config Class Initialized
INFO - 2018-03-16 21:58:07 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:58:07 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:58:07 --> Utf8 Class Initialized
INFO - 2018-03-16 21:58:07 --> URI Class Initialized
DEBUG - 2018-03-16 21:58:07 --> No URI present. Default controller set.
INFO - 2018-03-16 21:58:07 --> Router Class Initialized
INFO - 2018-03-16 21:58:08 --> Output Class Initialized
INFO - 2018-03-16 21:58:08 --> Security Class Initialized
DEBUG - 2018-03-16 21:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:58:08 --> Input Class Initialized
INFO - 2018-03-16 21:58:08 --> Language Class Initialized
INFO - 2018-03-16 21:58:08 --> Loader Class Initialized
INFO - 2018-03-16 21:58:08 --> Helper loaded: url_helper
INFO - 2018-03-16 21:58:08 --> Helper loaded: site_helper
INFO - 2018-03-16 21:58:08 --> Database Driver Class Initialized
INFO - 2018-03-16 21:58:08 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:58:08 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:58:08 --> Controller Class Initialized
INFO - 2018-03-16 21:58:08 --> User Agent Class Initialized
INFO - 2018-03-16 21:58:08 --> Model "site_model" initialized
INFO - 2018-03-16 21:58:08 --> Model "user_model" initialized
INFO - 2018-03-16 21:58:08 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:58:08 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 21:58:08 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:58:08 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:58:08 --> Final output sent to browser
DEBUG - 2018-03-16 21:58:08 --> Total execution time: 0.0420
INFO - 2018-03-16 21:58:10 --> Database Driver Class Initialized
INFO - 2018-03-16 21:58:10 --> Config Class Initialized
INFO - 2018-03-16 21:58:10 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:58:10 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:58:10 --> Utf8 Class Initialized
INFO - 2018-03-16 21:58:10 --> URI Class Initialized
INFO - 2018-03-16 21:58:10 --> Router Class Initialized
INFO - 2018-03-16 21:58:10 --> Output Class Initialized
INFO - 2018-03-16 21:58:10 --> Security Class Initialized
DEBUG - 2018-03-16 21:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:58:10 --> Input Class Initialized
INFO - 2018-03-16 21:58:10 --> Language Class Initialized
INFO - 2018-03-16 21:58:10 --> Loader Class Initialized
INFO - 2018-03-16 21:58:10 --> Helper loaded: url_helper
INFO - 2018-03-16 21:58:10 --> Helper loaded: site_helper
INFO - 2018-03-16 21:58:10 --> Database Driver Class Initialized
INFO - 2018-03-16 21:58:10 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:58:10 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:58:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:58:10 --> Controller Class Initialized
INFO - 2018-03-16 21:58:10 --> Model "user_model" initialized
INFO - 2018-03-16 21:58:10 --> Model "site_model" initialized
INFO - 2018-03-16 21:58:10 --> Language file loaded: language/english/user_lang.php
INFO - 2018-03-16 21:58:10 --> Final output sent to browser
DEBUG - 2018-03-16 21:58:10 --> Total execution time: 0.0580
INFO - 2018-03-16 21:58:11 --> Database Driver Class Initialized
INFO - 2018-03-16 21:58:11 --> Config Class Initialized
INFO - 2018-03-16 21:58:11 --> Hooks Class Initialized
DEBUG - 2018-03-16 21:58:11 --> UTF-8 Support Enabled
INFO - 2018-03-16 21:58:11 --> Utf8 Class Initialized
INFO - 2018-03-16 21:58:11 --> URI Class Initialized
DEBUG - 2018-03-16 21:58:11 --> No URI present. Default controller set.
INFO - 2018-03-16 21:58:11 --> Router Class Initialized
INFO - 2018-03-16 21:58:11 --> Output Class Initialized
INFO - 2018-03-16 21:58:11 --> Security Class Initialized
DEBUG - 2018-03-16 21:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 21:58:11 --> Input Class Initialized
INFO - 2018-03-16 21:58:11 --> Language Class Initialized
INFO - 2018-03-16 21:58:11 --> Loader Class Initialized
INFO - 2018-03-16 21:58:11 --> Helper loaded: url_helper
INFO - 2018-03-16 21:58:11 --> Helper loaded: site_helper
INFO - 2018-03-16 21:58:11 --> Database Driver Class Initialized
INFO - 2018-03-16 21:58:11 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 21:58:11 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 21:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 21:58:11 --> Controller Class Initialized
INFO - 2018-03-16 21:58:11 --> User Agent Class Initialized
INFO - 2018-03-16 21:58:11 --> Model "site_model" initialized
INFO - 2018-03-16 21:58:11 --> Model "user_model" initialized
INFO - 2018-03-16 21:58:11 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 21:58:11 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 21:58:11 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 21:58:11 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 21:58:11 --> Final output sent to browser
DEBUG - 2018-03-16 21:58:11 --> Total execution time: 0.0420
INFO - 2018-03-16 22:00:50 --> Database Driver Class Initialized
INFO - 2018-03-16 22:00:50 --> Config Class Initialized
INFO - 2018-03-16 22:00:50 --> Hooks Class Initialized
DEBUG - 2018-03-16 22:00:50 --> UTF-8 Support Enabled
INFO - 2018-03-16 22:00:50 --> Utf8 Class Initialized
INFO - 2018-03-16 22:00:50 --> URI Class Initialized
DEBUG - 2018-03-16 22:00:50 --> No URI present. Default controller set.
INFO - 2018-03-16 22:00:50 --> Router Class Initialized
INFO - 2018-03-16 22:00:50 --> Output Class Initialized
INFO - 2018-03-16 22:00:50 --> Security Class Initialized
DEBUG - 2018-03-16 22:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 22:00:50 --> Input Class Initialized
INFO - 2018-03-16 22:00:50 --> Language Class Initialized
INFO - 2018-03-16 22:00:50 --> Loader Class Initialized
INFO - 2018-03-16 22:00:50 --> Helper loaded: url_helper
INFO - 2018-03-16 22:00:50 --> Helper loaded: site_helper
INFO - 2018-03-16 22:00:50 --> Database Driver Class Initialized
INFO - 2018-03-16 22:00:50 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 22:00:50 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 22:00:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 22:00:50 --> Controller Class Initialized
INFO - 2018-03-16 22:00:50 --> User Agent Class Initialized
INFO - 2018-03-16 22:00:50 --> Model "site_model" initialized
INFO - 2018-03-16 22:00:50 --> Model "user_model" initialized
INFO - 2018-03-16 22:00:50 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 22:00:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 22:00:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 22:00:50 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 22:00:50 --> Final output sent to browser
DEBUG - 2018-03-16 22:00:50 --> Total execution time: 0.0550
INFO - 2018-03-16 22:00:55 --> Database Driver Class Initialized
INFO - 2018-03-16 22:00:55 --> Config Class Initialized
INFO - 2018-03-16 22:00:55 --> Hooks Class Initialized
DEBUG - 2018-03-16 22:00:55 --> UTF-8 Support Enabled
INFO - 2018-03-16 22:00:55 --> Utf8 Class Initialized
INFO - 2018-03-16 22:00:55 --> URI Class Initialized
DEBUG - 2018-03-16 22:00:55 --> No URI present. Default controller set.
INFO - 2018-03-16 22:00:55 --> Router Class Initialized
INFO - 2018-03-16 22:00:55 --> Output Class Initialized
INFO - 2018-03-16 22:00:55 --> Security Class Initialized
DEBUG - 2018-03-16 22:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 22:00:55 --> Input Class Initialized
INFO - 2018-03-16 22:00:55 --> Language Class Initialized
INFO - 2018-03-16 22:00:55 --> Loader Class Initialized
INFO - 2018-03-16 22:00:55 --> Helper loaded: url_helper
INFO - 2018-03-16 22:00:55 --> Helper loaded: site_helper
INFO - 2018-03-16 22:00:55 --> Database Driver Class Initialized
INFO - 2018-03-16 22:00:55 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 22:00:55 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 22:00:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 22:00:55 --> Controller Class Initialized
INFO - 2018-03-16 22:00:55 --> User Agent Class Initialized
INFO - 2018-03-16 22:00:55 --> Model "site_model" initialized
INFO - 2018-03-16 22:00:55 --> Model "user_model" initialized
INFO - 2018-03-16 22:00:55 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 22:00:55 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 22:00:55 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 22:00:55 --> Final output sent to browser
DEBUG - 2018-03-16 22:00:55 --> Total execution time: 0.0410
INFO - 2018-03-16 22:00:58 --> Database Driver Class Initialized
INFO - 2018-03-16 22:00:58 --> Config Class Initialized
INFO - 2018-03-16 22:00:58 --> Hooks Class Initialized
DEBUG - 2018-03-16 22:00:58 --> UTF-8 Support Enabled
INFO - 2018-03-16 22:00:58 --> Utf8 Class Initialized
INFO - 2018-03-16 22:00:58 --> URI Class Initialized
DEBUG - 2018-03-16 22:00:58 --> No URI present. Default controller set.
INFO - 2018-03-16 22:00:58 --> Router Class Initialized
INFO - 2018-03-16 22:00:58 --> Output Class Initialized
INFO - 2018-03-16 22:00:58 --> Security Class Initialized
DEBUG - 2018-03-16 22:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 22:00:58 --> Input Class Initialized
INFO - 2018-03-16 22:00:58 --> Language Class Initialized
INFO - 2018-03-16 22:00:58 --> Loader Class Initialized
INFO - 2018-03-16 22:00:58 --> Helper loaded: url_helper
INFO - 2018-03-16 22:00:58 --> Helper loaded: site_helper
INFO - 2018-03-16 22:00:58 --> Database Driver Class Initialized
INFO - 2018-03-16 22:00:58 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 22:00:58 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 22:00:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 22:00:58 --> Controller Class Initialized
INFO - 2018-03-16 22:00:58 --> User Agent Class Initialized
INFO - 2018-03-16 22:00:58 --> Model "site_model" initialized
INFO - 2018-03-16 22:00:58 --> Model "user_model" initialized
INFO - 2018-03-16 22:00:58 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 22:00:58 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 22:00:58 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 22:00:58 --> Final output sent to browser
DEBUG - 2018-03-16 22:00:58 --> Total execution time: 0.0530
INFO - 2018-03-16 22:01:10 --> Database Driver Class Initialized
INFO - 2018-03-16 22:01:10 --> Config Class Initialized
INFO - 2018-03-16 22:01:10 --> Hooks Class Initialized
DEBUG - 2018-03-16 22:01:10 --> UTF-8 Support Enabled
INFO - 2018-03-16 22:01:10 --> Utf8 Class Initialized
INFO - 2018-03-16 22:01:10 --> URI Class Initialized
DEBUG - 2018-03-16 22:01:10 --> No URI present. Default controller set.
INFO - 2018-03-16 22:01:10 --> Router Class Initialized
INFO - 2018-03-16 22:01:10 --> Output Class Initialized
INFO - 2018-03-16 22:01:10 --> Security Class Initialized
DEBUG - 2018-03-16 22:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 22:01:10 --> Input Class Initialized
INFO - 2018-03-16 22:01:10 --> Language Class Initialized
INFO - 2018-03-16 22:01:10 --> Loader Class Initialized
INFO - 2018-03-16 22:01:10 --> Helper loaded: url_helper
INFO - 2018-03-16 22:01:10 --> Helper loaded: site_helper
INFO - 2018-03-16 22:01:10 --> Database Driver Class Initialized
INFO - 2018-03-16 22:01:10 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 22:01:10 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 22:01:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 22:01:10 --> Controller Class Initialized
INFO - 2018-03-16 22:01:10 --> User Agent Class Initialized
INFO - 2018-03-16 22:01:10 --> Model "site_model" initialized
INFO - 2018-03-16 22:01:10 --> Model "user_model" initialized
INFO - 2018-03-16 22:01:10 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 22:01:10 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 22:01:10 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 22:01:10 --> Final output sent to browser
DEBUG - 2018-03-16 22:01:10 --> Total execution time: 0.0500
INFO - 2018-03-16 22:01:14 --> Database Driver Class Initialized
INFO - 2018-03-16 22:01:14 --> Config Class Initialized
INFO - 2018-03-16 22:01:14 --> Hooks Class Initialized
DEBUG - 2018-03-16 22:01:14 --> UTF-8 Support Enabled
INFO - 2018-03-16 22:01:14 --> Utf8 Class Initialized
INFO - 2018-03-16 22:01:14 --> URI Class Initialized
DEBUG - 2018-03-16 22:01:14 --> No URI present. Default controller set.
INFO - 2018-03-16 22:01:14 --> Router Class Initialized
INFO - 2018-03-16 22:01:14 --> Output Class Initialized
INFO - 2018-03-16 22:01:14 --> Security Class Initialized
DEBUG - 2018-03-16 22:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 22:01:14 --> Input Class Initialized
INFO - 2018-03-16 22:01:14 --> Language Class Initialized
INFO - 2018-03-16 22:01:14 --> Loader Class Initialized
INFO - 2018-03-16 22:01:14 --> Helper loaded: url_helper
INFO - 2018-03-16 22:01:14 --> Helper loaded: site_helper
INFO - 2018-03-16 22:01:14 --> Database Driver Class Initialized
INFO - 2018-03-16 22:01:14 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 22:01:14 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 22:01:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 22:01:14 --> Controller Class Initialized
INFO - 2018-03-16 22:01:14 --> User Agent Class Initialized
INFO - 2018-03-16 22:01:14 --> Model "site_model" initialized
INFO - 2018-03-16 22:01:14 --> Model "user_model" initialized
INFO - 2018-03-16 22:01:14 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 22:01:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 22:01:14 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 22:01:14 --> Final output sent to browser
DEBUG - 2018-03-16 22:01:14 --> Total execution time: 0.0650
INFO - 2018-03-16 22:01:19 --> Database Driver Class Initialized
INFO - 2018-03-16 22:01:19 --> Config Class Initialized
INFO - 2018-03-16 22:01:19 --> Hooks Class Initialized
DEBUG - 2018-03-16 22:01:19 --> UTF-8 Support Enabled
INFO - 2018-03-16 22:01:19 --> Utf8 Class Initialized
INFO - 2018-03-16 22:01:19 --> URI Class Initialized
DEBUG - 2018-03-16 22:01:19 --> No URI present. Default controller set.
INFO - 2018-03-16 22:01:19 --> Router Class Initialized
INFO - 2018-03-16 22:01:19 --> Output Class Initialized
INFO - 2018-03-16 22:01:19 --> Security Class Initialized
DEBUG - 2018-03-16 22:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 22:01:19 --> Input Class Initialized
INFO - 2018-03-16 22:01:19 --> Language Class Initialized
INFO - 2018-03-16 22:01:19 --> Loader Class Initialized
INFO - 2018-03-16 22:01:19 --> Helper loaded: url_helper
INFO - 2018-03-16 22:01:19 --> Helper loaded: site_helper
INFO - 2018-03-16 22:01:19 --> Database Driver Class Initialized
INFO - 2018-03-16 22:01:19 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 22:01:19 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 22:01:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 22:01:19 --> Controller Class Initialized
INFO - 2018-03-16 22:01:19 --> User Agent Class Initialized
INFO - 2018-03-16 22:01:19 --> Model "site_model" initialized
INFO - 2018-03-16 22:01:19 --> Model "user_model" initialized
INFO - 2018-03-16 22:01:19 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 22:01:19 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 22:01:19 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 22:01:19 --> Final output sent to browser
DEBUG - 2018-03-16 22:01:19 --> Total execution time: 0.0500
INFO - 2018-03-16 22:01:21 --> Database Driver Class Initialized
INFO - 2018-03-16 22:01:21 --> Config Class Initialized
INFO - 2018-03-16 22:01:21 --> Hooks Class Initialized
DEBUG - 2018-03-16 22:01:21 --> UTF-8 Support Enabled
INFO - 2018-03-16 22:01:21 --> Utf8 Class Initialized
INFO - 2018-03-16 22:01:21 --> URI Class Initialized
DEBUG - 2018-03-16 22:01:21 --> No URI present. Default controller set.
INFO - 2018-03-16 22:01:21 --> Router Class Initialized
INFO - 2018-03-16 22:01:21 --> Output Class Initialized
INFO - 2018-03-16 22:01:21 --> Security Class Initialized
DEBUG - 2018-03-16 22:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 22:01:21 --> Input Class Initialized
INFO - 2018-03-16 22:01:21 --> Language Class Initialized
INFO - 2018-03-16 22:01:21 --> Loader Class Initialized
INFO - 2018-03-16 22:01:21 --> Helper loaded: url_helper
INFO - 2018-03-16 22:01:21 --> Helper loaded: site_helper
INFO - 2018-03-16 22:01:21 --> Database Driver Class Initialized
INFO - 2018-03-16 22:01:21 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 22:01:21 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 22:01:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 22:01:21 --> Controller Class Initialized
INFO - 2018-03-16 22:01:21 --> User Agent Class Initialized
INFO - 2018-03-16 22:01:21 --> Model "site_model" initialized
INFO - 2018-03-16 22:01:21 --> Model "user_model" initialized
INFO - 2018-03-16 22:01:21 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 22:01:21 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 22:01:21 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 22:01:21 --> Final output sent to browser
DEBUG - 2018-03-16 22:01:21 --> Total execution time: 0.0430
INFO - 2018-03-16 22:02:17 --> Database Driver Class Initialized
INFO - 2018-03-16 22:02:17 --> Config Class Initialized
INFO - 2018-03-16 22:02:17 --> Hooks Class Initialized
DEBUG - 2018-03-16 22:02:17 --> UTF-8 Support Enabled
INFO - 2018-03-16 22:02:17 --> Utf8 Class Initialized
INFO - 2018-03-16 22:02:17 --> URI Class Initialized
DEBUG - 2018-03-16 22:02:17 --> No URI present. Default controller set.
INFO - 2018-03-16 22:02:17 --> Router Class Initialized
INFO - 2018-03-16 22:02:17 --> Output Class Initialized
INFO - 2018-03-16 22:02:17 --> Security Class Initialized
DEBUG - 2018-03-16 22:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 22:02:17 --> Input Class Initialized
INFO - 2018-03-16 22:02:17 --> Language Class Initialized
INFO - 2018-03-16 22:02:17 --> Loader Class Initialized
INFO - 2018-03-16 22:02:17 --> Helper loaded: url_helper
INFO - 2018-03-16 22:02:17 --> Helper loaded: site_helper
INFO - 2018-03-16 22:02:17 --> Database Driver Class Initialized
INFO - 2018-03-16 22:02:17 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 22:02:17 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 22:02:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 22:02:17 --> Controller Class Initialized
INFO - 2018-03-16 22:02:17 --> User Agent Class Initialized
INFO - 2018-03-16 22:02:17 --> Model "site_model" initialized
INFO - 2018-03-16 22:02:17 --> Model "user_model" initialized
INFO - 2018-03-16 22:02:17 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 22:02:17 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 22:02:17 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 22:02:17 --> Final output sent to browser
DEBUG - 2018-03-16 22:02:17 --> Total execution time: 0.0520
INFO - 2018-03-16 22:02:45 --> Database Driver Class Initialized
INFO - 2018-03-16 22:02:45 --> Config Class Initialized
INFO - 2018-03-16 22:02:45 --> Hooks Class Initialized
DEBUG - 2018-03-16 22:02:45 --> UTF-8 Support Enabled
INFO - 2018-03-16 22:02:45 --> Utf8 Class Initialized
INFO - 2018-03-16 22:02:45 --> URI Class Initialized
DEBUG - 2018-03-16 22:02:45 --> No URI present. Default controller set.
INFO - 2018-03-16 22:02:45 --> Router Class Initialized
INFO - 2018-03-16 22:02:45 --> Output Class Initialized
INFO - 2018-03-16 22:02:45 --> Security Class Initialized
DEBUG - 2018-03-16 22:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 22:02:45 --> Input Class Initialized
INFO - 2018-03-16 22:02:45 --> Language Class Initialized
INFO - 2018-03-16 22:02:45 --> Loader Class Initialized
INFO - 2018-03-16 22:02:45 --> Helper loaded: url_helper
INFO - 2018-03-16 22:02:45 --> Helper loaded: site_helper
INFO - 2018-03-16 22:02:45 --> Database Driver Class Initialized
INFO - 2018-03-16 22:02:45 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 22:02:45 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 22:02:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 22:02:45 --> Controller Class Initialized
INFO - 2018-03-16 22:02:45 --> User Agent Class Initialized
INFO - 2018-03-16 22:02:45 --> Model "site_model" initialized
INFO - 2018-03-16 22:02:45 --> Model "user_model" initialized
INFO - 2018-03-16 22:02:45 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 22:02:45 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 22:02:45 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 22:02:45 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 22:02:45 --> Final output sent to browser
DEBUG - 2018-03-16 22:02:45 --> Total execution time: 0.0690
INFO - 2018-03-16 22:02:53 --> Database Driver Class Initialized
INFO - 2018-03-16 22:02:53 --> Config Class Initialized
INFO - 2018-03-16 22:02:53 --> Hooks Class Initialized
DEBUG - 2018-03-16 22:02:53 --> UTF-8 Support Enabled
INFO - 2018-03-16 22:02:53 --> Utf8 Class Initialized
INFO - 2018-03-16 22:02:53 --> URI Class Initialized
DEBUG - 2018-03-16 22:02:53 --> No URI present. Default controller set.
INFO - 2018-03-16 22:02:53 --> Router Class Initialized
INFO - 2018-03-16 22:02:53 --> Output Class Initialized
INFO - 2018-03-16 22:02:53 --> Security Class Initialized
DEBUG - 2018-03-16 22:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 22:02:53 --> Input Class Initialized
INFO - 2018-03-16 22:02:53 --> Language Class Initialized
INFO - 2018-03-16 22:02:53 --> Loader Class Initialized
INFO - 2018-03-16 22:02:53 --> Helper loaded: url_helper
INFO - 2018-03-16 22:02:53 --> Helper loaded: site_helper
INFO - 2018-03-16 22:02:53 --> Database Driver Class Initialized
INFO - 2018-03-16 22:02:53 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 22:02:53 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 22:02:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 22:02:53 --> Controller Class Initialized
INFO - 2018-03-16 22:02:53 --> User Agent Class Initialized
INFO - 2018-03-16 22:02:53 --> Model "site_model" initialized
INFO - 2018-03-16 22:02:53 --> Model "user_model" initialized
INFO - 2018-03-16 22:02:53 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 22:02:53 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 22:02:53 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 22:02:53 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 22:02:53 --> Final output sent to browser
DEBUG - 2018-03-16 22:02:53 --> Total execution time: 0.0510
INFO - 2018-03-16 22:02:59 --> Database Driver Class Initialized
INFO - 2018-03-16 22:02:59 --> Config Class Initialized
INFO - 2018-03-16 22:02:59 --> Hooks Class Initialized
DEBUG - 2018-03-16 22:02:59 --> UTF-8 Support Enabled
INFO - 2018-03-16 22:02:59 --> Utf8 Class Initialized
INFO - 2018-03-16 22:02:59 --> URI Class Initialized
DEBUG - 2018-03-16 22:02:59 --> No URI present. Default controller set.
INFO - 2018-03-16 22:02:59 --> Router Class Initialized
INFO - 2018-03-16 22:02:59 --> Output Class Initialized
INFO - 2018-03-16 22:02:59 --> Security Class Initialized
DEBUG - 2018-03-16 22:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 22:02:59 --> Input Class Initialized
INFO - 2018-03-16 22:02:59 --> Language Class Initialized
INFO - 2018-03-16 22:02:59 --> Loader Class Initialized
INFO - 2018-03-16 22:02:59 --> Helper loaded: url_helper
INFO - 2018-03-16 22:02:59 --> Helper loaded: site_helper
INFO - 2018-03-16 22:02:59 --> Database Driver Class Initialized
INFO - 2018-03-16 22:02:59 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 22:02:59 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 22:02:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 22:02:59 --> Controller Class Initialized
INFO - 2018-03-16 22:02:59 --> User Agent Class Initialized
INFO - 2018-03-16 22:02:59 --> Model "site_model" initialized
INFO - 2018-03-16 22:02:59 --> Model "user_model" initialized
INFO - 2018-03-16 22:02:59 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 22:02:59 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 22:02:59 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 22:02:59 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 22:02:59 --> Final output sent to browser
DEBUG - 2018-03-16 22:02:59 --> Total execution time: 0.0690
INFO - 2018-03-16 22:03:00 --> Database Driver Class Initialized
INFO - 2018-03-16 22:03:00 --> Config Class Initialized
INFO - 2018-03-16 22:03:00 --> Hooks Class Initialized
DEBUG - 2018-03-16 22:03:00 --> UTF-8 Support Enabled
INFO - 2018-03-16 22:03:00 --> Utf8 Class Initialized
INFO - 2018-03-16 22:03:00 --> URI Class Initialized
DEBUG - 2018-03-16 22:03:00 --> No URI present. Default controller set.
INFO - 2018-03-16 22:03:00 --> Router Class Initialized
INFO - 2018-03-16 22:03:00 --> Output Class Initialized
INFO - 2018-03-16 22:03:00 --> Security Class Initialized
DEBUG - 2018-03-16 22:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 22:03:00 --> Input Class Initialized
INFO - 2018-03-16 22:03:00 --> Language Class Initialized
INFO - 2018-03-16 22:03:00 --> Loader Class Initialized
INFO - 2018-03-16 22:03:00 --> Helper loaded: url_helper
INFO - 2018-03-16 22:03:00 --> Helper loaded: site_helper
INFO - 2018-03-16 22:03:00 --> Database Driver Class Initialized
INFO - 2018-03-16 22:03:00 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 22:03:00 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 22:03:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 22:03:00 --> Controller Class Initialized
INFO - 2018-03-16 22:03:00 --> User Agent Class Initialized
INFO - 2018-03-16 22:03:00 --> Model "site_model" initialized
INFO - 2018-03-16 22:03:00 --> Model "user_model" initialized
INFO - 2018-03-16 22:03:00 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 22:03:00 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 22:03:00 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 22:03:00 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 22:03:00 --> Final output sent to browser
DEBUG - 2018-03-16 22:03:00 --> Total execution time: 0.0730
INFO - 2018-03-16 22:03:02 --> Database Driver Class Initialized
INFO - 2018-03-16 22:03:02 --> Config Class Initialized
INFO - 2018-03-16 22:03:02 --> Hooks Class Initialized
DEBUG - 2018-03-16 22:03:02 --> UTF-8 Support Enabled
INFO - 2018-03-16 22:03:02 --> Utf8 Class Initialized
INFO - 2018-03-16 22:03:02 --> URI Class Initialized
DEBUG - 2018-03-16 22:03:02 --> No URI present. Default controller set.
INFO - 2018-03-16 22:03:02 --> Router Class Initialized
INFO - 2018-03-16 22:03:02 --> Output Class Initialized
INFO - 2018-03-16 22:03:02 --> Security Class Initialized
DEBUG - 2018-03-16 22:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 22:03:02 --> Input Class Initialized
INFO - 2018-03-16 22:03:02 --> Language Class Initialized
INFO - 2018-03-16 22:03:02 --> Loader Class Initialized
INFO - 2018-03-16 22:03:02 --> Helper loaded: url_helper
INFO - 2018-03-16 22:03:02 --> Helper loaded: site_helper
INFO - 2018-03-16 22:03:02 --> Database Driver Class Initialized
INFO - 2018-03-16 22:03:02 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 22:03:02 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 22:03:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 22:03:02 --> Controller Class Initialized
INFO - 2018-03-16 22:03:02 --> User Agent Class Initialized
INFO - 2018-03-16 22:03:02 --> Model "site_model" initialized
INFO - 2018-03-16 22:03:02 --> Model "user_model" initialized
INFO - 2018-03-16 22:03:02 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 22:03:02 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 22:03:02 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 22:03:02 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 22:03:02 --> Final output sent to browser
DEBUG - 2018-03-16 22:03:02 --> Total execution time: 0.0950
INFO - 2018-03-16 22:03:03 --> Database Driver Class Initialized
INFO - 2018-03-16 22:03:03 --> Config Class Initialized
INFO - 2018-03-16 22:03:03 --> Hooks Class Initialized
DEBUG - 2018-03-16 22:03:03 --> UTF-8 Support Enabled
INFO - 2018-03-16 22:03:03 --> Utf8 Class Initialized
INFO - 2018-03-16 22:03:03 --> URI Class Initialized
DEBUG - 2018-03-16 22:03:03 --> No URI present. Default controller set.
INFO - 2018-03-16 22:03:03 --> Router Class Initialized
INFO - 2018-03-16 22:03:03 --> Output Class Initialized
INFO - 2018-03-16 22:03:03 --> Security Class Initialized
DEBUG - 2018-03-16 22:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-16 22:03:03 --> Input Class Initialized
INFO - 2018-03-16 22:03:03 --> Language Class Initialized
INFO - 2018-03-16 22:03:03 --> Loader Class Initialized
INFO - 2018-03-16 22:03:03 --> Helper loaded: url_helper
INFO - 2018-03-16 22:03:03 --> Helper loaded: site_helper
INFO - 2018-03-16 22:03:03 --> Database Driver Class Initialized
INFO - 2018-03-16 22:03:03 --> Session: Class initialized using 'database' driver.
DEBUG - 2018-03-16 22:03:03 --> Config file loaded: D:\xampp\htdocs\myteenmatch\application\config/facebook.php
DEBUG - 2018-03-16 22:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-16 22:03:03 --> Controller Class Initialized
INFO - 2018-03-16 22:03:03 --> User Agent Class Initialized
INFO - 2018-03-16 22:03:03 --> Model "site_model" initialized
INFO - 2018-03-16 22:03:03 --> Model "user_model" initialized
INFO - 2018-03-16 22:03:03 --> Language file loaded: language/english/site_lang.php
INFO - 2018-03-16 22:03:03 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/headers/welcome_header.php
INFO - 2018-03-16 22:03:03 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\templates/footers/welcome_footer.php
INFO - 2018-03-16 22:03:03 --> File loaded: D:\xampp\htdocs\myteenmatch\application\views\welcome.php
INFO - 2018-03-16 22:03:03 --> Final output sent to browser
DEBUG - 2018-03-16 22:03:03 --> Total execution time: 0.0850
