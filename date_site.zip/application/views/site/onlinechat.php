<?php
$this->load->view('templates/headers/main_header', $title);
?>
<div class="container">
	<div class="row">
    <div id="addchat_initiate"></div>
		<div class="pull-left">
			<h3><?php echo $this->lang->line('Home'); ?></h3>
		</div>
		<div class="pull-right">
        
		</div>
	</div>
</div>
<?php
$this->load->view('templates/footers/main_footer');
?>