		
		
		<script type="text/javascript">
			var base_url = "<?php echo base_url() ?>";
		</script>
		
		<!-- Load JS here for greater good =============================-->
		<script src="<?php echo base_url(); ?>js/jquery-2.1.1.js"></script>
		<script src="<?php echo base_url(); ?>js/jquery-ui-1.10.4.min.js"></script>
		<script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>
		<script src="<?php echo base_url(); ?>js/jquery.cookie.min.js"></script>
		<script src="<?php echo base_url(); ?>js/pages/recover_password.js"></script>
	</body>
</html>